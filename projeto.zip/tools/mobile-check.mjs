import { chromium } from 'playwright-core';
const b = await chromium.launch({ channel: 'chrome' });
for (const [w, h, tag] of [[412, 915, 'cheio'], [412, 560, 'teclado']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, hasTouch: true, isMobile: true, deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  await p.goto('http://localhost:5181/?demo=login'); await p.waitForTimeout(1500);
  await p.screenshot({ path: `tools/m-login-${tag}.png` });
  await p.goto('http://localhost:5181/?demo=first'); await p.waitForTimeout(1500);
  await p.screenshot({ path: `tools/m-first-${tag}.png` });
  console.log(tag, await p.evaluate(() => { const f = document.querySelector('.ac-frame').getBoundingClientRect(); return [f.width, f.height, getComputedStyle(document.querySelector('.ac-frame')).borderRadius]; }));
  await ctx.close();
}
await b.close();
