const fs=require('fs'),zlib=require('zlib');
const h=fs.readFileSync(''+require('path').join(__dirname,'../prototype/original.html')+'','utf8');
const get=t=>{const o="<script type=\"__bundler/"+t+"\">";const i=h.lastIndexOf(o);if(i<0)return null;const s=i+o.length;return h.slice(s,h.indexOf("</script>",s));};
const man=JSON.parse(get('manifest'));let tpl=JSON.parse(get('template'));
fs.mkdirSync('assets',{recursive:true});
const ext={'application/javascript':'js','text/javascript':'js','text/css':'css','image/png':'png','image/svg+xml':'svg','text/html':'html','text/jsx':'jsx','text/babel':'jsx'};
for(const [u,e] of Object.entries(man)){let b=Buffer.from(e.data,'base64');if(e.compressed)b=zlib.gunzipSync(b);
const x=ext[e.mime]||e.mime.replace(/\W/g,'_');fs.writeFileSync('assets/'+u+'.'+x,b);console.log(u,e.mime,b.length);tpl=tpl.split(u).join('assets/'+u+'.'+x);}
fs.writeFileSync('index.html',tpl);console.log('ext',get('ext_resources')?.slice(0,300));
