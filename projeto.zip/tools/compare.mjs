// Compara o app com o HTML de protótipo (fonte da verdade), pixel a pixel, em fluxos reais.
// Uso: node tools/compare.mjs [filtroDeFluxo]
// Requer: protótipo servido em :5182 (original.html) e app em :5181 (npm run dev).
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright-core';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';
import { FLOWS } from './flows.mjs';

const ORIG = process.env.ORIG || 'http://localhost:5182/original.html'; // sirva a pasta prototype/ na 5182
const APP = process.env.APP || 'http://localhost:5181/';
const OUT = path.join(path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/, '$1')), 'out');
fs.mkdirSync(OUT, { recursive: true });
const filter = process.argv[2];

const INIT = () => {
  // Aleatoriedade determinística — os dois lados sorteiam a mesma sequência.
  let a = 1234567;
  Math.random = () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
};

async function run(browser, base, flow) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, reducedMotion: 'reduce', locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
  const page = await ctx.newPage();
  await page.clock.install({ time: new Date('2026-10-05T10:00:00-03:00') });
  await page.clock.resume();
  await page.addInitScript(INIT);
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  const shots = {};
  const steps = [];
  const expand = list => { for (const st of list) { if (st.loop) { for (let i = 0; i < st.loop; i++) expand(st.steps.map(x => (x.shot ? { ...x, shot: x.shot + '-' + i } : x))); } else steps.push(st); } };
  expand(flow.steps);
  for (const step of steps) {
    if (step.goto !== undefined) {
      await page.goto(base + step.goto, { waitUntil: 'load' });
      await page.waitForFunction(() => !document.getElementById('__bundler_loading') && document.querySelectorAll('div').length > 5, null, { timeout: 20000 });
      await page.waitForTimeout(step.settle ?? 900);
    } else if (step.click) {
      const loc = typeof step.click === 'string' ? page.getByText(step.click, { exact: step.exact ?? false }).nth(step.nth ?? 0) : page.locator(step.click.css).nth(step.click.nth ?? 0);
      await loc.click({ timeout: 5000 }).catch(e => errors.push('click ' + JSON.stringify(step.click) + ': ' + e.message.split('\n')[0]));
      await page.waitForTimeout(step.wait ?? 450);
    } else if (step.fill) {
      await page.locator(step.fill[0]).nth(step.fill[2] ?? 0).fill(step.fill[1]).catch(e => errors.push('fill: ' + e.message.split('\n')[0]));
      await page.waitForTimeout(150);
    } else if (step.press) {
      await page.keyboard.press(step.press);
      await page.waitForTimeout(step.wait ?? 300);
    } else if (step.wait) {
      await page.waitForTimeout(step.wait);
    } else if (step.eval) {
      await page.evaluate(step.eval).catch(e => errors.push('eval: ' + e.message));
      await page.waitForTimeout(step.waitAfter ?? 300);
    } else if (step.scroll) {
      await page.evaluate(([sel, y]) => { const els = [...document.querySelectorAll('div')].filter(d => d.scrollHeight > d.clientHeight + 4 && getComputedStyle(d).overflowY !== 'visible' && getComputedStyle(d).overflowY !== 'hidden'); const el = els[sel] || els[0]; if (el) el.scrollTop = y; }, step.scroll);
      await page.waitForTimeout(400);
    } else if (step.shot) {
      await page.waitForTimeout(step.pre ?? 250);
      shots[step.shot] = await page.screenshot({ animations: 'disabled', caret: 'hide' });
    }
  }
  await ctx.close();
  return { shots, errors };
}

const browser = await chromium.launch({ channel: 'chrome', headless: true });
const report = [];
let totDiff = 0, totPx = 0;
for (const flow of FLOWS) {
  if (filter && !flow.name.includes(filter)) continue;
  const [o, a] = await Promise.all([run(browser, ORIG, flow), run(browser, APP, flow)]);
  for (const name of Object.keys(o.shots)) {
    const A = PNG.sync.read(o.shots[name]);
    const B = a.shots[name] ? PNG.sync.read(a.shots[name]) : null;
    let pct = 0, diff = 0;
    if (B && B.width === A.width && B.height === A.height) {
      const d = new PNG({ width: A.width, height: A.height });
      diff = pixelmatch(A.data, B.data, d.data, A.width, A.height, { threshold: 0.1 });
      pct = 100 - (diff / (A.width * A.height)) * 100;
      if (diff) {
        fs.writeFileSync(path.join(OUT, `${flow.name}__${name}__diff.png`), PNG.sync.write(d));
        fs.writeFileSync(path.join(OUT, `${flow.name}__${name}__orig.png`), o.shots[name]);
        fs.writeFileSync(path.join(OUT, `${flow.name}__${name}__app.png`), a.shots[name]);
      }
    } else diff = A.width * A.height;
    if (process.env.SAVE) { fs.writeFileSync(path.join(OUT, `${flow.name}__${name}__orig.png`), o.shots[name]); if (a.shots[name]) fs.writeFileSync(path.join(OUT, `${flow.name}__${name}__app.png`), a.shots[name]); }
    totDiff += diff; totPx += A.width * A.height;
    report.push({ flow: flow.name, shot: name, igualdade: pct.toFixed(2) + '%' });
  }
  if (o.errors.length || a.errors.length) report.push({ flow: flow.name, errosOriginal: o.errors, errosApp: a.errors });
}
await browser.close();
console.table(report.filter(r => r.shot));
for (const r of report.filter(r => !r.shot)) console.log(JSON.stringify(r));
console.log('IGUALDADE GERAL:', (100 - (totDiff / totPx) * 100).toFixed(3) + '%');
