// Fluxos de comparação app × protótipo. Cada `shot` vira um ponto de checagem pixel a pixel.
const LOGGED = `(() => { localStorage.setItem('takeat-academy-v0', JSON.stringify({ v: 1, session: { email: 'ana.prado@takeat.app' }, remembered: 'ana.prado@takeat.app', users: { 'ana.prado@takeat.app': { pwd: 'segredo', team: 'Suporte', birth: '10/04/1995' } }, onboarded: true, persona: 'cs', objetivo: 'chegando', goalMin: 5, reminder: '09:30', workDays: [1,2,3,4,5], sound: false, role: 'lider', team: 'Suporte', name: 'Ana Prado', phone: '', cargo: 'Analista de Suporte', xpTotal: 0, xpDay: {}, takitos: 120, streak: { count: 0, last: null, freezes: 1, grantWeek: null, days: [], best: 0 }, done: {}, activeTrack: 'FUN', league: { idx: 0, week: null, seed: 1, xp: 0 }, day: {}, month: {}, badges: [], certs: [], hl: {}, errors: {}, stats: { ans: 0, ok: 0 }, flashRecord: 0, boostUntil: 0, owned: ['m-bronze'], equipped: 'metal:bronze', dayOffset: 0, nudged: {}, offlineSim: false, levelTest: null })); })()`;

const demo = name => ({ name: 'demo-' + name, steps: [{ goto: '?demo=' + name, settle: 1200 }, { shot: name }] });

export const FLOWS = [
  ...['splash', 'login', 'loginErr', 'temp', 'tempSent', 'first', 'onb0', 'onb1', 'onb2', 'onb3', 'onb4', 'loading', 'path'].map(demo),
  {
    name: 'login-real',
    steps: [
      { goto: '', settle: 2600 },
      { shot: 'login' },
      { fill: ['input[type=email]', 'joao.silva@takeat.app'] },
      { fill: ['input[autocomplete=current-password]', 'errada'] },
      { click: 'Entrar', exact: true, wait: 600 },
      { shot: 'erro' },
      { fill: ['input[autocomplete=current-password]', 'academy123'] },
      { click: 'Entrar', exact: true, wait: 1400 },
      { shot: 'primeiro-acesso' },
      { click: 'Esqueci minha senha', wait: 200 },
    ],
  },
  {
    name: 'esqueci',
    steps: [
      { goto: '', settle: 2600 },
      { fill: ['input[type=email]', 'joao.silva@takeat.app'] },
      { click: 'Esqueci minha senha', wait: 500 },
      { shot: 'modal' },
    ],
  },
  {
    name: 'onboarding',
    steps: [
      { goto: '?demo=onb0', settle: 1000 },
      { click: 'Produto', wait: 300 }, { shot: 'persona' },
    ],
  },
  {
    name: 'abas',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { shot: 'aprender' },
      { click: 'Praticar', exact: true, wait: 700 }, { shot: 'praticar' },
      { click: 'Ligas', exact: true, wait: 1200 }, { shot: 'ligas' },
      { click: 'Missões', exact: true, wait: 700 }, { shot: 'missoes' },
      { click: 'Perfil', exact: true, wait: 700 }, { shot: 'perfil' },
    ],
  },
  {
    name: 'licao',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: { css: '[data-current="true"]' }, wait: 600 }, { shot: 'popover' },
      { click: 'Começar', exact: true, wait: 800 }, { shot: 'inicio' },
    ],
  },
];

// Passo genérico de lição: avança feedback/dicas, verifica quando possível ou interage com o exercício.
export const STEP = `(() => {
  const vis = b => b.offsetParent && !b.disabled && b.getBoundingClientRect().height > 0;
  const btns = [...document.querySelectorAll('button')].filter(vis);
  const by = re => btns.find(b => re.test(b.innerText.trim()));
  const hit = by(/^(Continuar|Entendi, vamos lá|Entendi|Coletar|Continuar a lição)$/) || by(/^Verificar$/);
  if (hit) { hit.click(); return 'ok:' + hit.innerText.trim(); }
  const setv = (el, v) => { const pr = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(pr, 'value').set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); };
  const inp = [...document.querySelectorAll('input')].find(i => i.offsetParent && !i.value);
  if (inp) { setv(inp, inp.inputMode === 'decimal' || inp.type === 'number' ? '10' : 'teste'); return 'fill'; }
  const opts = btns.filter(b => b.innerText.trim().length > 1 && !/Sair|Por quê|Verificar|Fechar/.test(b.innerText) && b.getBoundingClientRect().top > 90 && b.getBoundingClientRect().bottom < innerHeight - 90);
  window.__k = (window.__k || 0) + 1; const pick = opts[(window.__k * 5 + (window.__k >> 2)) % Math.max(1, opts.length)];
  if (pick) { pick.click(); return 'opt'; }
  const any = [...document.querySelectorAll('[role=button],div[style*="cursor: pointer"],span[style*="cursor: pointer"]')].filter(e => e.offsetParent)[0];
  if (any) { any.click(); return 'any'; }
  return 'none';
})()`;
const S = { eval: STEP, waitAfter: 450 };
const L = (n, tag) => ({ loop: n, steps: [S, { shot: tag }] });

FLOWS.push(
  {
    name: 'licao-completa',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: { css: '[data-current="1"]' }, wait: 700 }, { shot: 'popover' },
      { click: 'Começar', exact: true, wait: 900 }, { shot: 'dica' },
      L(70, 'passo'),
    ],
  },
  {
    name: 'sheets',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Fundamentos', exact: true, wait: 600 }, { shot: 'trilhas' },
      { press: 'Escape' }, { goto: '', settle: 3500 },
      { click: { css: 'button:has(lu-icon[name=flame])' }, wait: 600 }, { shot: 'ofensiva' },
      { goto: '', settle: 3500 },
      { click: { css: 'button:has(img[width="20"])' }, wait: 600 }, { shot: 'takitos' },
      { click: 'Gastar seus Takitos na Loja', wait: 800 }, { shot: 'loja' },
      { scroll: [0, 700] }, { shot: 'loja-scroll' },
    ],
  },
  {
    name: 'perfil',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Perfil', exact: true, wait: 700 }, { scroll: [0, 600] }, { shot: 'meio' }, { scroll: [0, 1400] }, { shot: 'baixo' }, { scroll: [0, 3000] }, { shot: 'fim' },
      { click: 'Configurações', wait: 700 }, { shot: 'config' },
    ],
  },
  {
    name: 'lider',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Perfil', exact: true, wait: 700 },
      { click: 'Abrir modo líder', wait: 800 }, { shot: 'lider' },
      { click: 'Regras', exact: true, wait: 600 }, { shot: 'regras' },
      { click: 'Modelo de resposta de impressão', wait: 600 }, { shot: 'regra-aberta' },
      { click: 'Nova questão', wait: 600 }, { shot: 'nova-questao' },
      { click: 'Gerar com Hubia', wait: 1500 }, { shot: 'hubia' },
      { click: 'Adicionar questão', wait: 800 }, { shot: 'questao-add' },
      { click: 'Publicar', exact: true, wait: 800 }, { shot: 'publicada' },
      { click: 'Nova regra', wait: 600 }, { shot: 'nova-regra' },
      { click: 'Obrigatória', exact: true, wait: 600 }, { shot: 'obrigatoria' },
      { click: 'Painel', exact: true, wait: 600 }, { shot: 'painel' },
    ],
  },
  {
    name: 'praticar',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Praticar', exact: true, wait: 700 },
      { click: 'Glossário', exact: true, wait: 700 }, { shot: 'glossario' },
      { click: 'Praticar este termo', wait: 900 }, { shot: 'termo' },
      { goto: '', settle: 3500 }, { click: 'Praticar', exact: true, wait: 700 },
      { click: 'Desafio relâmpago', exact: true, wait: 900 }, { shot: 'relampago' },
      { loop: 6, steps: [S] }, { shot: 'relampago-jogo' },
    ],
  },
  {
    name: 'ligas',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Ligas', exact: true, wait: 1300 }, { scroll: [0, 900] }, { shot: 'lista' },
      { click: 'Meu time', wait: 900 }, { shot: 'meu-time' },
      { click: 'Debug · encerrar semana', wait: 1200 }, { shot: 'resultado' },
    ],
  },
  {
    name: 'missoes',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Missões', exact: true, wait: 700 }, { scroll: [0, 800] }, { shot: 'baixo' },
      { click: 'Abrir o baú do dia', wait: 2500 }, { shot: 'bau' },
      { wait: 1500 }, { shot: 'bau-aberto' },
      { click: 'Coletar', wait: 1800 }, { shot: 'coletado' },
      { click: 'Perfil', exact: true, wait: 700 }, { click: 'Debug · avançar dia', wait: 900 }, { shot: 'dia' },
    ],
  },
  {
    name: 'certificado',
    steps: [
      { goto: '' }, { eval: LOGGED }, { goto: '', settle: 3500 },
      { click: 'Perfil', exact: true, wait: 700 },
      { click: 'Ver modelo do certificado', wait: 1200 }, { shot: 'cert' },
    ],
  },
);
