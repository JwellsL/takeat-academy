// Converte o template do protótipo (tools/prototype.dc.html) em JSX React (src/View.jsx).
// O protótipo HTML é a fonte da verdade: a conversão é mecânica e 1:1 com o runtime
// original (sc-if, sc-for, {{ caminho }}, sc-camel-*, style-active/style-hover).
// Rode `npm run convert` sempre que o template do protótipo mudar.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseFragment } from 'parse5';
import * as prettier from 'prettier';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const src = fs.readFileSync(path.join(root, 'tools/prototype.dc.html'), 'utf8');
const frag = parseFragment(src);

const pseudo = new Map(); // "active|css" -> className
const pseudoCss = [];
function importantify(css) {
  return css.split(';').map(d => d.trim()).filter(Boolean)
    .map(d => (/!important\s*$/.test(d) ? d : d + ' !important')).join(';');
}
function pseudoClass(kind, css) {
  const k = kind + '|' + css;
  if (pseudo.has(k)) return pseudo.get(k);
  const cls = 'scp' + pseudo.size.toString(36);
  pseudo.set(k, cls);
  pseudoCss.push('.' + cls + ':' + kind + '{' + importantify(css) + '}');
  return cls;
}

const kebabToCamel = s => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
const IDENT = /^[A-Za-z_$][\w$]*(\.[A-Za-z_$\d][\w$]*)*$/;

// Escopo: nomes de variáveis de loop (sc-for as="o") viram variáveis locais;
// todo o resto vem de `v` (renderVals).
function expr(raw, scope) {
  const e = raw.trim();
  if (e === 'true' || e === 'false' || e === 'null') return e;
  if (!IDENT.test(e)) throw new Error('Expressão não suportada: ' + e);
  const parts = e.split('.');
  const head = scope.includes(parts[0]) ? parts[0] : 'v.' + parts[0];
  return [head, ...parts.slice(1)].join('?.');
}
const WHOLE = /^\s*\{\{([\s\S]+?)\}\}\s*$/;
function attrExpr(raw, scope) {
  const m = raw.match(WHOLE);
  if (m) return expr(m[1], scope);
  if (raw.includes('{{')) {
    const parts = raw.split(/\{\{([\s\S]+?)\}\}/g);
    return '`' + parts.map((p, i) => (i & 1 ? '${S(' + expr(p, scope) + ')}' : p.replace(/[`\\$]/g, c => '\\' + c))).join('') + '`';
  }
  return null; // estático
}
function cssToObj(css) {
  const o = {};
  for (const decl of css.split(';')) {
    const i = decl.indexOf(':');
    if (i < 0) continue;
    const p = decl.slice(0, i).trim();
    o[p.startsWith('--') ? p : kebabToCamel(p)] = decl.slice(i + 1).trim();
  }
  return o;
}

const SVG_TAGS = new Set(['svg', 'circle', 'line', 'path', 'rect', 'g', 'polyline', 'polygon', 'defs', 'linearGradient', 'stop', 'text']);
const REACT_NAMES = {
  class: 'className', for: 'htmlFor', autocomplete: 'autoComplete', inputmode: 'inputMode', maxlength: 'maxLength',
  minlength: 'minLength', tabindex: 'tabIndex', readonly: 'readOnly', autofocus: 'autoFocus', enterkeyhint: 'enterKeyHint',
  crossorigin: 'crossOrigin', spellcheck: 'spellCheck', autocapitalize: 'autoCapitalize', accept: 'accept', multiple: 'multiple',
};
const isCustom = tag => tag.includes('-');

function attrsOf(node, scope) {
  const out = [];
  const classes = [];
  for (const { name, value } of node.attrs) {
    if (name === 'data-dc-tpl' || name === 'sc-name' || name === 'hint-size') continue;
    if (name.startsWith('style-')) { classes.push(pseudoClass(name.slice(6), value)); continue; }
    let key = name;
    if (key.startsWith('sc-camel-')) key = kebabToCamel(key.slice(9));
    else if (!isCustom(node.tagName)) {
      if (REACT_NAMES[key]) key = REACT_NAMES[key];
      else if (SVG_TAGS.has(node.tagName) && key.includes('-')) key = kebabToCamel(key);
    } else if (key === 'class') key = 'class';
    const dyn = attrExpr(value, scope);
    if (key === 'style') {
      out.push(dyn ? `style={css(${dyn})}` : `style={${JSON.stringify(cssToObj(value))}}`);
      continue;
    }
    if (dyn) {
      if (key === 'value' || key === 'checked') out.push(`${key}={D(${dyn}, ${key === 'checked' ? 'false' : "''"})}`);
      else out.push(`${key}={${dyn}}`);
    } else {
      out.push(`${key}=${JSON.stringify(value)}`);
    }
  }
  if (classes.length) out.push(`className=${JSON.stringify(classes.join(' '))}`);
  return out;
}

let loopN = 0;
function children(node, scope, depth) {
  return (node.childNodes || []).map(c => walk(c, scope, depth)).filter(x => x != null);
}
function wrapKids(kids) { return kids.length ? kids.join('') : ''; }

function walk(node, scope, depth) {
  if (node.nodeName === '#text') {
    const t = node.value;
    if (!t.includes('{{')) {
      if (!t.trim() && !t.includes(' ')) return null;
      return `{${JSON.stringify(t)}}`;
    }
    const parts = t.split(/\{\{([\s\S]+?)\}\}/g);
    return parts.map((p, i) => (i & 1 ? `{T(${expr(p, scope)})}` : p ? `{${JSON.stringify(p)}}` : '')).join('');
  }
  if (node.nodeName === '#comment') return null;
  const tag = node.tagName;
  if (!tag) return null;
  const get = n => (node.attrs.find(a => a.name === n) || {}).value;
  if (tag === 'sc-if') {
    const cond = attrExpr(get('value') || '', scope) || 'undefined';
    return `{${cond} ? <>${wrapKids(children(node, scope, depth))}</> : null}`;
  }
  if (tag === 'sc-for') {
    const list = attrExpr(get('list') || '', scope) || 'undefined';
    const as = get('as') || 'item';
    const idx = '$i' + loopN++;
    const kids = wrapKids(children(node, scope.concat([as]), depth + 1));
    return `{L(${list}).map((${as}, ${idx}) => <Fragment key={${idx}}>${kids}</Fragment>)}`;
  }
  const kids = node.tagName === 'template' ? children(node.content, scope, depth) : children(node, scope, depth);
  const attrs = attrsOf(node, scope).join(' ');
  const open = attrs ? `<${tag} ${attrs}` : `<${tag}`;
  return kids.length ? `${open}>${kids.join('')}</${tag}>` : `${open} />`;
}

const body = children(frag, [], 0).join('');
const out = `// GERADO por tools/dc2jsx.mjs a partir do protótipo — não edite à mão.
// Para mudar a interface, edite tools/prototype.dc.html e rode \`npm run convert\`.
import React, { Fragment } from 'react';
import './pseudo.css';

const kebab = s => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
// Mesmas regras do runtime do protótipo.
function css(str) {
  const o = {};
  for (const d of String(str).split(';')) {
    const i = d.indexOf(':');
    if (i < 0) continue;
    const p = d.slice(0, i).trim();
    o[p.startsWith('--') ? p : kebab(p)] = d.slice(i + 1).trim();
  }
  return o;
}
const S = x => (x == null ? '' : x);
const D = (x, d) => (x === undefined ? d : x);
const L = x => (Array.isArray(x) ? x : []);
function T(x) {
  if (x === undefined || x === null || typeof x === 'boolean') return null;
  if (React.isValidElement(x) || Array.isArray(x)) return x;
  return <span className="sc-interp">{String(x)}</span>;
}

export default function View({ v }) {
  return <>${body}</>;
}
`;
const formatted = await prettier.format(out, { parser: 'babel', printWidth: 140, singleQuote: true });
fs.writeFileSync(path.join(root, 'src/View.jsx'), formatted);
fs.writeFileSync(path.join(root, 'src/pseudo.css'), '/* GERADO por tools/dc2jsx.mjs */\n' + pseudoCss.join('\n') + '\n');
console.log('View.jsx gerado:', formatted.length, 'bytes ·', pseudo.size, 'pseudo-classes');
