import { chromium } from 'playwright-core';
const UID = '11111111-1111-1111-1111-111111111111';
let saldo = 500, salvo = null, ledger = [];
const b = await chromium.launch({ channel: 'chrome' });
const ctx = await b.newContext({ viewport: { width: 412, height: 915 }, hasTouch: true, isMobile: true });
await ctx.addInitScript(([uid]) => {
  const exp = Math.floor(Date.now() / 1000) + 3600 * 24;
  localStorage.setItem('takeat-academy-auth', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: exp, expires_in: 86400, token_type: 'bearer', user: { id: uid, email: 'joao.lucas@takeat.app', user_metadata: {}, aud: 'authenticated', role: 'authenticated' } }));
  if (!localStorage.getItem('takeat-academy-v0')) localStorage.setItem('takeat-academy-v0', JSON.stringify({ v: 1, session: { email: 'joao.lucas@takeat.app' }, uid, onboarded: false, team: 'Tecnologia', name: 'João Lucas', takitos: 120, league: { idx: 0, week: null, seed: 1, xp: 0 } }));
}, [UID]);
await ctx.route('**/rest/v1/**', async route => {
  const u = route.request().url(), body = route.request().postDataJSON?.() || {};
  const j = d => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(d) });
  if (u.includes('/profiles')) return j({ full_name: 'João Lucas', team: 'Tecnologia', cargo: 'Dev', telefone: null, avatar_url: 'https://takeathub.vercel.app/molduras/metal-ouro.png', moldura: { asset: 'rpg:dragao' } });
  if (u.includes('rpc/academy_estado')) return j({ dados: salvo, atualizado_em: new Date().toISOString(), saldo });
  if (u.includes('rpc/academy_salvar')) { salvo = body.p_dados; console.log('  salvar -> liga_xp', body.p_liga_xp, 'resumo', JSON.stringify(body.p_resumo), 'pos FUN', body.p_posicoes && body.p_posicoes.FUN); return j({ ok: true }); }
  if (u.includes('rpc/academy_takitos')) { ledger.push(body); saldo += body.p_delta; return j({ ok: true, saldo }); }
  if (u.includes('rpc/academy_ranking')) return j([
    { user_id: UID, nome: 'João Lucas', equipe: 'Tecnologia', liga_xp: 0, liga_idx: 0, posicoes: {}, resumo: {}, eu: true },
    { user_id: '2', nome: 'Maria Real', equipe: 'Suporte', avatar_url: null, moldura: 'metal:prata', liga_xp: 80, liga_idx: 0, posicoes: { FUN: 'FUN:0:0' }, resumo: { licoesSemana: 3, ofensiva: 4 }, eu: false },
  ]);
  return j([]);
});
const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
await p.goto('http://localhost:5181/'); await p.waitForTimeout(5000);
const txt = () => p.locator('body').innerText();
console.log('1. entrou direto no app (sem onboarding):', (await txt()).includes('Aprender'), '| Quem é você?', (await txt()).includes('Quem é você'));
console.log('2. saldo mostrado = Hub (500):', (await txt()).includes('500'));
saldo = 100500; // depósito no Hub
await p.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); await p.waitForTimeout(1500);
console.log('3. depósito refletiu (100500):', (await txt()).includes('100500') || (await txt()).includes('100.500'));
await p.getByText('Ligas', { exact: true }).click(); await p.waitForTimeout(2000);
const t = await txt();
console.log('4. ranking real:', t.includes('Maria Real'), '| sem mock (Bruno Lima?):', !t.includes('Bruno Lima'), '| simulador oculto:', !t.includes('Simular minha'));
await p.screenshot({ path: 'tools/c1.png' });
await p.getByText('Aprender', { exact: true }).click(); await p.waitForTimeout(1500);
await p.screenshot({ path: 'tools/c2.png' });
const av = await p.evaluate(() => [...document.querySelectorAll('span')].some(s => (s.style.background || '').includes('metal-ouro')));
console.log('6. foto do Hub no avatar:', av);
console.log('5. salvo na nuvem:', !!salvo, '| ledger', JSON.stringify(ledger));
console.log('erros', errs); await b.close();
