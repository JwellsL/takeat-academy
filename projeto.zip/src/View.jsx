// GERADO por tools/dc2jsx.mjs a partir do protótipo — não edite à mão.
// Para mudar a interface, edite tools/prototype.dc.html e rode `npm run convert`.
import React, { Fragment } from 'react';
import './pseudo.css';

const kebab = (s) => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
// Mesmas regras do runtime do protótipo.
function css(str) {
  const o = {};
  for (const d of String(str).split(';')) {
    const i = d.indexOf(':');
    if (i < 0) continue;
    const p = d.slice(0, i).trim();
    o[p.startsWith('--') ? p : kebab(p)] = d.slice(i + 1).trim();
  }
  return o;
}
const S = (x) => (x == null ? '' : x);
const D = (x, d) => (x === undefined ? d : x);
const L = (x) => (Array.isArray(x) ? x : []);
function T(x) {
  if (x === undefined || x === null || typeof x === 'boolean') return null;
  if (React.isValidElement(x) || Array.isArray(x)) return x;
  return <span className="sc-interp">{String(x)}</span>;
}

export default function View({ v }) {
  return (
    <>
      <div
        style={{
          minHeight: '100dvh',
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'hsl(0 0% 93%)',
          fontFamily: 'Poppins,sans-serif',
          color: 'hsl(0 0% 13%)',
        }}
      >
        <div
          ref={v.frameRef}
          style={{
            position: 'relative',
            width: 'min(100vw,390px)',
            height: 'min(100dvh,844px)',
            background: 'hsl(0 0% 98%)',
            overflow: 'hidden',
            borderRadius: 'max(0px, min(30px, calc((100vw - 391px) * 999)))',
            boxShadow: '0 12px 34px rgba(0,0,0,.14)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {v.isSplash ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  background: '#df1c0d',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '16px',
                  overflow: 'hidden',
                  zIndex: '90',
                }}
              >
                {'\n  '}
                <div
                  style={{
                    position: 'absolute',
                    inset: '0',
                    background: 'linear-gradient(135deg,rgba(255,255,255,.10),rgba(0,0,0,.34) 135%)',
                  }}
                />
                {'\n  '}
                <div
                  style={{
                    position: 'absolute',
                    right: '-60px',
                    top: '40px',
                    width: '260px',
                    height: '260px',
                    background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                    filter: 'brightness(0) invert(1)',
                    opacity: '.12',
                    animation: 'floatA 11s ease-in-out infinite',
                  }}
                />
                {'\n  '}
                <div
                  style={{
                    position: 'absolute',
                    left: '-50px',
                    bottom: '60px',
                    width: '200px',
                    height: '200px',
                    background: 'url("assets/shape-b.svg") center/contain no-repeat',
                    filter: 'brightness(0) invert(1)',
                    opacity: '.10',
                    animation: 'floatB 10s ease-in-out infinite',
                  }}
                />
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    width: '108px',
                    height: '108px',
                    background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                    filter: 'brightness(0) invert(1)',
                    animation: 'popIn .7s cubic-bezier(.34,1.56,.64,1) both',
                  }}
                />
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    lineHeight: '1',
                    animation: 'rise .6s .25s both',
                  }}
                >
                  <span style={{ fontSize: '32px', fontWeight: '800', color: '#fff', letterSpacing: '-.02em' }}>{'TakeatHub'}</span>
                  <span
                    style={{ fontFamily: "'Dancing Script',cursive", fontSize: '38px', fontWeight: '700', color: '#fff', marginTop: '2px' }}
                  >
                    {'Academy'}
                  </span>
                </div>
                {'\n  '}
                <div
                  style={{
                    position: 'absolute',
                    bottom: '48px',
                    width: '22px',
                    height: '22px',
                    border: '2.5px solid rgba(255,255,255,.4)',
                    borderTopColor: '#fff',
                    borderRadius: '50%',
                    animation: 'spin .7s linear infinite',
                  }}
                />
              </div>
            </>
          ) : null}
          {v.isLogin ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column',
                  background: '#f7f7f8',
                  animation: 'fadeIn .35s both',
                }}
              >
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    flex: '1',
                    minHeight: '0',
                    background: '#df1c0d',
                    padding: '22px 24px 26px',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    gap: '20px',
                  }}
                >
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      inset: '-16%',
                      transform: 'rotate(-8deg)',
                      pointerEvents: 'none',
                      background: 'url("assets/takeat-mark.png") 0 0/72px 72px repeat',
                      filter: 'brightness(0) invert(1)',
                      opacity: '.07',
                    }}
                  />
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      right: '-40px',
                      top: '-20px',
                      width: '230px',
                      height: '230px',
                      background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                      filter: 'brightness(0) invert(1) drop-shadow(0 30px 40px rgba(0,0,0,.3))',
                      opacity: '.20',
                      animation: 'floatA 11s ease-in-out infinite',
                    }}
                  />
                  {'\n    '}
                  <img
                    src="assets/shape-a.svg"
                    alt=""
                    style={{
                      position: 'absolute',
                      right: '40px',
                      bottom: '-30px',
                      width: '120px',
                      opacity: '.24',
                      animation: 'floatB 12s ease-in-out infinite',
                    }}
                  />
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      inset: '0',
                      pointerEvents: 'none',
                      background: 'linear-gradient(135deg,rgba(255,255,255,.10),rgba(0,0,0,.34) 135%)',
                    }}
                  />
                  {'\n    '}
                  <div
                    style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '12px', animation: 'rise .6s ease both' }}
                  >
                    {'\n      '}
                    <span
                      style={{
                        width: '36px',
                        height: '36px',
                        display: 'inline-block',
                        background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                        filter: 'brightness(0) invert(1)',
                      }}
                    />
                    {'\n      '}
                    <span
                      style={{
                        fontFamily: "'Dancing Script',cursive",
                        fontSize: '32px',
                        fontWeight: '700',
                        color: '#fff',
                        lineHeight: '1',
                      }}
                    >
                      {'Academy'}
                    </span>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div style={{ position: 'relative' }}>
                    {'\n      '}
                    <div
                      style={{
                        fontSize: '12px',
                        fontWeight: '600',
                        letterSpacing: '.15em',
                        textTransform: 'uppercase',
                        color: 'rgba(255,255,255,.72)',
                        marginBottom: '12px',
                        animation: 'rise .6s .05s ease both',
                      }}
                    >
                      {'Plataforma interna Takeat'}
                    </div>
                    {'\n      '}
                    <div style={{ fontSize: '31px', lineHeight: '1', letterSpacing: '-.035em', color: '#0d0d0d' }}>
                      {'\n        '}
                      <div style={{ fontWeight: '500', opacity: '.82', animation: 'rise .7s .12s ease both' }}>{'Todo o produto.'}</div>
                      {'\n        '}
                      <div style={{ fontWeight: '800', animation: 'rise .7s .22s ease both' }}>{'Cinco minutos.'}</div>
                      {'\n        '}
                      <div style={{ fontWeight: '500', opacity: '.82', animation: 'rise .7s .32s ease both' }}>{'Todo dia.'}</div>
                      {'\n      '}
                    </div>
                    {'\n    '}
                  </div>
                  {'\n  '}
                </div>
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    flex: 'none',
                    padding: '24px 24px calc(28px + env(safe-area-inset-bottom))',
                    display: 'flex',
                    flexDirection: 'column',
                    animation: 'rise .55s .15s ease both',
                  }}
                >
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      color: '#6b6b6b',
                      fontSize: '13px',
                      fontWeight: '500',
                      marginBottom: '12px',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    <lu-icon name="lock" size="15" />
                    <span>{'Acesso interno'}</span>
                  </div>
                  {'\n    '}
                  <h1
                    style={{
                      margin: '0 0 28px',
                      fontSize: '31px',
                      fontWeight: '800',
                      lineHeight: '1.05',
                      letterSpacing: '-.03em',
                      color: '#141414',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {'Acesse sua '}
                    <span style={{ color: '#df1c0d' }}>{'conta.'}</span>
                  </h1>
                  {'\n    '}
                  <div style={{ marginBottom: '20px' }}>
                    {'\n      '}
                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '9px' }}>
                      {'E-mail '}
                      <span style={{ color: '#df1c0d' }}>{'*'}</span>
                    </label>
                    {'\n      '}
                    <input
                      type="email"
                      autoComplete="username"
                      inputMode="email"
                      placeholder="Digite seu e-mail"
                      value={D(v.lgEmail, '')}
                      onChange={v.onLgEmail}
                      onKeyDown={v.onLgKey}
                      style={{
                        width: '100%',
                        height: '56px',
                        padding: '0 16px',
                        borderRadius: '12px',
                        fontSize: '15px',
                        border: '1.5px solid #e5e5e7',
                        background: '#fff',
                        color: '#141414',
                      }}
                    />
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div style={{ marginBottom: '20px' }}>
                    {'\n      '}
                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '9px' }}>
                      {'Senha '}
                      <span style={{ color: '#df1c0d' }}>{'*'}</span>
                    </label>
                    {'\n      '}
                    <div style={{ position: 'relative' }}>
                      {'\n        '}
                      <input
                        type={v.lgPwdType}
                        autoComplete="current-password"
                        placeholder="Digite sua senha"
                        value={D(v.lgPwd, '')}
                        onChange={v.onLgPwd}
                        onKeyDown={v.onLgKey}
                        style={{
                          width: '100%',
                          height: '56px',
                          padding: '0 52px 0 16px',
                          borderRadius: '12px',
                          fontSize: '15px',
                          border: '1.5px solid #e5e5e7',
                          background: '#fff',
                          color: '#141414',
                        }}
                      />
                      {'\n        '}
                      <button
                        type="button"
                        onClick={v.toggleShow}
                        aria-label="Mostrar senha"
                        style={{
                          position: 'absolute',
                          right: '6px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          width: '44px',
                          height: '44px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: 'none',
                          background: 'none',
                          color: '#6b6b6b',
                          cursor: 'pointer',
                        }}
                      >
                        <lu-icon name={v.lgEyeIcon} size="19" />
                      </button>
                      {'\n      '}
                    </div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      margin: '0 0 24px',
                      flexWrap: 'wrap',
                    }}
                  >
                    {'\n      '}
                    <button
                      type="button"
                      onClick={v.toggleRemember}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '9px',
                        border: 'none',
                        background: 'none',
                        cursor: 'pointer',
                        padding: '0',
                        minHeight: '44px',
                        color: '#141414',
                        fontSize: '13.5px',
                        fontWeight: '500',
                      }}
                    >
                      {'\n        '}
                      <span
                        style={{
                          width: '19px',
                          height: '19px',
                          borderRadius: '5px',
                          border: '1.5px solid #e5e5e7',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          overflow: 'hidden',
                          background: '#fff',
                        }}
                      >
                        {'\n          '}
                        {v.lgRemember ? (
                          <>
                            <span
                              style={{
                                width: '100%',
                                height: '100%',
                                background: '#df1c0d',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: '#fff',
                              }}
                            >
                              <lu-icon name="check" size="12" stroke="3.4" />
                            </span>
                          </>
                        ) : null}
                        {'\n        '}
                      </span>
                      {'\n        '}
                      <span style={{ whiteSpace: 'nowrap' }}>{'Lembrar meu e-mail'}</span>
                      {'\n      '}
                    </button>
                    {'\n      '}
                    <button
                      type="button"
                      onClick={v.onForgot}
                      style={{
                        border: 'none',
                        background: 'none',
                        cursor: 'pointer',
                        padding: '0',
                        minHeight: '44px',
                        color: '#df1c0d',
                        fontSize: '13.5px',
                        fontWeight: '600',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {'Esqueci minha senha'}
                    </button>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  {v.hasLgErr ? (
                    <>
                      <div
                        style={{
                          margin: '-8px 0 16px',
                          fontSize: '13px',
                          fontWeight: '500',
                          color: '#df1c0d',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                        }}
                      >
                        <lu-icon name="circle-x" size="15" />
                        {T(v.lgErr)}
                      </div>
                    </>
                  ) : null}
                  {'\n    '}
                  <button
                    type="button"
                    onClick={v.onLogin}
                    style={{
                      width: '100%',
                      height: '60px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '10px',
                      border: 'none',
                      borderRadius: '12px',
                      background: '#df1c0d',
                      color: '#fff',
                      fontSize: '16px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      boxShadow: '0 10px 24px color-mix(in srgb, #df1c0d 32%, transparent)',
                      transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                    }}
                    className="scp0"
                  >
                    {'\n      '}
                    {v.lgLoading ? (
                      <>
                        <span
                          style={{
                            width: '18px',
                            height: '18px',
                            border: '2.5px solid rgba(255,255,255,.4)',
                            borderTopColor: '#fff',
                            borderRadius: '50%',
                            animation: 'spin .7s linear infinite',
                          }}
                        />
                        <span>{'Entrando...'}</span>
                      </>
                    ) : null}
                    {'\n      '}
                    {v.lgIdle ? (
                      <>
                        <span>{'Entrar'}</span>
                        <lu-icon name="arrow-right" size="19" stroke="2.4" />
                      </>
                    ) : null}
                    {'\n    '}
                  </button>
                  {'\n    \n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.isOnb ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  background: 'hsl(0 0% 98%)',
                  animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                }}
              >
                {'\n  '}
                <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '12px', padding: '14px 16px' }}>
                  {'\n    '}
                  <button
                    onClick={v.onbBack}
                    disabled={v.onbDisabledBack}
                    aria-label="Voltar"
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '12px',
                      border: '1px solid hsl(0 0% 90%)',
                      background: '#fff',
                      color: 'hsl(0 0% 46%)',
                      display: 'grid',
                      placeItems: 'center',
                      cursor: 'pointer',
                      opacity: '1',
                    }}
                  >
                    <lu-icon name="chevron-left" size="20" />
                  </button>
                  {'\n    '}
                  <div style={{ flex: '1', height: '10px', borderRadius: '999px', background: 'hsl(0 0% 92%)', overflow: 'hidden' }}>
                    <div
                      style={css(
                        `height:100%;width:${S(v.onbPct)};background:hsl(6 91% 47%);border-radius:999px;transition:width .45s cubic-bezier(.34,1.56,.64,1)`,
                      )}
                    />
                  </div>
                  {'\n  '}
                </div>
                {'\n  '}
                <div style={{ flex: '1', overflowY: 'auto', padding: '8px 20px 24px' }}>
                  {'\n    '}
                  {v.onb0 ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <h2 style={{ margin: '0 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>
                          {'Quem é você?'}
                        </h2>
                        {'\n        '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                          {'Sua função define a trilha inicial e a ordem das recomendadas.'}
                        </p>
                        {'\n        '}
                        <div
                          style={{
                            fontSize: '11px',
                            fontWeight: '700',
                            letterSpacing: '.08em',
                            textTransform: 'uppercase',
                            color: 'hsl(0 0% 62%)',
                            marginBottom: '10px',
                          }}
                        >
                          {'Time Takeat'}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '22px' }}>
                          {'\n          '}
                          {L(v.personasInt).map((o, $i0) => (
                            <Fragment key={$i0}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `min-height:64px;display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;border:1.5px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:600;text-align:left;cursor:pointer;transform:${S(o?.tr)};transition:all .15s cubic-bezier(.16,1,.3,1)`,
                                )}
                              >
                                <span
                                  style={{
                                    width: '36px',
                                    height: '36px',
                                    borderRadius: '10px',
                                    background: 'hsl(6 91% 47% / .12)',
                                    color: 'hsl(6 91% 47%)',
                                    display: 'grid',
                                    placeItems: 'center',
                                    flex: 'none',
                                  }}
                                >
                                  <lu-icon name={o?.icon} size="18" />
                                </span>
                                {T(o?.nome)}
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n        '}
                        </div>
                        {'\n        '}
                        <div
                          style={{
                            fontSize: '11px',
                            fontWeight: '700',
                            letterSpacing: '.08em',
                            textTransform: 'uppercase',
                            color: 'hsl(0 0% 62%)',
                            marginBottom: '10px',
                          }}
                        >
                          {'Restaurante cliente'}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                          {'\n          '}
                          {L(v.personasCli).map((o, $i1) => (
                            <Fragment key={$i1}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `min-height:64px;display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;border:1.5px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:600;text-align:left;cursor:pointer;transform:${S(o?.tr)};transition:all .15s cubic-bezier(.16,1,.3,1)`,
                                )}
                              >
                                <span
                                  style={{
                                    width: '36px',
                                    height: '36px',
                                    borderRadius: '10px',
                                    background: 'hsl(0 0% 95%)',
                                    color: 'hsl(0 0% 46%)',
                                    display: 'grid',
                                    placeItems: 'center',
                                    flex: 'none',
                                  }}
                                >
                                  <lu-icon name={o?.icon} size="18" />
                                </span>
                                {T(o?.nome)}
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n        '}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.onb1 ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <h2 style={{ margin: '0 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>
                          {'Qual é o seu objetivo?'}
                        </h2>
                        {'\n        '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                          {'A gente ajusta o ritmo ao que você precisa agora.'}
                        </p>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {'\n          '}
                          {L(v.objetivos).map((o, $i2) => (
                            <Fragment key={$i2}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `min-height:72px;padding:14px 16px;border-radius:14px;border:1.5px solid ${S(o?.bd)};background:${S(o?.bg)};text-align:left;cursor:pointer;transform:${S(o?.tr)};transition:all .15s cubic-bezier(.16,1,.3,1)`,
                                )}
                              >
                                <div style={css(`font-size:15px;font-weight:700;color:${S(o?.fg)}`)}>{T(o?.t)}</div>
                                <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', marginTop: '2px' }}>{T(o?.d)}</div>
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n        '}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.onb2 ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <h2 style={{ margin: '0 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>
                          {'Sua meta diária'}
                        </h2>
                        {'\n        '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>{'Dá para trocar depois no Perfil.'}</p>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {'\n          '}
                          {L(v.goals).map((o, $i3) => (
                            <Fragment key={$i3}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `min-height:64px;padding:12px 16px;border-radius:14px;border:1.5px solid ${S(o?.bd)};background:${S(o?.bg)};display:flex;align-items:center;gap:12px;cursor:pointer;transform:${S(o?.tr)};transition:all .15s cubic-bezier(.16,1,.3,1)`,
                                )}
                              >
                                <div style={{ flex: '1', textAlign: 'left' }}>
                                  <div style={css(`font-size:15px;font-weight:700;color:${S(o?.fg)}`)}>{T(o?.t)}</div>
                                  <div style={{ fontSize: '12.5px', color: 'hsl(0 0% 46%)' }}>{T(o?.d)}</div>
                                </div>
                                <span
                                  style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px',
                                    fontSize: '12px',
                                    fontWeight: '700',
                                    padding: '4px 10px',
                                    borderRadius: '999px',
                                    background: 'hsl(40 92% 46% / .15)',
                                    color: 'hsl(32 82% 40%)',
                                  }}
                                >
                                  <lu-icon name="zap" size="13" />
                                  {T(o?.xp)}
                                </span>
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n        '}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.onb3 ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <h2 style={{ margin: '0 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>
                          {'Por onde começar?'}
                        </h2>
                        {'\n        '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                          {'Se você já usa a Takeat, o teste pula o que você já sabe.'}
                        </p>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {'\n          '}
                          {L(v.niveis).map((o, $i4) => (
                            <Fragment key={$i4}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `min-height:84px;padding:14px 16px;border-radius:14px;border:1.5px solid ${S(o?.bd)};background:${S(o?.bg)};display:flex;align-items:center;gap:14px;text-align:left;cursor:pointer;transform:${S(o?.tr)};transition:all .15s cubic-bezier(.16,1,.3,1)`,
                                )}
                              >
                                <span
                                  style={{
                                    width: '44px',
                                    height: '44px',
                                    borderRadius: '12px',
                                    background: 'hsl(6 91% 47% / .12)',
                                    color: 'hsl(6 91% 47%)',
                                    display: 'grid',
                                    placeItems: 'center',
                                    flex: 'none',
                                  }}
                                >
                                  <lu-icon name={o?.icon} size="22" />
                                </span>
                                <div>
                                  <div style={css(`font-size:15px;font-weight:700;color:${S(o?.fg)}`)}>{T(o?.t)}</div>
                                  <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', marginTop: '2px', lineHeight: '1.45' }}>
                                    {T(o?.d)}
                                  </div>
                                </div>
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n        '}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.onb4 ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <h2 style={{ margin: '0 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>
                          {'Um lembrete no seu turno'}
                        </h2>
                        {'\n        '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                          {'Escolha o horário em que uma lição curta cabe melhor.'}
                        </p>
                        {'\n        '}
                        <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', marginBottom: '22px' }}>
                          {'\n          '}
                          <span
                            style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '12px',
                              background: 'hsl(6 91% 47% / .10)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <hubia-orb size="26" animate="" />
                          </span>
                          {'\n          '}
                          <div
                            style={{
                              background: 'hsl(0 0% 95%)',
                              borderRadius: '4px 14px 14px 14px',
                              padding: '11px 13px',
                              fontSize: '13px',
                              lineHeight: '1.5',
                            }}
                          >
                            {
                              'Oi! Eu sou a Hubia. Te mando um lembrete só nos dias de trabalho, no horário que você escolher. Se você não abrir, eu paro de insistir.'
                            }
                          </div>
                          {'\n        '}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'flex', gap: '8px' }}>
                          {'\n          '}
                          {L(v.reminders).map((o, $i5) => (
                            <Fragment key={$i5}>
                              {'\n            '}
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `flex:1;min-height:44px;padding:0;border-radius:999px;border:1px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:14px;font-weight:600;cursor:pointer;white-space:nowrap`,
                                )}
                              >
                                {T(o?.t)}
                              </button>
                              {'\n          '}
                            </Fragment>
                          ))}
                          {'\n          \n        '}
                        </div>
                        {'\n        '}
                        <div style={{ fontSize: '12px', fontWeight: '600', color: 'hsl(0 0% 46%)', marginTop: '14px' }}>
                          {'Ou digite o horário'}
                        </div>
                        {true ? (
                          <>
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '6px',
                                padding: '12px 8px',
                                borderRadius: '14px',
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                marginTop: '10px',
                                animation: 'up8 .25s both',
                              }}
                            >
                              <button
                                onClick={v.onbTime?.hDown}
                                aria-label="Menos uma hora"
                                style={{
                                  width: '36px',
                                  height: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  color: 'hsl(0 0% 46%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  cursor: 'pointer',
                                }}
                              >
                                <lu-icon name="minus" size="16" />
                              </button>
                              <input
                                value={D(v.onbTime?.hh, '')}
                                onChange={v.onbTime?.onH}
                                onFocus={v.onbTime?.focus}
                                inputMode="numeric"
                                aria-label="Hora"
                                style={{
                                  width: '62px',
                                  height: '52px',
                                  borderRadius: '10px',
                                  border: '1.5px solid hsl(0 0% 90%)',
                                  background: 'hsl(0 0% 98.5%)',
                                  fontSize: '28px',
                                  fontWeight: '800',
                                  letterSpacing: '-.02em',
                                  fontVariantNumeric: 'tabular-nums',
                                  textAlign: 'center',
                                  padding: '0',
                                  color: 'hsl(0 0% 13%)',
                                }}
                              />
                              <button
                                onClick={v.onbTime?.hUp}
                                aria-label="Mais uma hora"
                                style={{
                                  width: '36px',
                                  height: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  color: 'hsl(0 0% 46%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  cursor: 'pointer',
                                }}
                              >
                                <lu-icon name="plus" size="16" />
                              </button>
                              <span style={{ fontSize: '28px', fontWeight: '800', color: 'hsl(0 0% 62%)' }}>{':'}</span>
                              <button
                                onClick={v.onbTime?.mDown}
                                aria-label="Menos 5 minutos"
                                style={{
                                  width: '36px',
                                  height: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  color: 'hsl(0 0% 46%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  cursor: 'pointer',
                                }}
                              >
                                <lu-icon name="minus" size="16" />
                              </button>
                              <input
                                value={D(v.onbTime?.mm, '')}
                                onChange={v.onbTime?.onM}
                                onFocus={v.onbTime?.focus}
                                inputMode="numeric"
                                aria-label="Minuto"
                                style={{
                                  width: '62px',
                                  height: '52px',
                                  borderRadius: '10px',
                                  border: '1.5px solid hsl(0 0% 90%)',
                                  background: 'hsl(0 0% 98.5%)',
                                  fontSize: '28px',
                                  fontWeight: '800',
                                  letterSpacing: '-.02em',
                                  fontVariantNumeric: 'tabular-nums',
                                  textAlign: 'center',
                                  padding: '0',
                                  color: 'hsl(0 0% 13%)',
                                }}
                              />
                              <button
                                onClick={v.onbTime?.mUp}
                                aria-label="Mais 5 minutos"
                                style={{
                                  width: '36px',
                                  height: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  color: 'hsl(0 0% 46%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  cursor: 'pointer',
                                }}
                              >
                                <lu-icon name="plus" size="16" />
                              </button>
                            </div>
                          </>
                        ) : null}
                        {'\n        '}
                        <button
                          onClick={v.onAllowNotif}
                          style={{
                            marginTop: '18px',
                            minHeight: '44px',
                            padding: '0 16px',
                            borderRadius: '10px',
                            border: '1px solid hsl(6 91% 47% / .35)',
                            background: 'hsl(6 91% 47% / .06)',
                            color: 'hsl(6 91% 47%)',
                            fontSize: '13px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '8px',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          <lu-icon name="bell" size="16" />
                          {'Ativar lembretes'}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n  '}
                </div>
                {'\n  '}
                <div
                  style={{
                    flex: 'none',
                    padding: '12px 20px calc(16px + env(safe-area-inset-bottom))',
                    borderTop: '1px solid hsl(0 0% 93%)',
                    background: '#fff',
                  }}
                >
                  {'\n    '}
                  <button
                    onClick={v.onbNext}
                    disabled={v.onbDisabled}
                    style={css(
                      `width:100%;height:54px;border:none;border-radius:12px;background:${S(v.onbBtnBg)};color:${S(v.onbBtnFg)};font-size:15px;font-weight:700;cursor:pointer;box-shadow:${S(v.onbBtnSh)};transition:background .2s, color .2s, transform .25s cubic-bezier(.34,1.56,.64,1)`,
                    )}
                    className="scp0"
                  >
                    {T(v.onbNextLabel)}
                  </button>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.showHeader ? (
            <>
              <div
                style={{
                  flex: 'none',
                  position: 'relative',
                  zIndex: '30',
                  background: 'hsla(0,0%,100%,.82)',
                  backdropFilter: 'blur(16px) saturate(1.6)',
                  WebkitBackdropFilter: 'blur(16px) saturate(1.6)',
                  borderBottom: '1px solid hsl(0 0% 90%)',
                  padding: '8px 10px 8px 12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                }}
              >
                {'\n  '}
                <button
                  onClick={v.openTracks}
                  aria-label="Trocar de trilha"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    border: 'none',
                    background: 'none',
                    padding: '0',
                    cursor: 'pointer',
                    minHeight: '44px',
                    minWidth: '0',
                    flex: '1',
                    textAlign: 'left',
                  }}
                  data-comment-anchor="12e7f651fb-button"
                >
                  {'\n    '}
                  <span
                    style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '12px',
                      background: 'hsl(6 91% 47% / .12)',
                      color: 'hsl(6 91% 47%)',
                      display: 'grid',
                      placeItems: 'center',
                      flex: 'none',
                    }}
                  >
                    <lu-icon name={v.trackIcon} size="20" />
                  </span>
                  {'\n    '}
                  <span style={{ minWidth: '0' }}>
                    <span style={{ display: 'block', fontSize: '11px', color: 'hsl(0 0% 46%)', fontWeight: '500', lineHeight: '1.2' }}>
                      {'Trilha'}
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '2px',
                        fontSize: '13px',
                        fontWeight: '700',
                        lineHeight: '1.3',
                        color: 'hsl(0 0% 13%)',
                      }}
                    >
                      <span style={{ whiteSpace: 'nowrap' }}>{T(v.trackShort)}</span>
                      <lu-icon name="chevron-down" size="14" />
                    </span>
                  </span>
                  {'\n  '}
                </button>
                {'\n  '}
                <button
                  onClick={v.openStreak}
                  aria-label="Ofensiva"
                  style={css(
                    `min-height:44px;min-width:40px;padding:0 4px;flex:none;border:none;background:none;display:flex;align-items:center;gap:3px;cursor:pointer;color:${S(v.flameColor)};font-size:14px;font-weight:700`,
                  )}
                >
                  <lu-icon name="flame" size="21" fill={v.flameFill} />
                  <span style={{ color: 'hsl(0 0% 13%)', fontVariantNumeric: 'tabular-nums' }}>{T(v.streakN)}</span>
                </button>
                {'\n  '}
                <button
                  ref={v.xpRef}
                  onClick={v.openStreak}
                  aria-label="XP de hoje"
                  style={{
                    minHeight: '44px',
                    padding: '0 4px',
                    flex: 'none',
                    border: 'none',
                    background: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: '700',
                    color: 'hsl(0 0% 13%)',
                  }}
                >
                  {'\n    '}
                  <span style={{ position: 'relative', width: '28px', height: '28px', display: 'grid', placeItems: 'center' }}>
                    {'\n      '}
                    <svg width="28" height="28" viewBox="0 0 36 36" style={{ position: 'absolute', inset: '0' }}>
                      <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(0 0% 92%)" strokeWidth="3.6" />
                      <circle
                        cx="18"
                        cy="18"
                        r="15.9"
                        fill="none"
                        stroke={v.ringColor}
                        strokeWidth="3.6"
                        strokeDasharray={v.ringDash}
                        strokeLinecap="round"
                        transform="rotate(-90 18 18)"
                        style={{ transition: 'stroke-dasharray .6s cubic-bezier(.16,1,.3,1)' }}
                      />
                    </svg>
                    {'\n      '}
                    <span style={{ position: 'relative', color: 'hsl(40 92% 46%)', display: 'grid', placeItems: 'center' }}>
                      <lu-icon name="zap" size="14" fill="currentColor" />
                    </span>
                    {'\n    '}
                  </span>
                  {'\n    '}
                  <span style={{ fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                    {T(v.xpNumEl)}
                    <span style={{ color: 'hsl(0 0% 62%)', fontWeight: '500' }}>
                      {'/'}
                      {T(v.goalXp)}
                    </span>
                  </span>
                  {'\n    '}
                  {v.boostOn ? (
                    <>
                      <span
                        style={{
                          fontSize: '10px',
                          fontWeight: '800',
                          color: '#fff',
                          background: 'hsl(40 92% 46%)',
                          borderRadius: '999px',
                          padding: '1px 5px',
                        }}
                      >
                        {'x2'}
                      </span>
                    </>
                  ) : null}
                  {'\n  '}
                </button>
                {'\n  '}
                <button
                  ref={v.coinRef}
                  onClick={v.openCoins}
                  aria-label="Seus Takitos"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    borderRadius: '10px',
                    border: 'none',
                    background: 'hsl(38 92% 50% / .08)',
                    padding: '0 10px',
                    height: '44px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: 'hsl(0 0% 13%)',
                    boxShadow: 'none',
                    cursor: 'pointer',
                  }}
                >
                  <img ref={v.coinImgRef} src="assets/academy-book.png" width="20" height="20" alt="" style={{ objectFit: 'contain' }} />
                  <span style={{ fontVariantNumeric: 'tabular-nums' }}>{T(v.coinNumEl)}</span>
                </button>
              </div>
            </>
          ) : null}
          {v.isApp ? (
            <>
              <div style={{ flex: '1', minHeight: '0', display: 'flex', flexDirection: 'column', position: 'relative' }}>
                {'\n  '}
                {v.offlineBanner ? (
                  <>
                    <div
                      style={{
                        flex: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '8px 14px',
                        background: 'hsl(0 0% 13%)',
                        color: '#fff',
                        fontSize: '12px',
                        fontWeight: '500',
                      }}
                    >
                      <lu-icon name="wifi-off" size="15" />
                      {'Você está offline. O progresso fica salvo e sincroniza depois.'}
                    </div>
                  </>
                ) : null}
                {'\n\n  '}
                {v.tabLearn ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        position: 'relative',
                        display: 'flex',
                        flexDirection: 'column',
                        animation: 'fadeIn .25s both',
                      }}
                    >
                      {'\n    '}
                      {v.homeLoading ? (
                        <>
                          {'\n      '}
                          <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '18px', alignItems: 'center' }}>
                            {'\n        '}
                            <div
                              style={{
                                width: '100%',
                                height: '64px',
                                borderRadius: '16px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                width: '68px',
                                height: '62px',
                                borderRadius: '50%',
                                marginLeft: '-60px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                width: '68px',
                                height: '62px',
                                borderRadius: '50%',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                width: '68px',
                                height: '62px',
                                borderRadius: '50%',
                                marginLeft: '80px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                width: '68px',
                                height: '62px',
                                borderRadius: '50%',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n      '}
                          </div>
                          {'\n    '}
                        </>
                      ) : null}
                      {'\n    '}
                      {v.homeReady ? (
                        <>
                          {'\n    '}
                          <div
                            ref={v.pathRef}
                            onScroll={v.onPathScroll}
                            onClick={v.closePop}
                            style={{ flex: '1', minHeight: '0', overflowY: 'auto', position: 'relative', overscrollBehavior: 'contain' }}
                          >
                            {'\n      '}
                            {v.hasUnits ? (
                              <>
                                {'\n        '}
                                <div
                                  style={{
                                    position: 'sticky',
                                    top: '0',
                                    zIndex: '20',
                                    padding: '10px 12px 4px',
                                    background: 'linear-gradient(hsl(0 0% 98%) 70%,hsla(0,0%,98%,0))',
                                  }}
                                >
                                  {'\n          '}
                                  <div
                                    style={css(
                                      `position:relative;height:66px;border-radius:16px;background:${S(v.bColor)};box-shadow:0 4px 0 rgba(0,0,0,.14);overflow:hidden;transition:background .35s`,
                                    )}
                                  >
                                    {'\n            '}
                                    {v.bannerA ? (
                                      <>
                                        <div
                                          style={{
                                            position: 'absolute',
                                            inset: '0',
                                            padding: '10px 10px 10px 16px',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            animation: 'rise .35s cubic-bezier(.16,1,.3,1) both',
                                          }}
                                        >
                                          <div style={{ flex: '1', minWidth: '0', color: '#fff' }}>
                                            <div
                                              style={{
                                                fontSize: '11px',
                                                fontWeight: '700',
                                                letterSpacing: '.06em',
                                                textTransform: 'uppercase',
                                                opacity: '.85',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(v.bLabel)}
                                            </div>
                                            <div
                                              style={{
                                                fontSize: '16px',
                                                fontWeight: '700',
                                                lineHeight: '1.25',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(v.bTitle)}
                                            </div>
                                          </div>
                                          <button
                                            onClick={v.onUnitInfo}
                                            aria-label="Sobre a unidade"
                                            style={{
                                              width: '44px',
                                              height: '44px',
                                              borderRadius: '12px',
                                              border: '1.5px solid rgba(255,255,255,.4)',
                                              background: 'rgba(255,255,255,.14)',
                                              color: '#fff',
                                              display: 'grid',
                                              placeItems: 'center',
                                              cursor: 'pointer',
                                              flex: 'none',
                                            }}
                                          >
                                            <lu-icon name="book-open-text" size="19" />
                                          </button>
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n            '}
                                    {v.bannerB ? (
                                      <>
                                        <div
                                          style={{
                                            position: 'absolute',
                                            inset: '0',
                                            padding: '10px 10px 10px 16px',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            animation: 'rise .35s cubic-bezier(.16,1,.3,1) both',
                                          }}
                                        >
                                          <div style={{ flex: '1', minWidth: '0', color: '#fff' }}>
                                            <div
                                              style={{
                                                fontSize: '11px',
                                                fontWeight: '700',
                                                letterSpacing: '.06em',
                                                textTransform: 'uppercase',
                                                opacity: '.85',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(v.bLabel)}
                                            </div>
                                            <div
                                              style={{
                                                fontSize: '16px',
                                                fontWeight: '700',
                                                lineHeight: '1.25',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(v.bTitle)}
                                            </div>
                                          </div>
                                          <button
                                            onClick={v.onUnitInfo}
                                            aria-label="Sobre a unidade"
                                            style={{
                                              width: '44px',
                                              height: '44px',
                                              borderRadius: '12px',
                                              border: '1.5px solid rgba(255,255,255,.4)',
                                              background: 'rgba(255,255,255,.14)',
                                              color: '#fff',
                                              display: 'grid',
                                              placeItems: 'center',
                                              cursor: 'pointer',
                                              flex: 'none',
                                            }}
                                          >
                                            <lu-icon name="book-open-text" size="19" />
                                          </button>
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </div>
                                {'\n        '}
                                {v.showRisk ? (
                                  <>
                                    <div
                                      style={{
                                        margin: '6px 12px 0',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '10px',
                                        padding: '10px 12px',
                                        borderRadius: '12px',
                                        background: 'hsl(40 92% 46% / .15)',
                                        border: '1px solid hsl(40 92% 46% / .3)',
                                        fontSize: '12.5px',
                                        color: 'hsl(32 82% 32%)',
                                      }}
                                    >
                                      <lu-icon name="flame" size="18" />
                                      <div>
                                        <b>{'Sua ofensiva está em risco.'}</b> {T(v.riskText)}
                                      </div>
                                    </div>
                                  </>
                                ) : null}
                                {'\n        '}
                                {v.trackDone ? (
                                  <>
                                    <div
                                      style={{
                                        margin: '20px 16px 0',
                                        padding: '18px',
                                        borderRadius: '16px',
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                                        textAlign: 'center',
                                      }}
                                    >
                                      <div
                                        style={{
                                          width: '54px',
                                          height: '54px',
                                          borderRadius: '14px',
                                          margin: '0 auto 10px',
                                          background: 'linear-gradient(145deg,#FFD66B,#FF8A3D)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                        }}
                                      >
                                        <lu-icon name="trophy" size="26" />
                                      </div>
                                      <div style={{ fontSize: '16px', fontWeight: '700' }}>{'Trilha concluída'}</div>
                                      <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', marginTop: '4px' }}>
                                        {'Troque de trilha no topo ou revise em Praticar.'}
                                      </div>
                                    </div>
                                  </>
                                ) : null}
                                {'\n        '}
                                {L(v.units).map((u, $i6) => (
                                  <Fragment key={$i6}>
                                    {'\n          '}
                                    <div data-ui={u?.uiS} style={css(`opacity:${S(u?.op)};padding:12px 0 4px;transition:opacity .3s`)}>
                                      {'\n            '}
                                      {L(u?.rows).map((r, $i7) => (
                                        <Fragment key={$i7}>
                                          {'\n              '}
                                          <div style={css(`position:relative;height:100px;z-index:${S(r?.z)}`)}>
                                            {'\n                '}
                                            {r?.hasLine ? (
                                              <>
                                                <svg
                                                  width="300"
                                                  height="100"
                                                  viewBox="0 0 300 100"
                                                  style={{
                                                    position: 'absolute',
                                                    left: 'calc(50% - 150px)',
                                                    top: '47px',
                                                    zIndex: '0',
                                                    overflow: 'visible',
                                                    pointerEvents: 'none',
                                                  }}
                                                >
                                                  <line
                                                    x1={r?.lx1}
                                                    y1="100"
                                                    x2={r?.lx2}
                                                    y2="0"
                                                    stroke={r?.lc}
                                                    strokeWidth="7"
                                                    strokeLinecap="round"
                                                    pathLength="1"
                                                    style={css(`stroke-dasharray:1;stroke-dashoffset:0;animation:${S(r?.lanim)}`)}
                                                  />
                                                </svg>
                                              </>
                                            ) : null}
                                            {'\n                '}
                                            {r?.showStartTag ? (
                                              <>
                                                <div
                                                  style={css(
                                                    `position:absolute;top:-22px;left:${S(r?.left)};width:68px;display:flex;justify-content:center;z-index:3;pointer-events:none`,
                                                  )}
                                                >
                                                  <span
                                                    style={{
                                                      position: 'relative',
                                                      padding: '6px 12px',
                                                      borderRadius: '10px',
                                                      background: '#fff',
                                                      border: '2px solid hsl(0 0% 90%)',
                                                      color: 'hsl(6 91% 47%)',
                                                      fontSize: '12px',
                                                      fontWeight: '800',
                                                      letterSpacing: '.04em',
                                                      textTransform: 'uppercase',
                                                      whiteSpace: 'nowrap',
                                                      animation: 'bob 1.6s ease-in-out infinite',
                                                    }}
                                                  >
                                                    {'Começar'}
                                                  </span>
                                                </div>
                                              </>
                                            ) : null}
                                            {'\n                '}
                                            <button
                                              data-current={r?.dc}
                                              onClick={r?.onClick}
                                              aria-label={r?.popTitle}
                                              style={css(
                                                `position:absolute;top:18px;left:${S(r?.left)};width:66px;height:66px;padding:0;margin:0;border-radius:50%;border:none;background:${S(r?.bg)};box-shadow:${S(r?.sh)};color:${S(r?.fg)};display:grid;place-items:center;cursor:pointer;z-index:2;animation:${S(r?.anim)};transition:transform .12s`,
                                              )}
                                              className="scp1"
                                            >
                                              {'\n                  '}
                                              {r?.isCur ? (
                                                <>
                                                  <span
                                                    style={{
                                                      position: 'absolute',
                                                      left: '-10px',
                                                      right: '-10px',
                                                      top: '-10px',
                                                      bottom: '-10px',
                                                      margin: '0',
                                                      borderRadius: '50%',
                                                      border: '4px solid hsl(6 91% 47% / .55)',
                                                      boxSizing: 'border-box',
                                                      transformOrigin: '50% 50%',
                                                      animation: 'pulseRing 1.6s cubic-bezier(.16,1,.3,1) infinite',
                                                      pointerEvents: 'none',
                                                    }}
                                                  />
                                                </>
                                              ) : null}
                                              {'\n                  '}
                                              <lu-icon name={r?.icon} size="27" stroke="2.4" />
                                              {'\n                '}
                                            </button>
                                            {'\n                '}
                                            {r?.popOpen ? (
                                              <>
                                                {'\n                  '}
                                                <div
                                                  onClick={v.stopProp}
                                                  style={css(
                                                    `position:absolute;${S(r?.popPos)};left:${S(r?.popLeft)};width:260px;z-index:41;animation:popIn .22s cubic-bezier(.16,1,.3,1) both;transform-origin:${S(r?.popOrigin)}`,
                                                  )}
                                                >
                                                  {'\n                    '}
                                                  <span
                                                    style={css(
                                                      `position:absolute;${S(r?.caretPos)};left:${S(r?.caretLeft)};width:16px;height:16px;background:${S(r?.popBg)};transform:rotate(45deg);border-radius:3px`,
                                                    )}
                                                  />
                                                  {'\n                    '}
                                                  <div
                                                    style={css(
                                                      `position:relative;background:${S(r?.popBg)};border-radius:16px;padding:14px;box-shadow:0 12px 34px rgba(0,0,0,.18);display:flex;flex-direction:column;gap:10px`,
                                                    )}
                                                  >
                                                    {'\n                      '}
                                                    <div>
                                                      <div
                                                        style={css(`font-size:15px;font-weight:700;line-height:1.3;color:${S(r?.popFg)}`)}
                                                      >
                                                        {T(r?.popTitle)}
                                                      </div>
                                                      <div style={css(`font-size:12.5px;margin-top:3px;color:${S(r?.popSubFg)}`)}>
                                                        {T(r?.popSub)}
                                                      </div>
                                                    </div>
                                                    {'\n                      '}
                                                    {r?.popCan ? (
                                                      <>
                                                        <button
                                                          onClick={r?.onStart}
                                                          style={css(
                                                            `height:46px;border:none;border-radius:12px;background:#fff;color:${S(r?.popBtnFg)};font-size:14px;font-weight:800;cursor:pointer;box-shadow:0 4px 0 rgba(0,0,0,.14);transition:transform .2s cubic-bezier(.34,1.56,.64,1)`,
                                                          )}
                                                          className="scp0"
                                                        >
                                                          {T(r?.popBtn)}
                                                        </button>
                                                      </>
                                                    ) : null}
                                                    {'\n                      '}
                                                    {r?.popLocked ? (
                                                      <>
                                                        <div
                                                          style={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '8px',
                                                            fontSize: '12.5px',
                                                            color: 'hsl(0 0% 46%)',
                                                            background: 'hsl(0 0% 95%)',
                                                            borderRadius: '10px',
                                                            padding: '10px',
                                                          }}
                                                        >
                                                          <lu-icon name="lock" size="15" />
                                                          {'Conclua os níveis anteriores para desbloquear.'}
                                                        </div>
                                                      </>
                                                    ) : null}
                                                    {'\n                      '}
                                                    {r?.showSkip ? (
                                                      <>
                                                        <button
                                                          onClick={r?.onSkip}
                                                          style={css(
                                                            `height:44px;border-radius:12px;border:1px solid ${S(r?.skipBd)};background:${S(r?.skipBg)};color:${S(r?.popFg)};font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px`,
                                                          )}
                                                        >
                                                          <lu-icon name="fast-forward" size="15" />
                                                          {'Pular com teste'}
                                                        </button>
                                                      </>
                                                    ) : null}
                                                    {'\n                      '}
                                                    <button
                                                      onClick={r?.onReport}
                                                      style={css(
                                                        `align-self:center;min-height:36px;padding:0 8px;border:none;background:none;color:${S(r?.reportFg)};font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:6px;white-space:nowrap`,
                                                      )}
                                                    >
                                                      <lu-icon name="message-square-warning" size="14" />
                                                      {'Enviar feedback desta fase'}
                                                    </button>
                                                    {'\n                    '}
                                                  </div>
                                                  {'\n                  '}
                                                </div>
                                                {'\n                '}
                                              </>
                                            ) : null}
                                            {'\n              '}
                                          </div>
                                          {'\n            '}
                                        </Fragment>
                                      ))}
                                      {'\n            '}
                                      <div
                                        style={{
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: '10px',
                                          padding: '8px 24px 4px',
                                          color: 'hsl(0 0% 62%)',
                                          fontSize: '12px',
                                          fontWeight: '600',
                                        }}
                                      >
                                        <span style={{ flex: '1', height: '1px', background: 'hsl(0 0% 90%)' }} />
                                        <span
                                          style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '260px' }}
                                        >
                                          {T(u?.label)}
                                          {' · '}
                                          {T(u?.title)}
                                        </span>
                                        <span style={{ flex: '1', height: '1px', background: 'hsl(0 0% 90%)' }} />
                                      </div>
                                      {'\n          '}
                                    </div>
                                    {'\n        '}
                                  </Fragment>
                                ))}
                                {'\n        '}
                                {v.isAtd ? (
                                  <>
                                    {'\n          '}
                                    <div
                                      style={{
                                        margin: '10px 16px 0',
                                        padding: '16px',
                                        borderRadius: '16px',
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                                      }}
                                    >
                                      {'\n            '}
                                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                                        <span
                                          style={{
                                            width: '36px',
                                            height: '36px',
                                            borderRadius: '10px',
                                            background: 'hsl(6 91% 47% / .12)',
                                            color: 'hsl(6 91% 47%)',
                                            display: 'grid',
                                            placeItems: 'center',
                                          }}
                                        >
                                          <lu-icon name="clipboard-check" size="18" />
                                        </span>
                                        <div>
                                          <div style={{ fontSize: '14px', fontWeight: '700' }}>{'Rubrica da Monitoria'}</div>
                                          <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                            {'As mesmas faixas usadas na nota de atendimento'}
                                          </div>
                                        </div>
                                      </div>
                                      {'\n            '}
                                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                                        <span
                                          style={{
                                            fontSize: '11px',
                                            fontWeight: '600',
                                            padding: '3px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(150 55% 40% / .14)',
                                            color: 'hsl(150 55% 40%)',
                                          }}
                                        >
                                          {'Alto ≥ 80'}
                                        </span>
                                        <span
                                          style={{
                                            fontSize: '11px',
                                            fontWeight: '600',
                                            padding: '3px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(40 92% 46% / .15)',
                                            color: 'hsl(32 82% 42%)',
                                          }}
                                        >
                                          {'Médio ≥ 60'}
                                        </span>
                                        <span
                                          style={{
                                            fontSize: '11px',
                                            fontWeight: '600',
                                            padding: '3px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(6 91% 47% / .12)',
                                            color: 'hsl(6 91% 47%)',
                                          }}
                                        >
                                          {'Baixo < 60'}
                                        </span>
                                      </div>
                                      {'\n            '}
                                      {v.atdMand ? (
                                        <>
                                          <div
                                            style={{
                                              marginTop: '10px',
                                              display: 'flex',
                                              alignItems: 'center',
                                              gap: '6px',
                                              fontSize: '12px',
                                              fontWeight: '600',
                                              color: 'hsl(6 91% 47%)',
                                            }}
                                          >
                                            <lu-icon name="calendar-clock" size="14" />
                                            {T(v.atdMandText)}
                                          </div>
                                        </>
                                      ) : null}
                                      {'\n            '}
                                      {v.canLead ? (
                                        <>
                                          <button
                                            onClick={v.onOpenLeader}
                                            style={{
                                              marginTop: '12px',
                                              width: '100%',
                                              minHeight: '44px',
                                              borderRadius: '10px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              background: '#fff',
                                              fontSize: '13px',
                                              fontWeight: '600',
                                              color: 'hsl(0 0% 13%)',
                                              cursor: 'pointer',
                                              display: 'flex',
                                              alignItems: 'center',
                                              justifyContent: 'center',
                                              gap: '8px',
                                            }}
                                          >
                                            <lu-icon name="shield" size="16" />
                                            {'Personalizar no modo líder'}
                                          </button>
                                        </>
                                      ) : null}
                                      {'\n          '}
                                    </div>
                                    {'\n        '}
                                  </>
                                ) : null}
                                {'\n        '}
                                <div style={{ height: '100px' }} />
                                {'\n      '}
                              </>
                            ) : null}
                            {'\n      '}
                            {v.atdEmpty ? (
                              <>
                                {'\n        '}
                                <div
                                  style={{
                                    padding: '60px 28px',
                                    textAlign: 'center',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}
                                >
                                  {'\n          '}
                                  <span
                                    style={{
                                      width: '64px',
                                      height: '64px',
                                      borderRadius: '16px',
                                      background: 'hsl(6 91% 47% / .12)',
                                      color: 'hsl(6 91% 47%)',
                                      display: 'grid',
                                      placeItems: 'center',
                                    }}
                                  >
                                    <lu-icon name="headset" size="30" />
                                  </span>
                                  {'\n          '}
                                  <div style={{ fontSize: '17px', fontWeight: '700' }}>{'Sua equipe ainda não tem regras publicadas'}</div>
                                  {'\n          '}
                                  <div style={{ fontSize: '13.5px', color: 'hsl(0 0% 46%)', maxWidth: '30ch' }}>
                                    {'O líder do time liga as unidades-base da Monitoria ou cria regras próprias.'}
                                  </div>
                                  {'\n          '}
                                  {v.canLead ? (
                                    <>
                                      <button
                                        onClick={v.onOpenLeader}
                                        style={{
                                          marginTop: '6px',
                                          minHeight: '46px',
                                          padding: '0 18px',
                                          border: 'none',
                                          borderRadius: '10px',
                                          background: 'hsl(6 91% 47%)',
                                          color: '#fff',
                                          fontSize: '14px',
                                          fontWeight: '600',
                                          cursor: 'pointer',
                                          boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: '8px',
                                        }}
                                      >
                                        <lu-icon name="shield" size="16" />
                                        {'Montar a trilha'}
                                      </button>
                                    </>
                                  ) : null}
                                  {'\n        '}
                                </div>
                                {'\n      '}
                              </>
                            ) : null}
                            {'\n    '}
                          </div>
                          {'\n    '}
                          {v.hasContinue ? (
                            <>
                              {'\n      '}
                              <div style={{ position: 'absolute', left: '14px', right: '14px', bottom: '12px', zIndex: '25' }}>
                                {'\n        '}
                                <button
                                  onClick={v.onContinue}
                                  style={{
                                    width: '100%',
                                    height: '56px',
                                    border: 'none',
                                    borderRadius: '14px',
                                    background: 'hsl(6 91% 47%)',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    boxShadow: '0 4px 0 hsl(6 100% 34%), 0 10px 24px hsl(6 91% 47% / .3)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '12px',
                                    padding: '0 16px',
                                    transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                                  }}
                                  className="scp0"
                                >
                                  {'\n          '}
                                  <lu-icon name="play" size="20" fill="#fff" />
                                  {'\n          '}
                                  <span style={{ flex: '1', minWidth: '0', textAlign: 'left' }}>
                                    <span
                                      style={{
                                        display: 'block',
                                        fontSize: '11px',
                                        fontWeight: '600',
                                        opacity: '.85',
                                        textTransform: 'uppercase',
                                        letterSpacing: '.06em',
                                      }}
                                    >
                                      {'Continuar'}
                                    </span>
                                    <span
                                      style={{
                                        display: 'block',
                                        fontSize: '14px',
                                        fontWeight: '700',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                      }}
                                    >
                                      {T(v.continueLabel)}
                                    </span>
                                  </span>
                                  {'\n          '}
                                  <lu-icon name="arrow-right" size="20" />
                                  {'\n        '}
                                </button>
                                {'\n      '}
                              </div>
                              {'\n    '}
                            </>
                          ) : null}
                          {'\n    '}
                        </>
                      ) : null}
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n\n  '}
                {v.tabPractice ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        overflowY: 'auto',
                        padding: '18px 16px 28px',
                        animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                      }}
                    >
                      {'\n    '}
                      <h1 style={{ margin: '0', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>{'Praticar'}</h1>
                      {'\n    '}
                      <p style={{ margin: '4px 0 18px', fontSize: '13.5px', color: 'hsl(0 0% 46%)' }}>
                        {'Reforce o que está esfriando, no seu tempo.'}
                      </p>
                      {'\n    '}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {'\n      '}
                        <button
                          onClick={v.onReview}
                          style={{
                            textAlign: 'left',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '14px',
                            padding: '16px',
                            borderRadius: '16px',
                            border: '1px solid hsl(0 0% 90%)',
                            background: '#fff',
                            boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                            cursor: 'pointer',
                            minHeight: '84px',
                            transition: 'transform .2s',
                          }}
                          className="scp2"
                        >
                          {'\n        '}
                          <span
                            style={{
                              width: '46px',
                              height: '46px',
                              borderRadius: '13px',
                              background: 'hsl(262 52% 55% / .14)',
                              color: 'hsl(262 52% 55%)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name="brain" size="22" />
                          </span>
                          {'\n        '}
                          <span style={{ flex: '1', minWidth: '0' }}>
                            <span style={{ display: 'block', fontSize: '15px', fontWeight: '700' }}>{'Revisão inteligente'}</span>
                            <span style={{ display: 'block', fontSize: '12.5px', color: 'hsl(0 0% 46%)', marginTop: '2px' }}>
                              {T(v.dueLabel)}
                            </span>
                          </span>
                          {'\n        '}
                          <span
                            style={{ fontSize: '20px', fontWeight: '800', color: 'hsl(262 52% 55%)', fontVariantNumeric: 'tabular-nums' }}
                          >
                            {T(v.dueCount)}
                          </span>
                          {'\n      '}
                        </button>
                        {'\n      '}
                        <button
                          onClick={v.onErrors}
                          style={{
                            textAlign: 'left',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '14px',
                            padding: '16px',
                            borderRadius: '16px',
                            border: '1px solid hsl(0 0% 90%)',
                            background: '#fff',
                            boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                            cursor: 'pointer',
                            minHeight: '84px',
                            transition: 'transform .2s',
                          }}
                          className="scp2"
                        >
                          {'\n        '}
                          <span
                            style={{
                              width: '46px',
                              height: '46px',
                              borderRadius: '13px',
                              background: 'hsl(6 91% 47% / .12)',
                              color: 'hsl(6 91% 47%)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name="rotate-ccw" size="22" />
                          </span>
                          {'\n        '}
                          <span style={{ flex: '1', minWidth: '0' }}>
                            <span style={{ display: 'block', fontSize: '15px', fontWeight: '700' }}>{'Meus erros'}</span>
                            <span style={{ display: 'block', fontSize: '12.5px', color: 'hsl(0 0% 46%)', marginTop: '2px' }}>
                              {T(v.errLabel)}
                            </span>
                          </span>
                          {'\n        '}
                          <span
                            style={{ fontSize: '20px', fontWeight: '800', color: 'hsl(6 91% 47%)', fontVariantNumeric: 'tabular-nums' }}
                          >
                            {T(v.errCount)}
                          </span>
                          {'\n      '}
                        </button>
                        {'\n      '}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                          {'\n        '}
                          <button
                            onClick={v.onGlossOpen}
                            style={{
                              textAlign: 'left',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '10px',
                              padding: '16px',
                              borderRadius: '16px',
                              border: '1px solid hsl(0 0% 90%)',
                              background: '#fff',
                              boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                              cursor: 'pointer',
                              minHeight: '120px',
                            }}
                          >
                            {'\n          '}
                            <span
                              style={{
                                width: '40px',
                                height: '40px',
                                borderRadius: '11px',
                                background: 'hsl(212 72% 48% / .12)',
                                color: 'hsl(212 72% 48%)',
                                display: 'grid',
                                placeItems: 'center',
                              }}
                            >
                              <lu-icon name="book-text" size="20" />
                            </span>
                            {'\n          '}
                            <span>
                              <span style={{ display: 'block', fontSize: '14px', fontWeight: '700' }}>{'Glossário'}</span>
                              <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                {T(v.glossCount)}
                                {' termos'}
                              </span>
                            </span>
                            {'\n        '}
                          </button>
                          {'\n        '}
                          <button
                            onClick={v.onFlash}
                            style={{
                              textAlign: 'left',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '10px',
                              padding: '16px',
                              borderRadius: '16px',
                              border: '1px solid hsl(0 0% 90%)',
                              background: '#fff',
                              boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                              cursor: 'pointer',
                              minHeight: '120px',
                            }}
                          >
                            {'\n          '}
                            <span
                              style={{
                                width: '40px',
                                height: '40px',
                                borderRadius: '11px',
                                background: 'hsl(40 92% 46% / .15)',
                                color: 'hsl(40 92% 46%)',
                                display: 'grid',
                                placeItems: 'center',
                              }}
                            >
                              <lu-icon name="timer" size="20" />
                            </span>
                            {'\n          '}
                            <span>
                              <span style={{ display: 'block', fontSize: '14px', fontWeight: '700' }}>{'Desafio relâmpago'}</span>
                              <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                {'60 s · recorde '}
                                {T(v.flashRecord)}
                              </span>
                            </span>
                            {'\n        '}
                          </button>
                          {'\n      '}
                        </div>
                        {'\n      '}
                        {v.hasRecs ? (
                          <>
                            {'\n        '}
                            <div
                              style={{
                                marginTop: '6px',
                                fontSize: '11px',
                                fontWeight: '700',
                                letterSpacing: '.08em',
                                textTransform: 'uppercase',
                                color: 'hsl(0 0% 62%)',
                              }}
                            >
                              {'Recomendado pela Monitoria'}
                            </div>
                            {'\n        '}
                            {L(v.recs).map((r, $i8) => (
                              <Fragment key={$i8}>
                                {'\n          '}
                                <button
                                  onClick={r?.onClick}
                                  style={{
                                    textAlign: 'left',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '12px',
                                    padding: '14px 16px',
                                    borderRadius: '14px',
                                    border: '1px solid hsl(6 91% 47% / .35)',
                                    background: 'hsl(6 91% 47% / .06)',
                                    cursor: 'pointer',
                                    minHeight: '64px',
                                  }}
                                >
                                  {'\n            '}
                                  <span
                                    style={{
                                      width: '36px',
                                      height: '36px',
                                      borderRadius: '10px',
                                      background: 'hsl(6 91% 47% / .12)',
                                      display: 'grid',
                                      placeItems: 'center',
                                      flex: 'none',
                                    }}
                                  >
                                    <hubia-orb size="22" />
                                  </span>
                                  {'\n            '}
                                  <span style={{ flex: '1' }}>
                                    <span style={{ display: 'block', fontSize: '14px', fontWeight: '700', color: 'hsl(6 91% 47%)' }}>
                                      {'Reforce: '}
                                      {T(r?.crit)}
                                    </span>
                                    <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                      {'Sua nota neste critério está Baixa · '}
                                      {T(r?.score)}
                                    </span>
                                  </span>
                                  {'\n            '}
                                  <lu-icon name="arrow-right" size="18" />
                                  {'\n          '}
                                </button>
                                {'\n        '}
                              </Fragment>
                            ))}
                            {'\n      '}
                          </>
                        ) : null}
                        {'\n    '}
                      </div>
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n\n  '}
                {v.tabLeague ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        overflowY: 'auto',
                        padding: '16px 16px 28px',
                        animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                      }}
                      data-comment-anchor="3763e695be-div"
                    >
                      {'\n    '}
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '14px',
                          padding: '16px',
                          borderRadius: '16px',
                          background: '#fff',
                          border: '1px solid hsl(0 0% 90%)',
                          boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                        }}
                      >
                        {'\n      '}
                        <div
                          style={{
                            position: 'relative',
                            width: '62px',
                            height: '70px',
                            flex: 'none',
                            filter: 'drop-shadow(0 6px 12px rgba(0,0,0,.18))',
                          }}
                        >
                          <div
                            style={css(
                              `position:absolute;inset:0;background:${S(v.lgGrad)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%);display:grid;place-items:center;color:#fff;overflow:hidden`,
                            )}
                            data-comment-anchor="951d43e104-div"
                          >
                            <span
                              style={{
                                position: 'absolute',
                                inset: '5px',
                                clipPath: 'polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%)',
                                background: 'linear-gradient(160deg,rgba(255,255,255,.35),rgba(255,255,255,0) 55%,rgba(0,0,0,.18))',
                              }}
                            />
                            <span
                              style={{
                                position: 'relative',
                                display: 'grid',
                                marginTop: '-6px',
                                filter: 'drop-shadow(0 1px 2px rgba(0,0,0,.3))',
                              }}
                            >
                              <lu-icon name={v.lgIcon} size="28" stroke="2.2" />
                            </span>
                            <span
                              style={{
                                position: 'absolute',
                                top: '-10%',
                                bottom: '-10%',
                                left: '0',
                                width: '40%',
                                background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.6),transparent)',
                                transform: 'translateX(-130%) skewX(-18deg)',
                                animation: 'sheenLoop 3s .8s cubic-bezier(.45,0,.55,1) infinite',
                                willChange: 'transform',
                                pointerEvents: 'none',
                              }}
                            />
                          </div>
                        </div>
                        {'\n      '}
                        <div style={{ flex: '1', minWidth: '0' }}>
                          {'\n        '}
                          <div style={{ fontSize: '19px', fontWeight: '800', letterSpacing: '-.01em' }}>{T(v.lgName)}</div>
                          {'\n        '}
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '5px',
                              fontSize: '12.5px',
                              color: 'hsl(0 0% 46%)',
                              marginTop: '2px',
                            }}
                          >
                            <lu-icon name="clock" size="13" />
                            {T(v.lgCountdown)}
                          </div>
                          {'\n        '}
                          <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginTop: '2px' }}>{T(v.lgRules)}</div>
                          {'\n      '}
                        </div>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-end', gap: '8px', margin: '16px 0 4px' }}>
                        {'\n      '}
                        {L(v.lgSteps).map((g, $i9) => (
                          <Fragment key={$i9}>
                            <div
                              style={css(
                                `display:flex;flex-direction:column;align-items:center;gap:4px;opacity:${S(g?.op)};transition:opacity .3s`,
                              )}
                            >
                              <span
                                style={css(
                                  `position:relative;width:${S(g?.sz)};height:${S(g?.sz)};display:grid;place-items:center;filter:drop-shadow(0 3px 5px rgba(0,0,0,.18))`,
                                )}
                              >
                                <span
                                  style={css(
                                    `position:absolute;inset:0;background:${S(g?.g)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%)`,
                                  )}
                                />
                                <span
                                  style={{
                                    position: 'absolute',
                                    inset: '3px',
                                    background: 'linear-gradient(160deg,rgba(255,255,255,.4),rgba(255,255,255,0) 55%,rgba(0,0,0,.16))',
                                    clipPath: 'polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%)',
                                  }}
                                />
                                <span
                                  style={{
                                    position: 'relative',
                                    color: '#fff',
                                    display: 'grid',
                                    marginTop: '-3px',
                                    filter: 'drop-shadow(0 1px 1px rgba(0,0,0,.35))',
                                  }}
                                >
                                  <lu-icon name={g?.icon} size={g?.isz} stroke="2.4" />
                                </span>
                              </span>
                              <span style={css(`font-size:10px;font-weight:${S(g?.fw)};color:${S(g?.fg)}`)}>{T(g?.nome)}</span>
                            </div>
                          </Fragment>
                        ))}
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <div
                        style={{
                          display: 'flex',
                          background: 'hsl(0 0% 95%)',
                          borderRadius: '10px',
                          padding: '4px',
                          gap: '2px',
                          margin: '14px 0 18px',
                        }}
                      >
                        {'\n      '}
                        <button
                          onClick={v.onFTeam}
                          style={css(
                            `flex:1;min-height:40px;border:none;border-radius:8px;background:${S(v.fTeamBg)};color:${S(v.fTeamFg)};box-shadow:${S(v.fTeamSh)};font-size:13px;font-weight:600;cursor:pointer`,
                          )}
                        >
                          {'Meu time'}
                        </button>
                        {'\n      '}
                        <button
                          onClick={v.onFAll}
                          style={css(
                            `flex:1;min-height:40px;border:none;border-radius:8px;background:${S(v.fAllBg)};color:${S(v.fAllFg)};box-shadow:${S(v.fAllSh)};font-size:13px;font-weight:600;cursor:pointer`,
                          )}
                        >
                          {'Toda a Takeat'}
                        </button>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      {v.lbLoading ? (
                        <>
                          {'\n      '}
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                            {'\n        '}
                            <div
                              style={{
                                height: '170px',
                                borderRadius: '16px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                height: '64px',
                                borderRadius: '14px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                height: '64px',
                                borderRadius: '14px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n        '}
                            <div
                              style={{
                                height: '64px',
                                borderRadius: '14px',
                                background: 'linear-gradient(90deg,hsl(0 0% 93%) 25%,hsl(0 0% 97%) 50%,hsl(0 0% 93%) 75%)',
                                backgroundSize: '200% 100%',
                                animation: 'shimmer 1.4s linear infinite',
                              }}
                            />
                            {'\n      '}
                          </div>
                          {'\n    '}
                        </>
                      ) : null}
                      {'\n    '}
                      {v.lbError ? (
                        <>
                          {'\n      '}
                          <div
                            style={css(
                              `padding:32px 20px;border-radius:16px;background:#fff;border:1px solid hsl(0 0% 90%);text-align:center;display:flex;flex-direction:column;align-items:center;gap:8px;animation:${S(v.errAnim)}`,
                            )}
                          >
                            {'\n        '}
                            <span
                              style={{
                                width: '52px',
                                height: '52px',
                                borderRadius: '14px',
                                background: 'hsl(0 0% 95%)',
                                color: 'hsl(0 0% 46%)',
                                display: 'grid',
                                placeItems: 'center',
                              }}
                            >
                              <lu-icon name="wifi-off" size="24" />
                            </span>
                            {'\n        '}
                            <div style={{ fontSize: '15px', fontWeight: '700' }}>{'Não foi possível carregar o ranking'}</div>
                            {'\n        '}
                            <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                              {'Confira sua conexão. Seu XP da semana está salvo.'}
                            </div>
                            {'\n        '}
                            <button
                              onClick={v.onRetry}
                              disabled={v.retrying}
                              style={{
                                marginTop: '6px',
                                minHeight: '44px',
                                padding: '0 18px',
                                border: 'none',
                                borderRadius: '10px',
                                background: 'hsl(6 91% 47%)',
                                color: '#fff',
                                fontSize: '13px',
                                fontWeight: '600',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                transition: 'transform .25s cubic-bezier(.34,1.56,.64,1), opacity .2s',
                              }}
                              className="scp0"
                            >
                              <span style={css(`display:grid;animation:${S(v.retryAnim)}`)}>
                                <lu-icon name={v.retryIcon} size="15" />
                              </span>
                              {v.retryIdle ? <>{'Tentar de novo'}</> : null}
                              {v.retrying ? <>{'Conectando…'}</> : null}
                            </button>
                            {'\n      '}
                          </div>
                          {'\n    '}
                        </>
                      ) : null}
                      {'\n    '}
                      {v.lbReady ? (
                        <>
                          {'\n      '}
                          {v.lbIsAll ? (
                            <>
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'flex-end',
                                  justifyContent: 'center',
                                  gap: '10px',
                                  padding: '8px 4px 0',
                                  marginBottom: '22px',
                                  height: '214px',
                                }}
                                data-comment-anchor="8ebb9c6952-div"
                              >
                                {'\n        '}
                                {L(v.podium).map((o, $i10) => (
                                  <Fragment key={$i10}>
                                    {'\n          '}
                                    <div
                                      style={{
                                        flex: '1',
                                        maxWidth: '110px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        gap: '6px',
                                      }}
                                    >
                                      {'\n            '}
                                      <div
                                        style={css(
                                          `display:flex;flex-direction:column;align-items:center;gap:2px;animation:dropIn .55s ${S(o?.avDelay)} cubic-bezier(.34,1.56,.64,1) both`,
                                        )}
                                      >
                                        {'\n              '}
                                        <span style={{ position: 'relative', width: '56px', height: '56px', display: 'inline-flex' }}>
                                          {'\n                '}
                                          {o?.av?.has ? (
                                            <>
                                              <span
                                                style={{
                                                  position: 'absolute',
                                                  top: '8px',
                                                  left: '8px',
                                                  width: '40px',
                                                  height: '40px',
                                                  borderRadius: '999px',
                                                  background: 'hsl(6 91% 47%)',
                                                  color: '#fff',
                                                  display: 'grid',
                                                  placeItems: 'center',
                                                  fontSize: '14px',
                                                  fontWeight: '700',
                                                }}
                                              >
                                                {T(o?.av?.ini)}
                                              </span>
                                              <span
                                                style={css(
                                                  `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(o?.av?.src)}) center/contain no-repeat`,
                                                )}
                                              />
                                            </>
                                          ) : null}
                                          {'\n                '}
                                          {o?.av?.no ? (
                                            <>
                                              <span
                                                style={{
                                                  width: '56px',
                                                  height: '56px',
                                                  borderRadius: '999px',
                                                  border: '1px solid hsl(0 0% 90%)',
                                                  background: 'hsl(6 91% 47%)',
                                                  color: '#fff',
                                                  display: 'grid',
                                                  placeItems: 'center',
                                                  fontSize: '18px',
                                                  fontWeight: '700',
                                                }}
                                              >
                                                {T(o?.av?.ini)}
                                              </span>
                                            </>
                                          ) : null}
                                          {'\n              '}
                                        </span>
                                        {'\n              '}
                                        <span
                                          style={{
                                            fontSize: '12.5px',
                                            fontWeight: '700',
                                            maxWidth: '100px',
                                            whiteSpace: 'nowrap',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                          }}
                                        >
                                          {T(o?.nome)}
                                        </span>
                                        {'\n              '}
                                        <span style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)' }}>{T(o?.xp)}</span>
                                        {'\n            '}
                                      </div>
                                      {'\n            '}
                                      <div
                                        style={css(
                                          `width:100%;height:${S(o?.h)};border-radius:12px 12px 0 0;background:${S(o?.g)};transform-origin:bottom;animation:stepUp .5s ${S(o?.stepDelay)} cubic-bezier(.16,1,.3,1) both;display:grid;place-items:center;color:#fff;font-size:24px;font-weight:800;text-shadow:0 1px 2px rgba(0,0,0,.2)`,
                                        )}
                                      >
                                        {T(o?.place)}
                                      </div>
                                      {'\n          '}
                                    </div>
                                    {'\n        '}
                                  </Fragment>
                                ))}
                                {'\n      '}
                              </div>
                              {'\n      '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {'\n        '}
                                {L(v.lbItems).map((i, $i11) => (
                                  <Fragment key={$i11}>
                                    {'\n          '}
                                    {i?.isRow ? (
                                      <>
                                        {'\n            '}
                                        <div
                                          style={css(
                                            `position:${S(i?.pos)};top:0;bottom:0;z-index:3;display:flex;align-items:center;gap:12px;min-height:64px;padding:10px 14px;border-radius:14px;background:${S(i?.bg)};border:1px solid ${S(i?.bd)};box-shadow:0 1px 3px rgba(0,0,0,.05);animation:up8 .35s ${S(i?.delay)} cubic-bezier(.16,1,.3,1) both;backdrop-filter:blur(8px)`,
                                          )}
                                        >
                                          {'\n              '}
                                          <span
                                            style={css(
                                              `width:24px;text-align:center;font-size:14px;font-weight:800;color:${S(i?.rankFg)};font-variant-numeric:tabular-nums`,
                                            )}
                                          >
                                            {T(i?.rank)}
                                          </span>
                                          {'\n              '}
                                          <span
                                            style={{
                                              position: 'relative',
                                              width: '42px',
                                              height: '42px',
                                              display: 'inline-flex',
                                              flex: 'none',
                                            }}
                                          >
                                            {'\n                '}
                                            {i?.av?.has ? (
                                              <>
                                                <span
                                                  style={{
                                                    position: 'absolute',
                                                    top: '6px',
                                                    left: '6px',
                                                    width: '30px',
                                                    height: '30px',
                                                    borderRadius: '999px',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '11px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(i?.av?.ini)}
                                                </span>
                                                <span
                                                  style={css(
                                                    `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(i?.av?.src)}) center/contain no-repeat`,
                                                  )}
                                                />
                                              </>
                                            ) : null}
                                            {'\n                '}
                                            {i?.av?.no ? (
                                              <>
                                                <span
                                                  style={{
                                                    width: '42px',
                                                    height: '42px',
                                                    borderRadius: '999px',
                                                    border: '1px solid hsl(0 0% 90%)',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '14px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(i?.av?.ini)}
                                                </span>
                                              </>
                                            ) : null}
                                            {'\n              '}
                                          </span>
                                          {'\n              '}
                                          <span style={{ flex: '1', minWidth: '0' }}>
                                            <span
                                              style={{
                                                display: 'block',
                                                fontSize: '14px',
                                                fontWeight: '600',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(i?.nome)}
                                            </span>
                                            <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(i?.team)}</span>
                                          </span>
                                          {'\n              '}
                                          <span
                                            style={{
                                              fontSize: '13px',
                                              fontWeight: '700',
                                              color: 'hsl(0 0% 13%)',
                                              fontVariantNumeric: 'tabular-nums',
                                            }}
                                          >
                                            {T(i?.xp)}
                                          </span>
                                          {'\n            '}
                                        </div>
                                        {'\n          '}
                                      </>
                                    ) : null}
                                    {'\n          '}
                                    {i?.isDiv ? (
                                      <>
                                        <div
                                          style={css(
                                            `display:flex;align-items:center;gap:8px;padding:6px 4px;color:${S(i?.divFg)};font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase`,
                                          )}
                                        >
                                          <lu-icon name={i?.divIcon} size="15" />
                                          {T(i?.divText)}
                                          <span style={{ flex: '1', height: '1px', background: 'currentColor', opacity: '.25' }} />
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n        '}
                                  </Fragment>
                                ))}
                                {'\n      '}
                              </div>
                              {'\n      '}
                            </>
                          ) : null}
                          {'\n      '}
                          {v.lbIsTeam ? (
                            <>
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'flex-end',
                                  justifyContent: 'center',
                                  gap: '10px',
                                  padding: '8px 4px 0',
                                  marginBottom: '22px',
                                  height: '214px',
                                }}
                              >
                                {'\n        '}
                                {L(v.podium).map((o, $i12) => (
                                  <Fragment key={$i12}>
                                    {'\n          '}
                                    <div
                                      style={{
                                        flex: '1',
                                        maxWidth: '110px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        gap: '6px',
                                      }}
                                    >
                                      {'\n            '}
                                      <div
                                        style={css(
                                          `display:flex;flex-direction:column;align-items:center;gap:2px;animation:dropIn .55s ${S(o?.avDelay)} cubic-bezier(.34,1.56,.64,1) both`,
                                        )}
                                      >
                                        {'\n              '}
                                        <span style={{ position: 'relative', width: '56px', height: '56px', display: 'inline-flex' }}>
                                          {'\n                '}
                                          {o?.av?.has ? (
                                            <>
                                              <span
                                                style={{
                                                  position: 'absolute',
                                                  top: '8px',
                                                  left: '8px',
                                                  width: '40px',
                                                  height: '40px',
                                                  borderRadius: '999px',
                                                  background: 'hsl(6 91% 47%)',
                                                  color: '#fff',
                                                  display: 'grid',
                                                  placeItems: 'center',
                                                  fontSize: '14px',
                                                  fontWeight: '700',
                                                }}
                                              >
                                                {T(o?.av?.ini)}
                                              </span>
                                              <span
                                                style={css(
                                                  `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(o?.av?.src)}) center/contain no-repeat`,
                                                )}
                                              />
                                            </>
                                          ) : null}
                                          {'\n                '}
                                          {o?.av?.no ? (
                                            <>
                                              <span
                                                style={{
                                                  width: '56px',
                                                  height: '56px',
                                                  borderRadius: '999px',
                                                  border: '1px solid hsl(0 0% 90%)',
                                                  background: 'hsl(6 91% 47%)',
                                                  color: '#fff',
                                                  display: 'grid',
                                                  placeItems: 'center',
                                                  fontSize: '18px',
                                                  fontWeight: '700',
                                                }}
                                              >
                                                {T(o?.av?.ini)}
                                              </span>
                                            </>
                                          ) : null}
                                          {'\n              '}
                                        </span>
                                        {'\n              '}
                                        <span
                                          style={{
                                            fontSize: '12.5px',
                                            fontWeight: '700',
                                            maxWidth: '100px',
                                            whiteSpace: 'nowrap',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                          }}
                                        >
                                          {T(o?.nome)}
                                        </span>
                                        {'\n              '}
                                        <span style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)' }}>{T(o?.xp)}</span>
                                        {'\n            '}
                                      </div>
                                      {'\n            '}
                                      <div
                                        style={css(
                                          `width:100%;height:${S(o?.h)};border-radius:12px 12px 0 0;background:${S(o?.g)};transform-origin:bottom;animation:stepUp .5s ${S(o?.stepDelay)} cubic-bezier(.16,1,.3,1) both;display:grid;place-items:center;color:#fff;font-size:24px;font-weight:800;text-shadow:0 1px 2px rgba(0,0,0,.2)`,
                                        )}
                                      >
                                        {T(o?.place)}
                                      </div>
                                      {'\n          '}
                                    </div>
                                    {'\n        '}
                                  </Fragment>
                                ))}
                                {'\n      '}
                              </div>
                              {'\n      '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {'\n        '}
                                {L(v.lbItems).map((i, $i13) => (
                                  <Fragment key={$i13}>
                                    {'\n          '}
                                    {i?.isRow ? (
                                      <>
                                        {'\n            '}
                                        <div
                                          style={css(
                                            `position:${S(i?.pos)};top:0;bottom:0;z-index:3;display:flex;align-items:center;gap:12px;min-height:64px;padding:10px 14px;border-radius:14px;background:${S(i?.bg)};border:1px solid ${S(i?.bd)};box-shadow:0 1px 3px rgba(0,0,0,.05);animation:up8 .35s ${S(i?.delay)} cubic-bezier(.16,1,.3,1) both;backdrop-filter:blur(8px)`,
                                          )}
                                        >
                                          {'\n              '}
                                          <span
                                            style={css(
                                              `width:24px;text-align:center;font-size:14px;font-weight:800;color:${S(i?.rankFg)};font-variant-numeric:tabular-nums`,
                                            )}
                                          >
                                            {T(i?.rank)}
                                          </span>
                                          {'\n              '}
                                          <span
                                            style={{
                                              position: 'relative',
                                              width: '42px',
                                              height: '42px',
                                              display: 'inline-flex',
                                              flex: 'none',
                                            }}
                                          >
                                            {'\n                '}
                                            {i?.av?.has ? (
                                              <>
                                                <span
                                                  style={{
                                                    position: 'absolute',
                                                    top: '6px',
                                                    left: '6px',
                                                    width: '30px',
                                                    height: '30px',
                                                    borderRadius: '999px',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '11px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(i?.av?.ini)}
                                                </span>
                                                <span
                                                  style={css(
                                                    `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(i?.av?.src)}) center/contain no-repeat`,
                                                  )}
                                                />
                                              </>
                                            ) : null}
                                            {'\n                '}
                                            {i?.av?.no ? (
                                              <>
                                                <span
                                                  style={{
                                                    width: '42px',
                                                    height: '42px',
                                                    borderRadius: '999px',
                                                    border: '1px solid hsl(0 0% 90%)',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '14px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(i?.av?.ini)}
                                                </span>
                                              </>
                                            ) : null}
                                            {'\n              '}
                                          </span>
                                          {'\n              '}
                                          <span style={{ flex: '1', minWidth: '0' }}>
                                            <span
                                              style={{
                                                display: 'block',
                                                fontSize: '14px',
                                                fontWeight: '600',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                              }}
                                            >
                                              {T(i?.nome)}
                                            </span>
                                            <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(i?.team)}</span>
                                          </span>
                                          {'\n              '}
                                          <span
                                            style={{
                                              fontSize: '13px',
                                              fontWeight: '700',
                                              color: 'hsl(0 0% 13%)',
                                              fontVariantNumeric: 'tabular-nums',
                                            }}
                                          >
                                            {T(i?.xp)}
                                          </span>
                                          {'\n            '}
                                        </div>
                                        {'\n          '}
                                      </>
                                    ) : null}
                                    {'\n          '}
                                    {i?.isDiv ? (
                                      <>
                                        <div
                                          style={css(
                                            `display:flex;align-items:center;gap:8px;padding:6px 4px;color:${S(i?.divFg)};font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase`,
                                          )}
                                        >
                                          <lu-icon name={i?.divIcon} size="15" />
                                          {T(i?.divText)}
                                          <span style={{ flex: '1', height: '1px', background: 'currentColor', opacity: '.25' }} />
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n        '}
                                  </Fragment>
                                ))}
                                {'\n      '}
                              </div>
                              {'\n      '}
                            </>
                          ) : null}
                          {'\n      '}
                          <button
                            onClick={v.onEndWeek}
                            style={{
                              marginTop: '20px',
                              width: '100%',
                              minHeight: '44px',
                              borderRadius: '10px',
                              border: '1px dashed hsl(0 0% 80%)',
                              background: 'transparent',
                              color: 'hsl(0 0% 46%)',
                              fontSize: '12.5px',
                              fontWeight: '600',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '8px',
                            }}
                          >
                            <lu-icon name="flag" size="15" />
                            {'Debug · encerrar semana'}
                          </button>
                          {'\n    '}
                        </>
                      ) : null}
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n\n  '}
                {v.tabMissions ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        overflowY: 'auto',
                        padding: '18px 16px 28px',
                        animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '14px',
                      }}
                    >
                      {'\n    '}
                      <div>
                        <h1 style={{ margin: '0', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>{'Missões'}</h1>
                        <p style={{ margin: '4px 0 0', fontSize: '13.5px', color: 'hsl(0 0% 46%)' }}>
                          {'Complete missões e ganhe Takitos para a Loja do Hub.'}
                        </p>
                      </div>
                      {'\n    '}
                      <div
                        style={{
                          background: '#fff',
                          border: '1px solid hsl(0 0% 90%)',
                          borderRadius: '16px',
                          boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                          padding: '16px',
                        }}
                      >
                        {'\n      '}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                          {'\n        '}
                          <span
                            style={{
                              width: '38px',
                              height: '38px',
                              borderRadius: '11px',
                              background: 'hsl(6 91% 47% / .12)',
                              color: 'hsl(6 91% 47%)',
                              display: 'grid',
                              placeItems: 'center',
                            }}
                          >
                            <lu-icon name="target" size="19" />
                          </span>
                          {'\n        '}
                          <div style={{ flex: '1' }}>
                            <div style={{ fontSize: '15px', fontWeight: '700' }}>{'Missões do dia'}</div>
                            <div style={{ fontSize: '12px', color: 'hsl(6 91% 47%)', fontWeight: '500' }}>
                              {T(v.hubLevel)}
                              {' · '}
                              {T(v.dailyDone)}
                              {'/3'}
                            </div>
                          </div>
                          {'\n        '}
                          <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: 'hsl(0 0% 46%)' }}>
                            <lu-icon name="clock" size="12" />
                            {T(v.resetIn)}
                          </span>
                          {'\n      '}
                        </div>
                        {'\n      '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                          {'\n        '}
                          {L(v.daily).map((m, $i14) => (
                            <Fragment key={$i14}>
                              {'\n          '}
                              <div style={css(`display:flex;align-items:center;gap:12px;opacity:${S(m?.op)};min-height:44px`)}>
                                {'\n            '}
                                {m?.done ? (
                                  <>
                                    <span style={{ color: 'hsl(150 55% 40%)', display: 'grid' }}>
                                      <lu-icon name="circle-check" size="22" />
                                    </span>
                                  </>
                                ) : null}
                                {'\n            '}
                                {m?.notDone ? (
                                  <>
                                    <span
                                      style={{
                                        width: '20px',
                                        height: '20px',
                                        margin: '1px',
                                        borderRadius: '999px',
                                        border: '2px solid hsl(217 91% 60%)',
                                        flex: 'none',
                                      }}
                                    />
                                  </>
                                ) : null}
                                {'\n            '}
                                <div style={{ flex: '1', minWidth: '0' }}>
                                  {'\n              '}
                                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px' }}>
                                    <span style={css(`font-size:13.5px;font-weight:500;text-decoration:${S(m?.deco)}`)}>{T(m?.t)}</span>
                                    <span style={{ fontSize: '11px', color: 'hsl(0 0% 46%)', fontVariantNumeric: 'tabular-nums' }}>
                                      {T(m?.prog)}
                                    </span>
                                  </div>
                                  {'\n              '}
                                  <div
                                    style={{
                                      height: '6px',
                                      borderRadius: '999px',
                                      background: 'hsl(0 0% 93%)',
                                      marginTop: '6px',
                                      overflow: 'hidden',
                                    }}
                                  >
                                    <div
                                      style={css(
                                        `height:100%;width:${S(m?.pct)};background:hsl(6 91% 47%);border-radius:999px;transition:width .5s cubic-bezier(.34,1.56,.64,1)`,
                                      )}
                                    />
                                  </div>
                                  {'\n            '}
                                </div>
                                {'\n            '}
                                <span
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '2px',
                                    fontSize: '11px',
                                    fontWeight: '600',
                                    color: '#d97706',
                                    flex: 'none',
                                  }}
                                >
                                  {T(m?.reward)}
                                  <img src="assets/academy-book.png" width="13" height="13" alt="" />
                                </span>
                                {'\n          '}
                              </div>
                              {'\n        '}
                            </Fragment>
                          ))}
                          {'\n      '}
                        </div>
                        {'\n      '}
                        <div style={{ marginTop: '14px', paddingTop: '14px', borderTop: '1px solid hsl(0 0% 93%)' }}>
                          {'\n        '}
                          {v.chestReady ? (
                            <>
                              <button
                                onClick={v.onDailyChest}
                                style={{
                                  width: '100%',
                                  minHeight: '52px',
                                  border: 'none',
                                  borderRadius: '12px',
                                  background: 'linear-gradient(145deg,#FFD66B,#FF8A3D)',
                                  color: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '700',
                                  cursor: 'pointer',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                  boxShadow: '0 4px 0 hsl(28 80% 42%)',
                                  animation: 'bob 1.6s ease-in-out infinite',
                                }}
                                className="scp0"
                              >
                                <lu-icon name="gift" size="19" />
                                {'Abrir o baú do dia'}
                              </button>
                            </>
                          ) : null}
                          {'\n        '}
                          {v.chestLocked ? (
                            <>
                              <div
                                style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '12.5px', color: 'hsl(0 0% 46%)' }}
                              >
                                <span
                                  style={{
                                    width: '36px',
                                    height: '36px',
                                    borderRadius: '10px',
                                    background: 'hsl(0 0% 95%)',
                                    display: 'grid',
                                    placeItems: 'center',
                                  }}
                                >
                                  <lu-icon name="gift" size="18" />
                                </span>
                                {'Complete as 3 missões para abrir o baú do dia.'}
                              </div>
                            </>
                          ) : null}
                          {'\n        '}
                          {v.chestOpened ? (
                            <>
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '10px',
                                  fontSize: '12.5px',
                                  color: 'hsl(150 55% 35%)',
                                }}
                              >
                                <lu-icon name="circle-check" size="18" />
                                {'Baú do dia aberto. Novas missões amanhã.'}
                              </div>
                            </>
                          ) : null}
                          {'\n      '}
                        </div>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <div
                        style={{
                          background: '#fff',
                          border: '1px solid hsl(0 0% 90%)',
                          borderRadius: '16px',
                          boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                          padding: '16px',
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'center',
                        }}
                      >
                        {'\n      '}
                        <div style={{ position: 'relative', width: '54px', height: '60px', flex: 'none' }}>
                          <div
                            style={{
                              position: 'absolute',
                              inset: '0',
                              background: 'linear-gradient(135deg,#FF2F6E,#A82743 55%,#5B1A8A)',
                              clipPath: 'polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%)',
                              display: 'grid',
                              placeItems: 'center',
                              color: '#fff',
                            }}
                          >
                            <lu-icon name="award" size="24" />
                          </div>
                        </div>
                        {'\n      '}
                        <div style={{ flex: '1', minWidth: '0' }}>
                          {'\n        '}
                          <div style={{ fontSize: '15px', fontWeight: '700', textTransform: 'capitalize' }}>{T(v.monthT)}</div>
                          {'\n        '}
                          <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(v.monthSub)}</div>
                          {'\n        '}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '8px' }}>
                            <div
                              style={{ flex: '1', height: '8px', borderRadius: '999px', background: 'hsl(0 0% 93%)', overflow: 'hidden' }}
                            >
                              <div
                                style={css(
                                  `height:100%;width:${S(v.monthPct)};background:linear-gradient(90deg,#FF2F6E,#A82743);border-radius:999px`,
                                )}
                              />
                            </div>
                            <span
                              style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)', fontVariantNumeric: 'tabular-nums' }}
                            >
                              {T(v.monthProg)}
                            </span>
                          </div>
                          {'\n      '}
                        </div>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <div
                        style={{
                          background: '#fff',
                          border: '1px solid hsl(0 0% 90%)',
                          borderRadius: '16px',
                          boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                          padding: '16px',
                        }}
                      >
                        {'\n      '}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                          <span
                            style={{
                              width: '38px',
                              height: '38px',
                              borderRadius: '11px',
                              background: 'hsl(212 72% 48% / .12)',
                              color: 'hsl(212 72% 48%)',
                              display: 'grid',
                              placeItems: 'center',
                            }}
                          >
                            <lu-icon name="users" size="19" />
                          </span>
                          <div style={{ flex: '1' }}>
                            <div style={{ fontSize: '15px', fontWeight: '700' }}>{'Missão de equipe'}</div>
                            <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(v.teamT)}</div>
                          </div>
                        </div>
                        {'\n      '}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                          <div style={{ flex: '1', height: '8px', borderRadius: '999px', background: 'hsl(0 0% 93%)', overflow: 'hidden' }}>
                            <div style={css(`height:100%;width:${S(v.teamPct)};background:hsl(212 72% 48%);border-radius:999px`)} />
                          </div>
                          <span style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)' }}>{T(v.teamProg)}</span>
                        </div>
                        {'\n      '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          {'\n        '}
                          {L(v.teamMembers).map((m, $i15) => (
                            <Fragment key={$i15}>
                              {'\n          '}
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                {'\n            '}
                                <span style={{ position: 'relative', width: '34px', height: '34px', display: 'inline-flex', flex: 'none' }}>
                                  {m?.av?.has ? (
                                    <>
                                      <span
                                        style={{
                                          position: 'absolute',
                                          top: '5px',
                                          left: '5px',
                                          width: '24px',
                                          height: '24px',
                                          borderRadius: '999px',
                                          background: 'hsl(6 91% 47%)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                          fontSize: '9px',
                                          fontWeight: '700',
                                        }}
                                      >
                                        {T(m?.av?.ini)}
                                      </span>
                                      <span
                                        style={css(
                                          `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(m?.av?.src)}) center/contain no-repeat`,
                                        )}
                                      />
                                    </>
                                  ) : null}
                                  {m?.av?.no ? (
                                    <>
                                      <span
                                        style={{
                                          width: '34px',
                                          height: '34px',
                                          borderRadius: '999px',
                                          background: 'hsl(6 91% 47%)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                          fontSize: '11px',
                                          fontWeight: '700',
                                        }}
                                      >
                                        {T(m?.av?.ini)}
                                      </span>
                                    </>
                                  ) : null}
                                </span>
                                {'\n            '}
                                <span style={{ flex: '1', fontSize: '13px', fontWeight: '500' }}>{T(m?.nome)}</span>
                                <span style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', fontVariantNumeric: 'tabular-nums' }}>
                                  {T(m?.nl)}
                                </span>
                                {'\n          '}
                              </div>
                              {'\n        '}
                            </Fragment>
                          ))}
                          {'\n      '}
                        </div>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <button
                        onClick={v.onLoja}
                        style={{
                          width: '100%',
                          minHeight: '44px',
                          borderRadius: '10px',
                          border: '1px solid hsl(0 0% 90%)',
                          background: '#fff',
                          fontSize: '13px',
                          fontWeight: '500',
                          color: 'hsl(0 0% 13%)',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '8px',
                        }}
                      >
                        <lu-icon name="store" size="16" />
                        {'Gastar seus Takitos na Loja'}
                      </button>
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n\n  '}
                {v.tabProfile ? (
                  <>
                    {'\n  '}
                    <div style={{ flex: '1', minHeight: '0', overflowY: 'auto', animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both' }}>
                      {'\n    '}
                      <div
                        style={{
                          background: '#fff',
                          borderBottom: '1px solid hsl(0 0% 90%)',
                          padding: '22px 16px 16px',
                          textAlign: 'center',
                        }}
                      >
                        <h1 style={{ margin: '0', fontSize: '24px', fontWeight: '700' }}>{'Meu Perfil'}</h1>
                        <p style={{ margin: '4px 0 0', fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                          {'Seu progresso no Academy e seus dados do TakeatHub.'}
                        </p>
                      </div>
                      {'\n    '}
                      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        {'\n      '}
                        <div
                          style={css(
                            `position:relative;background:#fff;border:1px solid hsl(0 0% 90%);border-radius:12px;padding:16px;padding-top:${S(v.profPadTop)};display:flex;align-items:center;gap:12px;overflow:hidden`,
                          )}
                        >
                          {'\n        '}
                          {v.hasProfBg ? (
                            <>
                              <div style={css(`position:absolute;left:0;right:0;top:0;height:40px;background:${S(v.profBg)}`)} />
                            </>
                          ) : null}
                          {'\n        '}
                          <span style={{ position: 'relative', width: '56px', height: '56px', display: 'inline-flex', flex: 'none' }}>
                            {v.profAv?.has ? (
                              <>
                                <span
                                  style={{
                                    position: 'absolute',
                                    top: '8px',
                                    left: '8px',
                                    width: '40px',
                                    height: '40px',
                                    borderRadius: '999px',
                                    background: 'hsl(6 91% 47%)',
                                    color: '#fff',
                                    display: 'grid',
                                    placeItems: 'center',
                                    fontSize: '14px',
                                    fontWeight: '700',
                                  }}
                                >
                                  {T(v.profAv?.ini)}
                                </span>
                                <span
                                  style={css(
                                    `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(v.profAv?.src)}) center/contain no-repeat`,
                                  )}
                                />
                              </>
                            ) : null}
                            {v.profAv?.no ? (
                              <>
                                <span
                                  style={{
                                    width: '56px',
                                    height: '56px',
                                    borderRadius: '999px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    background: 'hsl(6 91% 47%)',
                                    color: '#fff',
                                    display: 'grid',
                                    placeItems: 'center',
                                    fontSize: '19px',
                                    fontWeight: '700',
                                  }}
                                >
                                  {T(v.profAv?.ini)}
                                </span>
                              </>
                            ) : null}
                          </span>
                          {'\n        '}
                          <div style={{ position: 'relative', flex: '1', minWidth: '0' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '16px', fontWeight: '600' }}>
                              <span style={{ minWidth: '0', overflowWrap: 'anywhere' }}>{T(v.profName)}</span>
                              {v.profIconOn ? (
                                <>
                                  <span
                                    style={{
                                      width: '22px',
                                      height: '22px',
                                      borderRadius: '7px',
                                      background: 'hsl(6 91% 47% / .12)',
                                      color: 'hsl(6 91% 47%)',
                                      display: 'grid',
                                      placeItems: 'center',
                                      flex: 'none',
                                    }}
                                  >
                                    <lu-icon name={v.profIcon} size="13" />
                                  </span>
                                </>
                              ) : null}
                            </div>
                            <div
                              style={{
                                fontSize: '12px',
                                color: 'hsl(0 0% 46%)',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                              }}
                            >
                              {T(v.profEmail)}
                            </div>
                            <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(v.profCargo)}</div>
                          </div>
                          {'\n        '}
                          <span
                            style={{
                              flex: 'none',
                              padding: '4px 10px',
                              borderRadius: '6px',
                              fontSize: '12px',
                              fontWeight: '600',
                              background: 'hsl(6 91% 47% / .1)',
                              color: 'hsl(6 91% 47%)',
                            }}
                          >
                            {T(v.roleLabel)}
                          </span>
                          {'\n      '}
                        </div>
                        {'\n      '}
                        <div style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', overflow: 'hidden' }}>
                          {'\n        '}
                          <button
                            onClick={v.onProfReport}
                            style={{
                              width: '100%',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              padding: '12px 14px',
                              border: 'none',
                              background: 'none',
                              cursor: 'pointer',
                              textAlign: 'left',
                              minHeight: '60px',
                            }}
                          >
                            {'\n          '}
                            <span
                              style={{
                                width: '38px',
                                height: '38px',
                                borderRadius: '11px',
                                background: 'hsl(6 91% 47% / .12)',
                                color: 'hsl(6 91% 47%)',
                                display: 'grid',
                                placeItems: 'center',
                                flex: 'none',
                              }}
                            >
                              <lu-icon name="message-square-text" size="18" />
                            </span>
                            {'\n          '}
                            <span style={{ flex: '1', minWidth: '0' }}>
                              <span style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: 'hsl(0 0% 13%)' }}>
                                {'Enviar feedback'}
                              </span>
                              <span style={{ display: 'block', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                {'Erros, bugs ou ideias, com texto livre e anexos'}
                              </span>
                            </span>
                            {'\n          '}
                            <lu-icon name="chevron-right" size="16" />
                            {'\n        '}
                          </button>
                          {'\n        '}
                          <button
                            onClick={v.onProfReports}
                            style={{
                              width: '100%',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              padding: '10px 14px',
                              border: 'none',
                              borderTop: '1px solid hsl(0 0% 93%)',
                              background: 'none',
                              cursor: 'pointer',
                              textAlign: 'left',
                              minHeight: '48px',
                              color: 'hsl(0 0% 13%)',
                            }}
                          >
                            {'\n          '}
                            <span style={{ width: '38px', display: 'grid', placeItems: 'center', color: 'hsl(0 0% 46%)', flex: 'none' }}>
                              <lu-icon name="history" size="17" />
                            </span>
                            {'\n          '}
                            <span style={{ flex: '1', fontSize: '13px', fontWeight: '500' }}>{'Meus feedbacks'}</span>
                            {'\n          '}
                            <span
                              style={{ fontSize: '12px', fontWeight: '600', color: 'hsl(0 0% 46%)', fontVariantNumeric: 'tabular-nums' }}
                            >
                              {T(v.profRepCount)}
                            </span>
                            {'\n          '}
                            <lu-icon name="chevron-right" size="16" />
                            {'\n        '}
                          </button>
                          {'\n      '}
                        </div>
                        {'\n      '}
                        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                          {'\n        '}
                          <button
                            onClick={v.onPtA}
                            style={css(
                              `padding:0 11px;min-height:44px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;white-space:nowrap;background:${S(v.ptA?.bg)};color:${S(v.ptA?.fg)};border:1px solid ${S(v.ptA?.bd)}`,
                            )}
                          >
                            {'Academy'}
                          </button>
                          {'\n        '}
                          <button
                            onClick={v.onPtD}
                            style={css(
                              `padding:0 11px;min-height:44px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;white-space:nowrap;background:${S(v.ptD?.bg)};color:${S(v.ptD?.fg)};border:1px solid ${S(v.ptD?.bd)}`,
                            )}
                          >
                            {'Dados pessoais'}
                          </button>
                          {'\n        '}
                          <button
                            onClick={v.onPtC}
                            style={css(
                              `padding:0 11px;min-height:44px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;white-space:nowrap;background:${S(v.ptC?.bg)};color:${S(v.ptC?.fg)};border:1px solid ${S(v.ptC?.bd)}`,
                            )}
                          >
                            {'Configurações'}
                          </button>
                          {'\n      '}
                        </div>
                        {'\n\n      '}
                        {v.isPtA ? (
                          <>
                            {'\n        '}
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                              {'\n          '}
                              {L(v.stats).map((k, $i16) => (
                                <Fragment key={$i16}>
                                  {'\n            '}
                                  <div
                                    style={{
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '15px',
                                      padding: '14px',
                                      boxShadow: '0 1px 3px rgba(0,0,0,.05)',
                                    }}
                                  >
                                    <span
                                      style={css(
                                        `width:34px;height:34px;border-radius:10px;background:${S(k?.bg)};color:${S(k?.fg)};display:grid;place-items:center;margin-bottom:10px`,
                                      )}
                                    >
                                      <lu-icon name={k?.icon} size="17" />
                                    </span>
                                    <div style={{ fontSize: '21px', fontWeight: '800', letterSpacing: '-.02em', lineHeight: '1.1' }}>
                                      {T(k?.val)}
                                    </div>
                                    <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', fontWeight: '500', marginTop: '2px' }}>
                                      {T(k?.label)}
                                    </div>
                                  </div>
                                  {'\n          '}
                                </Fragment>
                              ))}
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <div style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '16px' }}>
                              {'\n          '}
                              <h2
                                style={{
                                  margin: '0 0 12px',
                                  fontSize: '15px',
                                  fontWeight: '600',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="award" size="17" />
                                {'Emblemas'}
                              </h2>
                              {'\n          '}
                              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '12px' }}>
                                {'\n            '}
                                {L(v.emblems).map((b, $i17) => (
                                  <Fragment key={$i17}>
                                    {'\n              '}
                                    <div
                                      style={{
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        textAlign: 'center',
                                        gap: '4px',
                                      }}
                                    >
                                      <div
                                        style={css(
                                          `width:52px;height:58px;background:${S(b?.g)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%);display:grid;place-items:center;color:#fff`,
                                        )}
                                      >
                                        <lu-icon name={b?.icon} size="22" />
                                      </div>
                                      <div style={{ fontSize: '11.5px', fontWeight: '700', lineHeight: '1.25' }}>{T(b?.nome)}</div>
                                      <div style={{ fontSize: '10.5px', color: 'hsl(0 0% 46%)', lineHeight: '1.3' }}>{T(b?.sub)}</div>
                                      <div style={{ fontSize: '10px', color: 'hsl(0 0% 62%)' }}>{T(b?.prog)}</div>
                                    </div>
                                    {'\n            '}
                                  </Fragment>
                                ))}
                                {'\n          '}
                              </div>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <div style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '16px' }}>
                              {'\n          '}
                              <h2
                                style={{
                                  margin: '0 0 12px',
                                  fontSize: '15px',
                                  fontWeight: '600',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="graduation-cap" size="17" />
                                {'Certificados'}
                              </h2>
                              {'\n          '}
                              {v.noCerts ? (
                                <>
                                  <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                                    {'Vença o Desafio Mestre de uma trilha para receber o certificado.'}
                                  </div>
                                  <button
                                    onClick={v.onCertSample}
                                    style={{
                                      marginTop: '10px',
                                      minHeight: '40px',
                                      padding: '0 12px',
                                      borderRadius: '9px',
                                      border: '1px solid hsl(0 0% 90%)',
                                      background: '#fff',
                                      fontSize: '12.5px',
                                      fontWeight: '600',
                                      cursor: 'pointer',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: '6px',
                                      color: 'hsl(0 0% 13%)',
                                    }}
                                  >
                                    <lu-icon name="eye" size="14" />
                                    {'Ver modelo do certificado'}
                                  </button>
                                </>
                              ) : null}
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {'\n            '}
                                {L(v.certs).map((c, $i18) => (
                                  <Fragment key={$i18}>
                                    <button
                                      onClick={c?.onOpen}
                                      style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px',
                                        padding: '10px 12px',
                                        borderRadius: '12px',
                                        border: '1px solid hsl(0 0% 90%)',
                                        background: '#fff',
                                        cursor: 'pointer',
                                        textAlign: 'left',
                                        minHeight: '56px',
                                      }}
                                    >
                                      <span
                                        style={{
                                          width: '36px',
                                          height: '36px',
                                          borderRadius: '10px',
                                          background: 'linear-gradient(145deg,#FFD66B,#FF8A3D)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                        }}
                                      >
                                        <lu-icon name="file-badge" size="18" />
                                      </span>
                                      <span style={{ flex: '1' }}>
                                        <span style={{ display: 'block', fontSize: '13.5px', fontWeight: '600' }}>{T(c?.trilha)}</span>
                                        <span style={{ display: 'block', fontSize: '11.5px', color: 'hsl(0 0% 46%)' }}>
                                          {'Emitido em '}
                                          {T(c?.data)}
                                        </span>
                                      </span>
                                      <span
                                        onClick={c?.onPrint}
                                        role="button"
                                        aria-label="Imprimir certificado"
                                        style={{
                                          width: '40px',
                                          height: '40px',
                                          borderRadius: '9px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          color: 'hsl(6 91% 47%)',
                                          flex: 'none',
                                        }}
                                      >
                                        <lu-icon name="printer" size="16" />
                                      </span>
                                    </button>
                                  </Fragment>
                                ))}
                                {'\n          '}
                              </div>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <div style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '16px' }}>
                              {'\n          '}
                              <h2
                                style={{
                                  margin: '0 0 12px',
                                  fontSize: '15px',
                                  fontWeight: '600',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="route" size="17" />
                                {'Trilhas'}
                              </h2>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                                {'\n            '}
                                {L(v.trkRows).map((t, $i19) => (
                                  <Fragment key={$i19}>
                                    <button
                                      onClick={t?.onClick}
                                      style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '10px',
                                        border: 'none',
                                        background: 'none',
                                        padding: '0',
                                        cursor: 'pointer',
                                        textAlign: 'left',
                                        minHeight: '44px',
                                      }}
                                    >
                                      <span
                                        style={{
                                          width: '34px',
                                          height: '34px',
                                          borderRadius: '10px',
                                          background: 'hsl(6 91% 47% / .12)',
                                          color: 'hsl(6 91% 47%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          flex: 'none',
                                        }}
                                      >
                                        <lu-icon name={t?.icon} size="17" />
                                      </span>
                                      <span style={{ flex: '1', minWidth: '0' }}>
                                        <span
                                          style={{
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                            gap: '8px',
                                            fontSize: '13px',
                                            fontWeight: '600',
                                          }}
                                        >
                                          <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                            {T(t?.nome)}
                                          </span>
                                          <span style={{ color: 'hsl(0 0% 46%)', fontWeight: '500' }}>{T(t?.pct)}</span>
                                        </span>
                                        <span
                                          style={{
                                            display: 'block',
                                            height: '6px',
                                            borderRadius: '999px',
                                            background: 'hsl(0 0% 93%)',
                                            marginTop: '6px',
                                            overflow: 'hidden',
                                          }}
                                        >
                                          <span
                                            style={css(
                                              `display:block;height:100%;width:${S(t?.pct)};background:hsl(6 91% 47%);border-radius:999px`,
                                            )}
                                          />
                                        </span>
                                      </span>
                                    </button>
                                  </Fragment>
                                ))}
                                {'\n          '}
                              </div>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            {v.hasMates ? (
                              <>
                                {'\n        '}
                                <div
                                  style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '16px' }}
                                >
                                  {'\n          '}
                                  <h2
                                    style={{
                                      margin: '0 0 12px',
                                      fontSize: '15px',
                                      fontWeight: '600',
                                      display: 'flex',
                                      alignItems: 'center',
                                      gap: '8px',
                                    }}
                                  >
                                    <lu-icon name="users" size="17" />
                                    {'Colegas'}
                                  </h2>
                                  {'\n          '}
                                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                    {'\n            '}
                                    {L(v.mates).map((m, $i20) => (
                                      <Fragment key={$i20}>
                                        {'\n              '}
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                          {'\n                '}
                                          <span
                                            style={{
                                              position: 'relative',
                                              width: '40px',
                                              height: '40px',
                                              display: 'inline-flex',
                                              flex: 'none',
                                            }}
                                          >
                                            {m?.av?.has ? (
                                              <>
                                                <span
                                                  style={{
                                                    position: 'absolute',
                                                    top: '6px',
                                                    left: '6px',
                                                    width: '28px',
                                                    height: '28px',
                                                    borderRadius: '999px',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '10px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(m?.av?.ini)}
                                                </span>
                                                <span
                                                  style={css(
                                                    `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(m?.av?.src)}) center/contain no-repeat`,
                                                  )}
                                                />
                                              </>
                                            ) : null}
                                            {m?.av?.no ? (
                                              <>
                                                <span
                                                  style={{
                                                    width: '40px',
                                                    height: '40px',
                                                    borderRadius: '999px',
                                                    background: 'hsl(6 91% 47%)',
                                                    color: '#fff',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontSize: '13px',
                                                    fontWeight: '700',
                                                  }}
                                                >
                                                  {T(m?.av?.ini)}
                                                </span>
                                              </>
                                            ) : null}
                                          </span>
                                          {'\n                '}
                                          <span style={{ flex: '1', minWidth: '0' }}>
                                            <span style={{ display: 'block', fontSize: '13.5px', fontWeight: '600' }}>{T(m?.nome)}</span>
                                            <span style={{ display: 'block', fontSize: '11.5px', color: 'hsl(0 0% 46%)' }}>
                                              {T(m?.sub)}
                                            </span>
                                          </span>
                                          {'\n                '}
                                          {m?.canNudge ? (
                                            <>
                                              <button
                                                onClick={m?.onNudge}
                                                style={{
                                                  minHeight: '40px',
                                                  padding: '0 12px',
                                                  borderRadius: '9px',
                                                  border: '1px solid hsl(0 0% 90%)',
                                                  background: '#fff',
                                                  fontSize: '12px',
                                                  fontWeight: '600',
                                                  cursor: 'pointer',
                                                  display: 'flex',
                                                  alignItems: 'center',
                                                  gap: '6px',
                                                  color: 'hsl(0 0% 13%)',
                                                }}
                                              >
                                                <lu-icon name="hand" size="14" />
                                                {'Cutucar'}
                                              </button>
                                            </>
                                          ) : null}
                                          {'\n                '}
                                          {m?.nudged ? (
                                            <>
                                              <span style={{ fontSize: '11.5px', color: 'hsl(150 55% 40%)', fontWeight: '600' }}>
                                                {'Cutucado'}
                                              </span>
                                            </>
                                          ) : null}
                                          {'\n              '}
                                        </div>
                                        {'\n            '}
                                      </Fragment>
                                    ))}
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </div>
                                {'\n        '}
                              </>
                            ) : null}
                            {'\n        '}
                            {v.isLeaderUser ? (
                              <>
                                {'\n        '}
                                <div
                                  style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '16px' }}
                                >
                                  {'\n          '}
                                  <h2
                                    style={{
                                      margin: '0 0 4px',
                                      fontSize: '15px',
                                      fontWeight: '600',
                                      display: 'flex',
                                      alignItems: 'center',
                                      gap: '8px',
                                    }}
                                  >
                                    <lu-icon name="shield" size="17" />
                                    {'Visão do líder'}
                                  </h2>
                                  {'\n          '}
                                  <p style={{ margin: '0 0 12px', fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                    {T(v.leadMembers)}
                                    {' pessoas no time'}
                                  </p>
                                  {'\n          '}
                                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', marginBottom: '12px' }}>
                                    {'\n            '}
                                    <div
                                      style={{
                                        background: 'hsl(0 0% 98.5%)',
                                        border: '1px solid hsl(0 0% 93%)',
                                        borderRadius: '12px',
                                        padding: '10px',
                                      }}
                                    >
                                      <div style={{ fontSize: '18px', fontWeight: '800' }}>{T(v.leadPct)}</div>
                                      <div style={{ fontSize: '11px', color: 'hsl(0 0% 46%)' }}>{'progresso médio'}</div>
                                    </div>
                                    {'\n            '}
                                    <div
                                      style={{
                                        background: 'hsl(0 0% 98.5%)',
                                        border: '1px solid hsl(0 0% 93%)',
                                        borderRadius: '12px',
                                        padding: '10px',
                                      }}
                                    >
                                      <div style={{ fontSize: '12.5px', fontWeight: '700' }}>{T(v.leadDone)}</div>
                                    </div>
                                    {'\n            '}
                                    <div
                                      style={{
                                        background: 'hsl(0 0% 98.5%)',
                                        border: '1px solid hsl(0 0% 93%)',
                                        borderRadius: '12px',
                                        padding: '10px',
                                      }}
                                    >
                                      <div style={{ fontSize: '12.5px', fontWeight: '700' }}>{T(v.leadCerts)}</div>
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n          '}
                                  <div
                                    style={{
                                      fontSize: '11px',
                                      fontWeight: '700',
                                      letterSpacing: '.08em',
                                      textTransform: 'uppercase',
                                      color: 'hsl(0 0% 62%)',
                                      marginBottom: '6px',
                                    }}
                                  >
                                    {'Conceitos com mais erro'}
                                  </div>
                                  {'\n          '}
                                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '12px' }}>
                                    {L(v.leadWorst).map((w, $i21) => (
                                      <Fragment key={$i21}>
                                        <span
                                          style={{
                                            fontSize: '11px',
                                            fontWeight: '600',
                                            padding: '3px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(6 91% 47% / .12)',
                                            color: 'hsl(6 91% 47%)',
                                          }}
                                        >
                                          {T(w)}
                                        </span>
                                      </Fragment>
                                    ))}
                                  </div>
                                  {'\n          '}
                                  <button
                                    onClick={v.onOpenLeader}
                                    style={{
                                      width: '100%',
                                      minHeight: '44px',
                                      border: 'none',
                                      borderRadius: '10px',
                                      background: 'hsl(6 91% 47%)',
                                      color: '#fff',
                                      fontSize: '13px',
                                      fontWeight: '600',
                                      cursor: 'pointer',
                                      boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      gap: '8px',
                                    }}
                                  >
                                    {'Abrir modo líder'}
                                    <lu-icon name="arrow-right" size="15" />
                                  </button>
                                  {'\n        '}
                                </div>
                                {'\n        '}
                              </>
                            ) : null}
                            {'\n      '}
                          </>
                        ) : null}
                        {'\n\n      '}
                        {v.isPtD ? (
                          <>
                            {'\n        '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '12px',
                                padding: '16px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '16px',
                              }}
                            >
                              {'\n          '}
                              <h2 style={{ margin: '0', fontSize: '16px', fontWeight: '600' }}>{'Informações pessoais'}</h2>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Nome completo'}</label>
                                <input
                                  value={D(v.pfName, '')}
                                  onChange={v.onPfName}
                                  style={{
                                    height: '44px',
                                    borderRadius: '8px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    padding: '0 12px',
                                    fontSize: '14px',
                                  }}
                                />
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Telefone (WhatsApp)'}</label>
                                <input
                                  type="tel"
                                  value={D(v.pfPhone, '')}
                                  onChange={v.onPfPhone}
                                  placeholder="Ex.: (27) 99999-9999"
                                  style={{
                                    height: '44px',
                                    borderRadius: '8px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    padding: '0 12px',
                                    fontSize: '14px',
                                  }}
                                />
                                <span style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                  {'Usado pela Hubia para te enviar a senha temporária. Único por usuário.'}
                                </span>
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Equipe'}</label>
                                {'\n            '}
                                {v.canManage ? (
                                  <>
                                    <div style={{ position: 'relative' }}>
                                      <button
                                        onClick={v.pTeamDD?.toggle}
                                        style={{
                                          width: '100%',
                                          height: '44px',
                                          borderRadius: '8px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          background: '#fff',
                                          display: 'flex',
                                          alignItems: 'center',
                                          justifyContent: 'space-between',
                                          gap: '8px',
                                          padding: '0 14px',
                                          fontSize: '14px',
                                          color: 'hsl(0 0% 13%)',
                                          cursor: 'pointer',
                                          textAlign: 'left',
                                        }}
                                      >
                                        <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                          {T(v.pTeamDD?.label)}
                                        </span>
                                        <lu-icon name="chevron-down" size="16" />
                                      </button>
                                      {v.pTeamDD?.open ? (
                                        <>
                                          <div
                                            style={{
                                              position: 'absolute',
                                              top: 'calc(100% + 8px)',
                                              left: '0',
                                              right: '0',
                                              zIndex: '30',
                                              background: '#fff',
                                              border: '1px solid hsl(0 0% 90%)',
                                              borderRadius: '13px',
                                              boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                              padding: '6px',
                                              maxHeight: '232px',
                                              overflowY: 'auto',
                                              animation: 'modalIn .15s both',
                                            }}
                                          >
                                            {L(v.pTeamDD?.items).map((o, $i22) => (
                                              <Fragment key={$i22}>
                                                <button
                                                  onClick={o?.onClick}
                                                  style={css(
                                                    `width:100%;min-height:40px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border:none;border-radius:9px;background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:${S(o?.fw)};cursor:pointer;text-align:left`,
                                                  )}
                                                >
                                                  <span style={{ flex: '1', minWidth: '0', textAlign: 'left' }}>{T(o?.t)}</span>
                                                  {o?.sel ? (
                                                    <>
                                                      <lu-icon name="check" size="15" />
                                                    </>
                                                  ) : null}
                                                </button>
                                              </Fragment>
                                            ))}
                                          </div>
                                        </>
                                      ) : null}
                                    </div>
                                  </>
                                ) : null}
                                {'\n            '}
                                {v.cantManage ? (
                                  <>
                                    <div
                                      style={{
                                        height: '44px',
                                        borderRadius: '8px',
                                        border: '1px solid hsl(0 0% 90%)',
                                        background: 'hsl(0 0% 96%)',
                                        padding: '0 12px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        fontSize: '14px',
                                        color: 'hsl(0 0% 46%)',
                                      }}
                                    >
                                      {T(v.pfTeam)}
                                    </div>
                                    <span style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                      {'Definido pela gestão (admin/master).'}
                                    </span>
                                  </>
                                ) : null}
                                {'\n          '}
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Cargo'}</label>
                                <div
                                  style={{
                                    height: '44px',
                                    borderRadius: '8px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    background: 'hsl(0 0% 96%)',
                                    padding: '0 12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    fontSize: '14px',
                                    color: 'hsl(0 0% 46%)',
                                  }}
                                >
                                  {T(v.pfCargo)}
                                </div>
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                <button
                                  onClick={v.onPfSave}
                                  style={{
                                    minHeight: '44px',
                                    padding: '0 16px',
                                    border: 'none',
                                    borderRadius: '6px',
                                    background: 'hsl(6 91% 47%)',
                                    color: '#fff',
                                    fontSize: '14px',
                                    fontWeight: '500',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                  }}
                                >
                                  <lu-icon name="save" size="16" />
                                  {'Salvar'}
                                </button>
                              </div>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '12px',
                                padding: '16px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '16px',
                              }}
                            >
                              {'\n          '}
                              <h2 style={{ margin: '0', fontSize: '16px', fontWeight: '600' }}>{'Alterar senha'}</h2>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Nova senha'}</label>
                                <div style={{ position: 'relative' }}>
                                  <input
                                    type={v.pfPwdType}
                                    value={D(v.pfPwd, '')}
                                    onChange={v.onPfPwd}
                                    placeholder="Mínimo 6 caracteres"
                                    style={{
                                      width: '100%',
                                      height: '44px',
                                      borderRadius: '8px',
                                      border: '1px solid hsl(0 0% 90%)',
                                      padding: '0 44px 0 12px',
                                      fontSize: '14px',
                                    }}
                                  />
                                  <button
                                    onClick={v.onPfEye}
                                    aria-label="Mostrar senha"
                                    style={{
                                      position: 'absolute',
                                      right: '0',
                                      top: '0',
                                      width: '44px',
                                      height: '44px',
                                      border: 'none',
                                      background: 'none',
                                      color: 'hsl(0 0% 46%)',
                                      display: 'grid',
                                      placeItems: 'center',
                                      cursor: 'pointer',
                                    }}
                                  >
                                    <lu-icon name={v.pfEye} size="16" />
                                  </button>
                                </div>
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <label style={{ fontSize: '14px', fontWeight: '600' }}>{'Confirmar nova senha'}</label>
                                <input
                                  type={v.pfPwdType}
                                  value={D(v.pfPwd2, '')}
                                  onChange={v.onPfPwd2}
                                  placeholder="Repita a nova senha"
                                  style={{
                                    height: '44px',
                                    borderRadius: '8px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    padding: '0 12px',
                                    fontSize: '14px',
                                  }}
                                />
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                <button
                                  onClick={v.onPfPwdSave}
                                  style={{
                                    minHeight: '44px',
                                    padding: '0 16px',
                                    border: 'none',
                                    borderRadius: '6px',
                                    background: 'hsl(6 91% 47%)',
                                    color: '#fff',
                                    fontSize: '14px',
                                    fontWeight: '500',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                  }}
                                >
                                  <lu-icon name="save" size="16" />
                                  {'Alterar senha'}
                                </button>
                              </div>
                              {'\n        '}
                            </div>
                            {'\n      '}
                          </>
                        ) : null}
                        {'\n\n      '}
                        {v.isPtC ? (
                          <>
                            {'\n        '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '12px',
                                padding: '16px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '18px',
                              }}
                            >
                              {'\n          '}
                              <div>
                                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>{'Meta diária'}</div>
                                <div
                                  style={{ display: 'flex', background: 'hsl(0 0% 95%)', borderRadius: '8px', padding: '4px', gap: '2px' }}
                                >
                                  {L(v.cfgGoals).map((g, $i23) => (
                                    <Fragment key={$i23}>
                                      <button
                                        onClick={g?.onClick}
                                        style={css(
                                          `flex:1;min-height:40px;border:none;border-radius:6px;background:${S(g?.bg)};color:${S(g?.fg)};box-shadow:${S(g?.sh)};font-size:13px;font-weight:500;cursor:pointer`,
                                        )}
                                      >
                                        {T(g?.t)}
                                      </button>
                                    </Fragment>
                                  ))}
                                </div>
                              </div>
                              {'\n          '}
                              <div>
                                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '2px' }}>{'Dias de trabalho'}</div>
                                <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginBottom: '8px' }}>
                                  {'A ofensiva conta só esses dias.'}
                                </div>
                                <div style={{ display: 'flex', gap: '6px' }}>
                                  {L(v.cfgDays).map((d, $i24) => (
                                    <Fragment key={$i24}>
                                      <button
                                        onClick={d?.onClick}
                                        style={css(
                                          `flex:1;height:44px;border-radius:10px;border:1px solid ${S(d?.bd)};background:${S(d?.bg)};color:${S(d?.fg)};font-size:13px;font-weight:700;cursor:pointer`,
                                        )}
                                      >
                                        {T(d?.l)}
                                      </button>
                                    </Fragment>
                                  ))}
                                </div>
                              </div>
                              {'\n          '}
                              <div>
                                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>{'Horário do lembrete'}</div>
                                <div style={{ display: 'flex', gap: '6px' }} data-comment-anchor="77c2ab2c9a-div">
                                  {L(v.cfgRem).map((r, $i25) => (
                                    <Fragment key={$i25}>
                                      <button
                                        onClick={r?.onClick}
                                        style={css(
                                          `flex:1;white-space:nowrap;min-height:40px;padding:0 6px;border-radius:999px;border:1px solid ${S(r?.bd)};background:${S(r?.bg)};color:${S(r?.fg)};font-size:13px;font-weight:600;cursor:pointer`,
                                        )}
                                      >
                                        {T(r?.t)}
                                      </button>
                                    </Fragment>
                                  ))}
                                </div>
                                {true ? (
                                  <>
                                    <div
                                      style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: '6px',
                                        padding: '12px 8px',
                                        borderRadius: '14px',
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        marginTop: '10px',
                                        animation: 'up8 .25s both',
                                      }}
                                    >
                                      <button
                                        onClick={v.cfgTime?.hDown}
                                        aria-label="Menos uma hora"
                                        style={{
                                          width: '36px',
                                          height: '44px',
                                          borderRadius: '10px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          background: '#fff',
                                          color: 'hsl(0 0% 46%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                        }}
                                      >
                                        <lu-icon name="minus" size="16" />
                                      </button>
                                      <input
                                        value={D(v.cfgTime?.hh, '')}
                                        onChange={v.cfgTime?.onH}
                                        onFocus={v.cfgTime?.focus}
                                        inputMode="numeric"
                                        aria-label="Hora"
                                        style={{
                                          width: '62px',
                                          height: '52px',
                                          borderRadius: '10px',
                                          border: '1.5px solid hsl(0 0% 90%)',
                                          background: 'hsl(0 0% 98.5%)',
                                          fontSize: '28px',
                                          fontWeight: '800',
                                          letterSpacing: '-.02em',
                                          fontVariantNumeric: 'tabular-nums',
                                          textAlign: 'center',
                                          padding: '0',
                                          color: 'hsl(0 0% 13%)',
                                        }}
                                      />
                                      <button
                                        onClick={v.cfgTime?.hUp}
                                        aria-label="Mais uma hora"
                                        style={{
                                          width: '36px',
                                          height: '44px',
                                          borderRadius: '10px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          background: '#fff',
                                          color: 'hsl(0 0% 46%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                        }}
                                      >
                                        <lu-icon name="plus" size="16" />
                                      </button>
                                      <span style={{ fontSize: '28px', fontWeight: '800', color: 'hsl(0 0% 62%)' }}>{':'}</span>
                                      <button
                                        onClick={v.cfgTime?.mDown}
                                        aria-label="Menos 5 minutos"
                                        style={{
                                          width: '36px',
                                          height: '44px',
                                          borderRadius: '10px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          background: '#fff',
                                          color: 'hsl(0 0% 46%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                        }}
                                      >
                                        <lu-icon name="minus" size="16" />
                                      </button>
                                      <input
                                        value={D(v.cfgTime?.mm, '')}
                                        onChange={v.cfgTime?.onM}
                                        onFocus={v.cfgTime?.focus}
                                        inputMode="numeric"
                                        aria-label="Minuto"
                                        style={{
                                          width: '62px',
                                          height: '52px',
                                          borderRadius: '10px',
                                          border: '1.5px solid hsl(0 0% 90%)',
                                          background: 'hsl(0 0% 98.5%)',
                                          fontSize: '28px',
                                          fontWeight: '800',
                                          letterSpacing: '-.02em',
                                          fontVariantNumeric: 'tabular-nums',
                                          textAlign: 'center',
                                          padding: '0',
                                          color: 'hsl(0 0% 13%)',
                                        }}
                                      />
                                      <button
                                        onClick={v.cfgTime?.mUp}
                                        aria-label="Mais 5 minutos"
                                        style={{
                                          width: '36px',
                                          height: '44px',
                                          borderRadius: '10px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          background: '#fff',
                                          color: 'hsl(0 0% 46%)',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                        }}
                                      >
                                        <lu-icon name="plus" size="16" />
                                      </button>
                                    </div>
                                  </>
                                ) : null}
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: '44px' }}>
                                <div>
                                  <div style={{ fontSize: '14px', fontWeight: '600' }}>{'Sons'}</div>
                                  <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{'Acerto, erro e conclusão'}</div>
                                </div>
                                <button
                                  onClick={v.onSound}
                                  aria-label="Sons"
                                  style={{
                                    width: '44px',
                                    height: '44px',
                                    border: 'none',
                                    background: 'none',
                                    display: 'grid',
                                    placeItems: 'center',
                                    cursor: 'pointer',
                                    padding: '0',
                                  }}
                                >
                                  <span
                                    style={css(
                                      `position:relative;width:38px;height:22px;border-radius:999px;background:${S(v.soundBg)};transition:background .15s`,
                                    )}
                                  >
                                    <span
                                      style={css(
                                        `position:absolute;top:2px;left:${S(v.soundKnob)};width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .15s`,
                                      )}
                                    />
                                  </span>
                                </button>
                              </div>
                              {'\n          '}
                              <div>
                                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>{'Trocar persona'}</div>
                                <div style={{ position: 'relative' }}>
                                  <button
                                    onClick={v.personaDD?.toggle}
                                    style={{
                                      width: '100%',
                                      height: '44px',
                                      borderRadius: '8px',
                                      border: '1px solid hsl(0 0% 90%)',
                                      background: '#fff',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'space-between',
                                      gap: '8px',
                                      padding: '0 14px',
                                      fontSize: '14px',
                                      color: 'hsl(0 0% 13%)',
                                      cursor: 'pointer',
                                      textAlign: 'left',
                                    }}
                                  >
                                    <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                      {T(v.personaDD?.label)}
                                    </span>
                                    <lu-icon name="chevron-down" size="16" />
                                  </button>
                                  {v.personaDD?.open ? (
                                    <>
                                      <div
                                        style={{
                                          position: 'absolute',
                                          top: 'calc(100% + 8px)',
                                          left: '0',
                                          right: '0',
                                          zIndex: '30',
                                          background: '#fff',
                                          border: '1px solid hsl(0 0% 90%)',
                                          borderRadius: '13px',
                                          boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                          padding: '6px',
                                          maxHeight: '232px',
                                          overflowY: 'auto',
                                          animation: 'modalIn .15s both',
                                        }}
                                      >
                                        {L(v.personaDD?.items).map((o, $i26) => (
                                          <Fragment key={$i26}>
                                            <button
                                              onClick={o?.onClick}
                                              style={css(
                                                `width:100%;min-height:40px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border:none;border-radius:9px;background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:${S(o?.fw)};cursor:pointer;text-align:left`,
                                              )}
                                            >
                                              <span style={{ flex: '1', minWidth: '0', textAlign: 'left' }}>{T(o?.t)}</span>
                                              {o?.sel ? (
                                                <>
                                                  <lu-icon name="check" size="15" />
                                                </>
                                              ) : null}
                                            </button>
                                          </Fragment>
                                        ))}
                                      </div>
                                    </>
                                  ) : null}
                                </div>
                              </div>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px dashed hsl(0 0% 80%)',
                                borderRadius: '12px',
                                padding: '16px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '14px',
                              }}
                            >
                              {'\n          '}
                              <div
                                style={{
                                  fontSize: '11px',
                                  fontWeight: '700',
                                  letterSpacing: '.08em',
                                  textTransform: 'uppercase',
                                  color: 'hsl(0 0% 62%)',
                                }}
                              >
                                {'Protótipo · simulações'}
                              </div>
                              {'\n          '}
                              <div>
                                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>{'Perfil de acesso'}</div>
                                <div
                                  style={{ display: 'flex', background: 'hsl(0 0% 95%)', borderRadius: '8px', padding: '4px', gap: '2px' }}
                                >
                                  {L(v.cfgRoles).map((g, $i27) => (
                                    <Fragment key={$i27}>
                                      <button
                                        onClick={g?.onClick}
                                        style={css(
                                          `flex:1;min-height:40px;border:none;border-radius:6px;background:${S(g?.bg)};color:${S(g?.fg)};box-shadow:${S(g?.sh)};font-size:12.5px;font-weight:500;cursor:pointer`,
                                        )}
                                      >
                                        {T(g?.t)}
                                      </button>
                                    </Fragment>
                                  ))}
                                </div>
                              </div>
                              {'\n          '}
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: '44px' }}>
                                <div style={{ fontSize: '14px', fontWeight: '600' }}>{'Simular offline'}</div>
                                <button
                                  onClick={v.onOffSim}
                                  aria-label="Simular offline"
                                  style={{
                                    width: '44px',
                                    height: '44px',
                                    border: 'none',
                                    background: 'none',
                                    display: 'grid',
                                    placeItems: 'center',
                                    cursor: 'pointer',
                                    padding: '0',
                                  }}
                                >
                                  <span
                                    style={css(
                                      `position:relative;width:38px;height:22px;border-radius:999px;background:${S(v.offBg)};transition:background .15s`,
                                    )}
                                  >
                                    <span
                                      style={css(
                                        `position:absolute;top:2px;left:${S(v.offKnob)};width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .15s`,
                                      )}
                                    />
                                  </span>
                                </button>
                              </div>
                              {'\n          '}
                              <button
                                onClick={v.onAdvanceDay}
                                style={{
                                  minHeight: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  fontSize: '13px',
                                  fontWeight: '500',
                                  cursor: 'pointer',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                  color: 'hsl(0 0% 13%)',
                                }}
                              >
                                <lu-icon name="calendar-plus" size="16" />
                                {'Avançar um dia'}
                              </button>
                              {'\n          '}
                              <button
                                onClick={v.onResetAsk}
                                style={{
                                  minHeight: '44px',
                                  borderRadius: '10px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  color: 'hsl(6 91% 47%)',
                                  fontSize: '13px',
                                  fontWeight: '500',
                                  cursor: 'pointer',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="rotate-ccw" size="16" />
                                {'Resetar progresso'}
                              </button>
                              {'\n        '}
                            </div>
                            {'\n        '}
                            <button
                              onClick={v.onLogout}
                              style={{
                                minHeight: '44px',
                                borderRadius: '10px',
                                border: '1px solid hsl(0 0% 90%)',
                                background: '#fff',
                                color: 'hsl(0 0% 13%)',
                                fontSize: '13px',
                                fontWeight: '500',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px',
                              }}
                            >
                              <lu-icon name="log-out" size="16" />
                              {'Sair'}
                            </button>
                            {'\n      '}
                          </>
                        ) : null}
                        {'\n    '}
                      </div>
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n\n  '}
                {v.isSub ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        display: 'flex',
                        flexDirection: 'column',
                        animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                      }}
                    >
                      {'\n    '}
                      <div
                        style={{
                          flex: 'none',
                          position: 'relative',
                          zIndex: '30',
                          background: 'hsla(0,0%,100%,.82)',
                          backdropFilter: 'blur(16px) saturate(1.6)',
                          borderBottom: '1px solid hsl(0 0% 90%)',
                          padding: '10px 14px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                        }}
                      >
                        {'\n      '}
                        <button
                          onClick={v.onSubBack}
                          aria-label="Voltar"
                          style={{
                            width: '44px',
                            height: '44px',
                            borderRadius: '12px',
                            border: '1px solid hsl(0 0% 90%)',
                            background: '#fff',
                            color: 'hsl(0 0% 46%)',
                            display: 'grid',
                            placeItems: 'center',
                            cursor: 'pointer',
                          }}
                        >
                          <lu-icon name="chevron-left" size="20" />
                        </button>
                        {'\n      '}
                        <span
                          style={{
                            width: '38px',
                            height: '38px',
                            borderRadius: '11px',
                            background: 'hsl(6 91% 47% / .12)',
                            color: 'hsl(6 91% 47%)',
                            display: 'grid',
                            placeItems: 'center',
                          }}
                        >
                          <lu-icon name={v.subIcon} size="18" />
                        </span>
                        {'\n      '}
                        <div style={{ minWidth: '0', flex: '1' }}>
                          <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', fontWeight: '500', whiteSpace: 'nowrap' }}>
                            {T(v.subCrumb)}
                          </div>
                          <div
                            style={{
                              fontSize: '18px',
                              fontWeight: '700',
                              letterSpacing: '-.01em',
                              lineHeight: '1.15',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {T(v.subTitle)}
                          </div>
                        </div>
                        {'\n    '}
                      </div>
                      {'\n    '}
                      <div style={{ flex: '1', minHeight: '0', overflowY: 'auto' }}>
                        {'\n    '}
                        {v.subLoja ? (
                          <>
                            {'\n      '}
                            <div
                              style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}
                              data-comment-anchor="c6164793ad-div"
                            >
                              {'\n        '}
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                                {'\n          '}
                                <p style={{ margin: '0', fontSize: '13px', color: 'hsl(0 0% 46%)', flex: '1' }}>
                                  {'Troque seus Takitos por cosméticos e personalize seu perfil.'}
                                </p>
                                {'\n          '}
                                <div
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    borderRadius: '12px',
                                    background: 'hsl(38 92% 50% / .1)',
                                    padding: '10px 14px',
                                    flex: 'none',
                                  }}
                                >
                                  <img src="assets/academy-book.png" width="28" height="28" alt="" />
                                  <div>
                                    <div
                                      style={{ fontSize: '19px', fontWeight: '700', lineHeight: '1', fontVariantNumeric: 'tabular-nums' }}
                                    >
                                      {T(v.lojaSaldo)}
                                    </div>
                                    <div style={{ fontSize: '11px', color: 'hsl(0 0% 46%)' }}>{'Takitos'}</div>
                                  </div>
                                </div>
                                {'\n        '}
                              </div>
                              {'\n        '}
                              <div
                                style={{ display: 'flex', background: 'hsl(0 0% 95%)', borderRadius: '8px', padding: '4px', gap: '2px' }}
                              >
                                {L(v.lojaTabs).map((t, $i28) => (
                                  <Fragment key={$i28}>
                                    <button
                                      onClick={t?.onClick}
                                      style={css(
                                        `flex:1;min-height:40px;border:none;border-radius:6px;background:${S(t?.bg)};color:${S(t?.fg)};box-shadow:${S(t?.sh)};font-size:12.5px;font-weight:600;cursor:pointer;white-space:nowrap`,
                                      )}
                                    >
                                      {T(t?.t)}
                                    </button>
                                  </Fragment>
                                ))}
                              </div>
                              {'\n        '}
                              <button
                                onClick={v.onOpenResgate}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '10px',
                                  padding: '12px 14px',
                                  border: '1px solid hsl(38 92% 50% / .3)',
                                  background: 'hsl(38 92% 50% / .05)',
                                  borderRadius: '8px',
                                  cursor: 'pointer',
                                  textAlign: 'left',
                                  minHeight: '56px',
                                }}
                              >
                                <span style={{ color: '#d97706', display: 'grid' }}>
                                  <lu-icon name="gift" size="20" />
                                </span>
                                <span style={{ flex: '1', fontSize: '14px', fontWeight: '600', color: 'hsl(0 0% 13%)' }}>
                                  {'Tem um código? Resgatar'}
                                </span>
                                <lu-icon name="chevron-right" size="16" />
                              </button>
                              {'\n        '}
                              <div style={{ position: 'relative' }}>
                                <span
                                  style={{
                                    position: 'absolute',
                                    left: '12px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    color: 'hsl(0 0% 46%)',
                                    display: 'grid',
                                  }}
                                >
                                  <lu-icon name="search" size="16" />
                                </span>
                                <input
                                  value={D(v.lojaBusca, '')}
                                  onChange={v.onLojaBusca}
                                  placeholder={v.lojaPh}
                                  style={{
                                    width: '100%',
                                    height: '44px',
                                    borderRadius: '6px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    padding: '0 12px 0 36px',
                                    fontSize: '14px',
                                  }}
                                />
                              </div>
                              {'\n        '}
                              <div style={{ position: 'relative' }} data-tier="">
                                <button
                                  onClick={v.tierDD?.toggle}
                                  style={{
                                    width: '100%',
                                    height: '44px',
                                    borderRadius: '6px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    background: '#fff',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    gap: '8px',
                                    padding: '0 14px',
                                    fontSize: '14px',
                                    color: 'hsl(0 0% 13%)',
                                    cursor: 'pointer',
                                    textAlign: 'left',
                                  }}
                                >
                                  <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    {T(v.tierDD?.label)}
                                  </span>
                                  <lu-icon name="chevron-down" size="16" />
                                </button>
                                {v.tierDD?.open ? (
                                  <>
                                    <div
                                      style={{
                                        position: 'absolute',
                                        top: 'calc(100% + 8px)',
                                        left: '0',
                                        right: '0',
                                        zIndex: '30',
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        borderRadius: '13px',
                                        boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                        padding: '6px',
                                        maxHeight: '232px',
                                        overflowY: 'auto',
                                        animation: 'modalIn .15s both',
                                      }}
                                      data-comment-anchor="a4ae08f335-div"
                                    >
                                      {L(v.tierDD?.items).map((o, $i29) => (
                                        <Fragment key={$i29}>
                                          <button
                                            onClick={o?.onClick}
                                            style={css(
                                              `width:100%;min-height:40px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border:none;border-radius:9px;background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:${S(o?.fw)};cursor:pointer;text-align:left`,
                                            )}
                                          >
                                            <span
                                              style={css(`width:9px;height:9px;border-radius:999px;background:${S(o?.dot)};flex:none`)}
                                            />
                                            <span style={{ flex: '1', minWidth: '0', textAlign: 'left' }}>{T(o?.t)}</span>
                                            {o?.sel ? (
                                              <>
                                                <lu-icon name="check" size="15" />
                                              </>
                                            ) : null}
                                          </button>
                                        </Fragment>
                                      ))}
                                    </div>
                                  </>
                                ) : null}
                              </div>
                              {'\n        '}
                              {v.lojaEmpty ? (
                                <>
                                  <div style={{ textAlign: 'center', padding: '48px 0', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                                    {'Nada encontrado com esses filtros.'}
                                  </div>
                                </>
                              ) : null}
                              {'\n        '}
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                                {'\n          '}
                                {L(v.lojaItems).map((i, $i30) => (
                                  <Fragment key={$i30}>
                                    {'\n            '}
                                    <div
                                      style={css(
                                        `display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 12px;border-radius:8px;border:1px solid hsl(0 0% 90%);border-top:${S(i?.top)};background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.05);transition:transform .2s, box-shadow .2s`,
                                      )}
                                      className="scp3"
                                    >
                                      {'\n              '}
                                      <div
                                        style={{
                                          alignSelf: 'stretch',
                                          display: 'flex',
                                          alignItems: 'center',
                                          justifyContent: 'space-between',
                                          marginBottom: '4px',
                                        }}
                                      >
                                        <span
                                          style={css(
                                            `border-radius:999px;padding:2px 8px;font-size:10px;font-weight:600;background:${S(i?.rbg)};color:${S(i?.rfg)}`,
                                          )}
                                        >
                                          {T(i?.rar)}
                                        </span>
                                        {i?.eq ? (
                                          <>
                                            <span
                                              style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '3px',
                                                fontSize: '10px',
                                                fontWeight: '600',
                                                color: '#059669',
                                              }}
                                            >
                                              <lu-icon name="check" size="12" />
                                              {'Em uso'}
                                            </span>
                                          </>
                                        ) : null}
                                      </div>
                                      {'\n              '}
                                      {i?.isMold ? (
                                        <>
                                          <span
                                            style={{
                                              position: 'relative',
                                              width: '96px',
                                              height: '96px',
                                              display: 'inline-flex',
                                              margin: '6px 0',
                                            }}
                                          >
                                            <span
                                              style={{
                                                position: 'absolute',
                                                top: '13px',
                                                left: '13px',
                                                width: '70px',
                                                height: '70px',
                                                borderRadius: '999px',
                                                background: 'hsl(6 91% 47%)',
                                                color: '#fff',
                                                display: 'grid',
                                                placeItems: 'center',
                                                fontSize: '24px',
                                                fontWeight: '700',
                                              }}
                                            >
                                              {T(i?.av?.ini)}
                                            </span>
                                            <span
                                              style={css(
                                                `position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;background:url(${S(i?.av?.src)}) center/contain no-repeat`,
                                              )}
                                            />
                                          </span>
                                        </>
                                      ) : null}
                                      {'\n              '}
                                      {i?.isItem ? (
                                        <>
                                          <span
                                            style={{
                                              width: '96px',
                                              height: '96px',
                                              margin: '6px 0',
                                              borderRadius: '999px',
                                              background: 'hsl(40 92% 46% / .12)',
                                              color: 'hsl(40 92% 46%)',
                                              display: 'grid',
                                              placeItems: 'center',
                                            }}
                                          >
                                            <lu-icon name={i?.icon} size="40" />
                                          </span>
                                        </>
                                      ) : null}
                                      {'\n              '}
                                      {i?.isFundo ? (
                                        <>
                                          <span
                                            style={css(
                                              `align-self:stretch;height:96px;margin:6px 0;border-radius:10px;background:${S(i?.g)};box-shadow:inset 0 0 0 1px rgba(0,0,0,.06);position:relative;overflow:hidden`,
                                            )}
                                          >
                                            <span
                                              style={{
                                                position: 'absolute',
                                                left: '10px',
                                                bottom: '10px',
                                                width: '34px',
                                                height: '34px',
                                                borderRadius: '999px',
                                                background: 'rgba(255,255,255,.92)',
                                                border: '2px solid #fff',
                                              }}
                                            />
                                            <span
                                              style={{
                                                position: 'absolute',
                                                left: '52px',
                                                bottom: '22px',
                                                width: '46px',
                                                height: '7px',
                                                borderRadius: '999px',
                                                background: 'rgba(255,255,255,.85)',
                                              }}
                                            />
                                            <span
                                              style={{
                                                position: 'absolute',
                                                left: '52px',
                                                bottom: '12px',
                                                width: '30px',
                                                height: '6px',
                                                borderRadius: '999px',
                                                background: 'rgba(255,255,255,.6)',
                                              }}
                                            />
                                          </span>
                                        </>
                                      ) : null}
                                      {'\n              '}
                                      {i?.isIcone ? (
                                        <>
                                          <span
                                            style={{
                                              width: '96px',
                                              height: '96px',
                                              margin: '6px 0',
                                              borderRadius: '24px',
                                              background: 'hsl(6 91% 47% / .10)',
                                              color: 'hsl(6 91% 47%)',
                                              display: 'grid',
                                              placeItems: 'center',
                                            }}
                                          >
                                            <lu-icon name={i?.icon} size="42" stroke="2" />
                                          </span>
                                        </>
                                      ) : null}
                                      {'\n              '}
                                      <div style={{ fontSize: '13.5px', fontWeight: '600', textAlign: 'center', lineHeight: '1.25' }}>
                                        {T(i?.nome)}
                                      </div>
                                      {'\n              '}
                                      <div style={{ fontSize: '11px', color: 'hsl(0 0% 46%)', marginBottom: '4px' }}>{T(i?.col)}</div>
                                      {'\n              '}
                                      <div style={{ marginTop: 'auto', marginBottom: '8px', fontSize: '14px', fontWeight: '700' }}>
                                        {'\n                '}
                                        {i?.isCod ? (
                                          <>
                                            <span
                                              style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '4px',
                                                fontSize: '12px',
                                                color: 'hsl(0 0% 46%)',
                                              }}
                                            >
                                              <lu-icon name="lock" size="14" />
                                              {'Só por código'}
                                            </span>
                                          </>
                                        ) : null}
                                        {'\n                '}
                                        {i?.isGratis ? (
                                          <>
                                            <span style={{ color: '#059669' }}>{'Grátis'}</span>
                                          </>
                                        ) : null}
                                        {'\n                '}
                                        {i?.isPago ? (
                                          <>
                                            <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#d97706' }}>
                                              <img src="assets/academy-book.png" width="18" height="18" alt="" />
                                              {T(i?.preco)}
                                            </span>
                                          </>
                                        ) : null}
                                        {'\n              '}
                                      </div>
                                      {'\n              '}
                                      <button
                                        onClick={i?.onClick}
                                        disabled={i?.dis}
                                        style={css(
                                          `width:100%;min-height:40px;border-radius:6px;border:1px solid ${S(i?.btnBd)};background:${S(i?.btnBg)};color:${S(i?.btnFg)};font-size:12.5px;font-weight:500;cursor:pointer`,
                                        )}
                                      >
                                        {T(i?.btn)}
                                      </button>
                                      {'\n            '}
                                    </div>
                                    {'\n          '}
                                  </Fragment>
                                ))}
                                {'\n        '}
                              </div>
                              {'\n      '}
                            </div>
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subReports ? (
                          <>
                            {'\n      '}
                            <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                              {'\n        '}
                              <button
                                onClick={v.onRepNew}
                                style={{
                                  width: '100%',
                                  height: '50px',
                                  border: 'none',
                                  borderRadius: '12px',
                                  background: 'hsl(6 91% 47%)',
                                  color: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '700',
                                  cursor: 'pointer',
                                  boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="plus" size="17" />
                                {'Novo feedback'}
                              </button>
                              {'\n        '}
                              {v.repListEmpty ? (
                                <>
                                  <div
                                    style={{
                                      padding: '36px 20px',
                                      textAlign: 'center',
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '14px',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      alignItems: 'center',
                                      gap: '8px',
                                    }}
                                  >
                                    <span
                                      style={{
                                        width: '52px',
                                        height: '52px',
                                        borderRadius: '14px',
                                        background: 'hsl(0 0% 95%)',
                                        color: 'hsl(0 0% 46%)',
                                        display: 'grid',
                                        placeItems: 'center',
                                      }}
                                    >
                                      <lu-icon name="inbox" size="24" />
                                    </span>
                                    <div style={{ fontSize: '14px', fontWeight: '600' }}>{'Nenhum feedback enviado ainda'}</div>
                                    <div style={{ fontSize: '12.5px', color: 'hsl(0 0% 46%)', maxWidth: '30ch' }}>
                                      {'Use a bandeira nas questões ou o link nas fases para reportar algo específico.'}
                                    </div>
                                  </div>
                                </>
                              ) : null}
                              {'\n        '}
                              {L(v.repList).map((f, $i31) => (
                                <Fragment key={$i31}>
                                  {'\n          '}
                                  <button
                                    onClick={f?.onOpen}
                                    style={{
                                      width: '100%',
                                      textAlign: 'left',
                                      cursor: 'pointer',
                                      fontFamily: 'inherit',
                                      color: 'inherit',
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '14px',
                                      padding: '12px 14px',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '6px',
                                      transition: 'transform .2s, box-shadow .2s',
                                    }}
                                    data-comment-anchor="cf19be2091-div"
                                    className="scp4"
                                  >
                                    {'\n            '}
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                      <span
                                        style={{
                                          fontSize: '10.5px',
                                          fontWeight: '700',
                                          padding: '2px 8px',
                                          borderRadius: '999px',
                                          background: 'hsl(0 0% 95%)',
                                          color: 'hsl(0 0% 40%)',
                                          whiteSpace: 'nowrap',
                                        }}
                                      >
                                        {T(f?.cat)}
                                      </span>
                                      <span style={{ flex: '1', fontSize: '11px', color: 'hsl(0 0% 62%)', whiteSpace: 'nowrap' }}>
                                        {T(f?.id)}
                                        {' · '}
                                        {T(f?.data)}
                                      </span>
                                      {f?.ok ? (
                                        <>
                                          <span
                                            style={{
                                              display: 'flex',
                                              alignItems: 'center',
                                              gap: '4px',
                                              fontSize: '11px',
                                              fontWeight: '600',
                                              color: 'hsl(150 55% 38%)',
                                              whiteSpace: 'nowrap',
                                            }}
                                          >
                                            <lu-icon name="circle-check" size="14" />
                                            {'Na nuvem'}
                                          </span>
                                        </>
                                      ) : null}
                                      {f?.pend ? (
                                        <>
                                          <span
                                            style={{
                                              display: 'flex',
                                              alignItems: 'center',
                                              gap: '4px',
                                              fontSize: '11px',
                                              fontWeight: '600',
                                              color: 'hsl(32 82% 40%)',
                                              whiteSpace: 'nowrap',
                                            }}
                                          >
                                            <lu-icon name="cloud-off" size="14" />
                                            {'Pendente'}
                                          </span>
                                        </>
                                      ) : null}
                                    </div>
                                    {'\n            '}
                                    <div
                                      style={{
                                        fontSize: '12px',
                                        fontWeight: '600',
                                        color: 'hsl(6 91% 47%)',
                                        overflow: 'hidden',
                                        display: '-webkit-box',
                                        WebkitLineClamp: '1',
                                        WebkitBoxOrient: 'vertical',
                                      }}
                                    >
                                      {T(f?.ctx)}
                                    </div>
                                    {'\n            '}
                                    <div
                                      style={{
                                        fontSize: '13px',
                                        lineHeight: '1.5',
                                        color: 'hsl(0 0% 20%)',
                                        whiteSpace: 'pre-wrap',
                                        overflow: 'hidden',
                                        display: '-webkit-box',
                                        WebkitLineClamp: '4',
                                        WebkitBoxOrient: 'vertical',
                                      }}
                                    >
                                      {T(f?.texto)}
                                    </div>
                                    {'\n            '}
                                    {f?.hasAnexos ? (
                                      <>
                                        <div
                                          style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '5px',
                                            fontSize: '11.5px',
                                            color: 'hsl(0 0% 46%)',
                                          }}
                                        >
                                          <lu-icon name="paperclip" size="13" />
                                          {T(f?.anexos)}
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n          '}
                                  </button>
                                  {'\n        '}
                                </Fragment>
                              ))}
                              {'\n      '}
                            </div>
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subReportView ? (
                          <>
                            {'\n      '}
                            {v.rvNone ? (
                              <>
                                <div style={{ padding: '48px 20px', textAlign: 'center', fontSize: '13.5px', color: 'hsl(0 0% 46%)' }}>
                                  {'Feedback não encontrado.'}
                                </div>
                              </>
                            ) : null}
                            {'\n      '}
                            {v.rvSome ? (
                              <>
                                {'\n      '}
                                <div
                                  style={{
                                    padding: '16px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '12px',
                                    animation: 'up8 .3s both',
                                  }}
                                >
                                  {'\n        '}
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                                    {'\n          '}
                                    <span
                                      style={{
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        gap: '6px',
                                        fontSize: '12px',
                                        fontWeight: '700',
                                        padding: '5px 10px',
                                        borderRadius: '999px',
                                        background: 'hsl(6 91% 47% / .1)',
                                        color: 'hsl(6 91% 47%)',
                                        whiteSpace: 'nowrap',
                                      }}
                                    >
                                      <lu-icon name={v.rvCatIcon} size="13" />
                                      {T(v.rvCat)}
                                    </span>
                                    {'\n          '}
                                    {v.rvOk ? (
                                      <>
                                        <span
                                          style={{
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: '5px',
                                            fontSize: '12px',
                                            fontWeight: '600',
                                            padding: '5px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(150 55% 40% / .12)',
                                            color: 'hsl(150 55% 35%)',
                                            whiteSpace: 'nowrap',
                                          }}
                                        >
                                          <lu-icon name="circle-check" size="13" />
                                          {'Na nuvem'}
                                        </span>
                                      </>
                                    ) : null}
                                    {'\n          '}
                                    {v.rvPend ? (
                                      <>
                                        <span
                                          style={{
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: '5px',
                                            fontSize: '12px',
                                            fontWeight: '600',
                                            padding: '5px 10px',
                                            borderRadius: '999px',
                                            background: 'hsl(40 92% 46% / .15)',
                                            color: 'hsl(32 82% 38%)',
                                            whiteSpace: 'nowrap',
                                          }}
                                        >
                                          <lu-icon name="cloud-off" size="13" />
                                          {'Pendente'}
                                        </span>
                                      </>
                                    ) : null}
                                    {'\n        '}
                                  </div>
                                  {'\n        '}
                                  <div
                                    style={{
                                      display: 'flex',
                                      gap: '10px',
                                      alignItems: 'flex-start',
                                      padding: '12px',
                                      borderRadius: '12px',
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                    }}
                                  >
                                    {'\n          '}
                                    <span
                                      style={{
                                        width: '32px',
                                        height: '32px',
                                        borderRadius: '9px',
                                        background: 'hsl(6 91% 47% / .12)',
                                        color: 'hsl(6 91% 47%)',
                                        display: 'grid',
                                        placeItems: 'center',
                                        flex: 'none',
                                      }}
                                    >
                                      <lu-icon name={v.rvCtxIcon} size="16" />
                                    </span>
                                    {'\n          '}
                                    <div style={{ minWidth: '0', flex: '1' }}>
                                      <div style={{ fontSize: '12px', fontWeight: '700', color: 'hsl(6 91% 47%)' }}>{T(v.rvCtxLabel)}</div>
                                      {v.rvHasCtxTitle ? (
                                        <>
                                          <div style={{ fontSize: '13px', lineHeight: '1.5', color: 'hsl(0 0% 25%)', marginTop: '3px' }}>
                                            {T(v.rvCtxTitle)}
                                          </div>
                                        </>
                                      ) : null}
                                    </div>
                                    {'\n        '}
                                  </div>
                                  {'\n        '}
                                  <div
                                    style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '14px' }}
                                  >
                                    {'\n          '}
                                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', marginBottom: '8px' }}>
                                      <span
                                        style={{
                                          fontSize: '11px',
                                          fontWeight: '700',
                                          letterSpacing: '.08em',
                                          textTransform: 'uppercase',
                                          color: 'hsl(0 0% 62%)',
                                        }}
                                      >
                                        {'Mensagem'}
                                      </span>
                                      {v.rvHasText ? (
                                        <>
                                          <span style={{ fontSize: '11px', color: 'hsl(0 0% 62%)', whiteSpace: 'nowrap' }}>
                                            {T(v.rvLen)}
                                          </span>
                                        </>
                                      ) : null}
                                    </div>
                                    {'\n          '}
                                    {v.rvHasText ? (
                                      <>
                                        <div
                                          style={{
                                            fontSize: '14px',
                                            lineHeight: '1.6',
                                            color: 'hsl(0 0% 15%)',
                                            whiteSpace: 'pre-wrap',
                                            overflowWrap: 'anywhere',
                                          }}
                                        >
                                          {T(v.rvText)}
                                        </div>
                                      </>
                                    ) : null}
                                    {'\n          '}
                                    {v.rvNoText ? (
                                      <>
                                        <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)' }}>{'Sem texto, só anexos.'}</div>
                                      </>
                                    ) : null}
                                    {'\n        '}
                                  </div>
                                  {'\n        '}
                                  {v.rvHasAnexos ? (
                                    <>
                                      {'\n        '}
                                      <div
                                        style={{
                                          background: '#fff',
                                          border: '1px solid hsl(0 0% 90%)',
                                          borderRadius: '12px',
                                          padding: '14px',
                                          display: 'flex',
                                          flexDirection: 'column',
                                          gap: '10px',
                                        }}
                                      >
                                        {'\n          '}
                                        <span
                                          style={{
                                            fontSize: '11px',
                                            fontWeight: '700',
                                            letterSpacing: '.08em',
                                            textTransform: 'uppercase',
                                            color: 'hsl(0 0% 62%)',
                                          }}
                                        >
                                          {T(v.rvAnexosT)}
                                        </span>
                                        {'\n          '}
                                        {v.rvHasImgs ? (
                                          <>
                                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                                              {L(v.rvImgs).map((a, $i32) => (
                                                <Fragment key={$i32}>
                                                  <button
                                                    onClick={a?.onOpen}
                                                    aria-label="Ampliar imagem"
                                                    style={{
                                                      position: 'relative',
                                                      padding: '0',
                                                      border: '1px solid hsl(0 0% 90%)',
                                                      borderRadius: '10px',
                                                      overflow: 'hidden',
                                                      cursor: 'zoom-in',
                                                      background: 'hsl(0 0% 96%)',
                                                    }}
                                                  >
                                                    <span
                                                      style={css(
                                                        `display:block;aspect-ratio:4/3;background:url(${S(a?.src)}) center/cover no-repeat`,
                                                      )}
                                                    />
                                                    <span
                                                      style={{
                                                        position: 'absolute',
                                                        left: '0',
                                                        right: '0',
                                                        bottom: '0',
                                                        padding: '16px 8px 6px',
                                                        background: 'linear-gradient(transparent,rgba(0,0,0,.55))',
                                                        color: '#fff',
                                                        fontSize: '10.5px',
                                                        fontWeight: '600',
                                                        textAlign: 'left',
                                                        whiteSpace: 'nowrap',
                                                        overflow: 'hidden',
                                                        textOverflow: 'ellipsis',
                                                      }}
                                                    >
                                                      {T(a?.nome)}
                                                    </span>
                                                  </button>
                                                </Fragment>
                                              ))}
                                            </div>
                                          </>
                                        ) : null}
                                        {'\n          '}
                                        {v.rvHasFiles ? (
                                          <>
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                              {L(v.rvFiles).map((a, $i33) => (
                                                <Fragment key={$i33}>
                                                  <div
                                                    style={{
                                                      display: 'flex',
                                                      alignItems: 'center',
                                                      gap: '10px',
                                                      padding: '10px 12px',
                                                      borderRadius: '10px',
                                                      border: '1px solid hsl(0 0% 90%)',
                                                      background: 'hsl(0 0% 98.5%)',
                                                    }}
                                                  >
                                                    <span
                                                      style={{
                                                        width: '34px',
                                                        height: '34px',
                                                        borderRadius: '9px',
                                                        background: 'hsl(0 0% 93%)',
                                                        color: 'hsl(0 0% 40%)',
                                                        display: 'grid',
                                                        placeItems: 'center',
                                                        flex: 'none',
                                                      }}
                                                    >
                                                      <lu-icon name={a?.icon} size="17" />
                                                    </span>
                                                    <span style={{ flex: '1', minWidth: '0' }}>
                                                      <span
                                                        style={{
                                                          display: 'block',
                                                          fontSize: '13px',
                                                          fontWeight: '600',
                                                          whiteSpace: 'nowrap',
                                                          overflow: 'hidden',
                                                          textOverflow: 'ellipsis',
                                                        }}
                                                      >
                                                        {T(a?.nome)}
                                                      </span>
                                                      <span style={{ display: 'block', fontSize: '11px', color: 'hsl(0 0% 46%)' }}>
                                                        {T(a?.size)}
                                                      </span>
                                                    </span>
                                                  </div>
                                                </Fragment>
                                              ))}
                                            </div>
                                          </>
                                        ) : null}
                                        {'\n        '}
                                      </div>
                                      {'\n        '}
                                    </>
                                  ) : null}
                                  {'\n        '}
                                  <div
                                    style={{
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '12px',
                                      padding: '4px 14px',
                                    }}
                                  >
                                    {'\n          '}
                                    {L(v.rvMeta).map((m, $i34) => (
                                      <Fragment key={$i34}>
                                        <div
                                          style={{
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                            gap: '12px',
                                            padding: '10px 0',
                                            borderBottom: '1px solid hsl(0 0% 94%)',
                                            fontSize: '12.5px',
                                          }}
                                        >
                                          <span style={{ color: 'hsl(0 0% 46%)', whiteSpace: 'nowrap' }}>{T(m?.k)}</span>
                                          <span style={{ fontWeight: '600', textAlign: 'right', overflowWrap: 'anywhere' }}>{T(m?.v)}</span>
                                        </div>
                                      </Fragment>
                                    ))}
                                    {'\n        '}
                                  </div>
                                  {'\n        '}
                                  <button
                                    onClick={v.onRvAgain}
                                    style={{
                                      width: '100%',
                                      minHeight: '46px',
                                      borderRadius: '12px',
                                      border: '1px solid hsl(0 0% 90%)',
                                      background: '#fff',
                                      fontSize: '13.5px',
                                      fontWeight: '600',
                                      cursor: 'pointer',
                                      color: 'hsl(0 0% 13%)',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      gap: '8px',
                                    }}
                                  >
                                    <lu-icon name="message-square-plus" size="16" />
                                    {'Complementar este feedback'}
                                  </button>
                                  {'\n      '}
                                </div>
                                {'\n      '}
                                {v.rvLight ? (
                                  <>
                                    {'\n        '}
                                    <div
                                      onClick={v.onRvLightClose}
                                      style={{
                                        position: 'absolute',
                                        inset: '0',
                                        zIndex: '90',
                                        background: 'rgba(10,4,4,.92)',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        animation: 'fadeIn .2s both',
                                      }}
                                    >
                                      {'\n          '}
                                      <div
                                        style={{
                                          flex: 'none',
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: '10px',
                                          padding: '12px 14px',
                                          color: '#fff',
                                        }}
                                      >
                                        <span
                                          style={{
                                            flex: '1',
                                            minWidth: '0',
                                            fontSize: '13px',
                                            fontWeight: '600',
                                            whiteSpace: 'nowrap',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                          }}
                                        >
                                          {T(v.rvLightNome)}
                                        </span>
                                        <span style={{ fontSize: '12px', opacity: '.7', whiteSpace: 'nowrap' }}>{T(v.rvLightPos)}</span>
                                        <button
                                          onClick={v.onRvLightClose}
                                          aria-label="Fechar"
                                          style={{
                                            width: '44px',
                                            height: '44px',
                                            borderRadius: '12px',
                                            border: 'none',
                                            background: 'rgba(255,255,255,.14)',
                                            color: '#fff',
                                            display: 'grid',
                                            placeItems: 'center',
                                            cursor: 'pointer',
                                            flex: 'none',
                                          }}
                                        >
                                          <lu-icon name="x" size="20" />
                                        </button>
                                      </div>
                                      {'\n          '}
                                      <div
                                        style={{
                                          position: 'relative',
                                          flex: '1',
                                          minHeight: '0',
                                          display: 'flex',
                                          alignItems: 'center',
                                          justifyContent: 'center',
                                          padding: '8px 12px 24px',
                                        }}
                                      >
                                        {'\n            '}
                                        <div
                                          style={css(
                                            `width:100%;height:100%;background:url(${S(v.rvLightSrc)}) center/contain no-repeat;animation:popIn .25s cubic-bezier(.16,1,.3,1) both`,
                                          )}
                                        />
                                        {'\n            '}
                                        {v.rvLightMulti ? (
                                          <>
                                            <button
                                              onClick={v.onRvPrev}
                                              aria-label="Anterior"
                                              style={{
                                                position: 'absolute',
                                                left: '10px',
                                                top: '50%',
                                                marginTop: '-22px',
                                                width: '44px',
                                                height: '44px',
                                                borderRadius: '999px',
                                                border: 'none',
                                                background: 'rgba(255,255,255,.16)',
                                                color: '#fff',
                                                display: 'grid',
                                                placeItems: 'center',
                                                cursor: 'pointer',
                                              }}
                                            >
                                              <lu-icon name="chevron-left" size="22" />
                                            </button>
                                            <button
                                              onClick={v.onRvNext}
                                              aria-label="Próxima"
                                              style={{
                                                position: 'absolute',
                                                right: '10px',
                                                top: '50%',
                                                marginTop: '-22px',
                                                width: '44px',
                                                height: '44px',
                                                borderRadius: '999px',
                                                border: 'none',
                                                background: 'rgba(255,255,255,.16)',
                                                color: '#fff',
                                                display: 'grid',
                                                placeItems: 'center',
                                                cursor: 'pointer',
                                              }}
                                            >
                                              <lu-icon name="chevron-right" size="22" />
                                            </button>
                                          </>
                                        ) : null}
                                        {'\n          '}
                                      </div>
                                      {'\n        '}
                                    </div>
                                    {'\n      '}
                                  </>
                                ) : null}
                                {'\n      '}
                              </>
                            ) : null}
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subCert ? (
                          <>
                            {'\n      '}
                            <div style={{ padding: '18px 16px 24px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                              {'\n        '}
                              <button
                                onClick={v.onCvFull}
                                aria-label="Ver em tela cheia"
                                style={{
                                  position: 'relative',
                                  display: 'block',
                                  width: '100%',
                                  padding: '0',
                                  border: 'none',
                                  background: 'none',
                                  cursor: 'zoom-in',
                                  textAlign: 'left',
                                }}
                              >
                                {'\n          '}
                                <div style={{ containerType: 'inline-size', width: '100%' }}>
                                  {'\n  '}
                                  <div
                                    style={{
                                      position: 'relative',
                                      width: '100%',
                                      aspectRatio: '297/210',
                                      fontFamily: "'Poppins',sans-serif",
                                      color: 'hsl(0 0% 13%)',
                                      display: 'grid',
                                      gridTemplateColumns: '31% 1fr',
                                      background: '#fff',
                                      overflow: 'hidden',
                                      borderRadius: '1.4cqw',
                                      boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                      animation: 'reveal3d .6s cubic-bezier(.16,1,.3,1) both',
                                    }}
                                  >
                                    {'\n    '}
                                    <div
                                      style={{
                                        position: 'relative',
                                        background: '#df1c0d',
                                        overflow: 'hidden',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        justifyContent: 'space-between',
                                        padding: '7cqw 4.5cqw 5cqw',
                                      }}
                                    >
                                      {'\n      '}
                                      <div
                                        style={{
                                          position: 'absolute',
                                          inset: '-20%',
                                          transform: 'rotate(-8deg)',
                                          background: 'url("assets/takeat-mark.png") 0 0/7cqw 7cqw repeat',
                                          filter: 'brightness(0) invert(1)',
                                          opacity: '.07',
                                        }}
                                      />
                                      {'\n      '}
                                      <div
                                        style={{
                                          position: 'absolute',
                                          inset: '0',
                                          background: 'linear-gradient(135deg,rgba(255,255,255,.10),rgba(0,0,0,.34) 135%)',
                                        }}
                                      />
                                      {'\n      '}
                                      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '1.4cqw' }}>
                                        {'\n        '}
                                        <span
                                          style={{
                                            width: '4.6cqw',
                                            height: '4.6cqw',
                                            background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                            filter: 'brightness(0) invert(1)',
                                            flex: 'none',
                                          }}
                                        />
                                        {'\n        '}
                                        <span style={{ display: 'flex', flexDirection: 'column', lineHeight: '1', color: '#fff' }}>
                                          <span style={{ fontSize: '2.5cqw', fontWeight: '800', letterSpacing: '-.02em' }}>
                                            {'TakeatHub'}
                                          </span>
                                          <span
                                            style={{
                                              fontFamily: "'Dancing Script',cursive",
                                              fontSize: '2.9cqw',
                                              fontWeight: '700',
                                              marginTop: '.2cqw',
                                            }}
                                          >
                                            {'Academy'}
                                          </span>
                                        </span>
                                        {'\n      '}
                                      </div>
                                      {'\n      '}
                                      <div
                                        style={{
                                          position: 'relative',
                                          width: '19cqw',
                                          height: '19cqw',
                                          margin: '0 auto',
                                          background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                          filter: 'brightness(0) invert(1) drop-shadow(0 2cqw 3cqw rgba(0,0,0,.3))',
                                          opacity: '.95',
                                        }}
                                      />
                                      {'\n      '}
                                      <div
                                        style={{
                                          position: 'relative',
                                          color: 'rgba(255,255,255,.88)',
                                          fontSize: '1.15cqw',
                                          lineHeight: '1.55',
                                        }}
                                      >
                                        {'\n        '}
                                        <div
                                          style={{
                                            fontSize: '.95cqw',
                                            fontWeight: '700',
                                            letterSpacing: '.15em',
                                            textTransform: 'uppercase',
                                            color: 'rgba(255,255,255,.72)',
                                            marginBottom: '.8cqw',
                                          }}
                                        >
                                          {'Plataforma interna Takeat'}
                                        </div>
                                        {
                                          '\n        Trilhas de aprendizado sobre a plataforma, os processos internos e as regras de atendimento de cada equipe.\n      '
                                        }
                                      </div>
                                      {'\n    '}
                                    </div>
                                    {'\n    '}
                                    <div
                                      style={{
                                        position: 'relative',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        padding: '6.5cqw 6cqw 5cqw 6cqw',
                                      }}
                                    >
                                      {'\n      '}
                                      <div
                                        style={{
                                          position: 'absolute',
                                          right: '-3cqw',
                                          bottom: '-3cqw',
                                          width: '26cqw',
                                          height: '26cqw',
                                          background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                          opacity: '.045',
                                          transform: 'rotate(8deg)',
                                        }}
                                      />
                                      {'\n      '}
                                      <div
                                        style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '3cqw' }}
                                      >
                                        {'\n        '}
                                        <div>
                                          {'\n          '}
                                          <div
                                            style={{
                                              fontSize: '1.1cqw',
                                              fontWeight: '700',
                                              letterSpacing: '.16em',
                                              textTransform: 'uppercase',
                                              color: '#df1c0d',
                                              whiteSpace: 'nowrap',
                                            }}
                                          >
                                            {'Certificado de conclusão'}
                                          </div>
                                          {'\n          '}
                                          <div
                                            style={{
                                              width: '5cqw',
                                              height: '.35cqw',
                                              borderRadius: '999px',
                                              background: '#df1c0d',
                                              marginTop: '1.2cqw',
                                            }}
                                          />
                                          {'\n        '}
                                        </div>
                                        {'\n        '}
                                        <div
                                          style={{
                                            position: 'relative',
                                            width: '10cqw',
                                            height: '10cqw',
                                            flex: 'none',
                                            borderRadius: '999px',
                                            background: 'linear-gradient(145deg,#FFE9A0,#F5B83B 50%,#C7801E)',
                                            boxShadow: '0 .8cqw 1.6cqw rgba(199,128,30,.35),inset 0 .2cqw 0 rgba(255,255,255,.6)',
                                            display: 'grid',
                                            placeItems: 'center',
                                          }}
                                        >
                                          {'\n          '}
                                          <div
                                            style={{
                                              position: 'absolute',
                                              inset: '.7cqw',
                                              borderRadius: '999px',
                                              border: '.18cqw dashed rgba(255,255,255,.75)',
                                            }}
                                          />
                                          {'\n          '}
                                          <div
                                            style={{
                                              position: 'absolute',
                                              inset: '1.4cqw',
                                              borderRadius: '999px',
                                              background: 'radial-gradient(circle at 35% 30%,#FFF6D2,#FFD66B 60%,#E3A325)',
                                            }}
                                          />
                                          {'\n          '}
                                          <div
                                            style={{
                                              position: 'relative',
                                              width: '6.6cqw',
                                              height: '6.6cqw',
                                              background: 'url("assets/takeat-mark.png") center/62% no-repeat',
                                              filter: 'drop-shadow(0 .15cqw .2cqw rgba(0,0,0,.25))',
                                            }}
                                          />
                                          {'\n        '}
                                        </div>
                                        {'\n      '}
                                      </div>
                                      {'\n      '}
                                      <div style={{ marginTop: 'auto', marginBottom: 'auto', padding: '2cqw 0' }}>
                                        {'\n        '}
                                        <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>{'Certificamos que'}</div>
                                        {'\n        '}
                                        <div
                                          style={{
                                            fontSize: '4.6cqw',
                                            fontWeight: '800',
                                            letterSpacing: '-.03em',
                                            lineHeight: '1.05',
                                            margin: '.8cqw 0 1.6cqw',
                                            textWrap: 'balance',
                                          }}
                                        >
                                          {T(v.cvNome)}
                                        </div>
                                        {'\n        '}
                                        <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>
                                          {'concluiu o Desafio Mestre da trilha'}
                                        </div>
                                        {'\n        '}
                                        <div
                                          style={{
                                            fontSize: '2.5cqw',
                                            fontWeight: '700',
                                            letterSpacing: '-.01em',
                                            lineHeight: '1.2',
                                            marginTop: '.4cqw',
                                            color: 'hsl(0 0% 13%)',
                                            textWrap: 'balance',
                                          }}
                                        >
                                          {T(v.cvTrilha)}
                                        </div>
                                        {'\n        '}
                                        <p
                                          style={{
                                            margin: '1.8cqw 0 0',
                                            fontSize: '1.2cqw',
                                            lineHeight: '1.6',
                                            color: 'hsl(0 0% 40%)',
                                            maxWidth: '46ch',
                                          }}
                                        >
                                          {T(v.cvDesc)}
                                        </p>
                                        {'\n      '}
                                      </div>
                                      {'\n      '}
                                      <div
                                        style={{
                                          display: 'grid',
                                          gridTemplateColumns: '1fr 1fr 1.2fr',
                                          gap: '3cqw',
                                          alignItems: 'end',
                                          paddingTop: '2cqw',
                                          borderTop: '1px solid hsl(0 0% 90%)',
                                        }}
                                      >
                                        {'\n        '}
                                        <div>
                                          <div
                                            style={{
                                              fontSize: '.9cqw',
                                              fontWeight: '700',
                                              letterSpacing: '.1em',
                                              textTransform: 'uppercase',
                                              color: 'hsl(0 0% 62%)',
                                            }}
                                          >
                                            {'Emitido em'}
                                          </div>
                                          <div style={{ fontSize: '1.35cqw', fontWeight: '600', marginTop: '.3cqw' }}>{T(v.cvData)}</div>
                                        </div>
                                        {'\n        '}
                                        <div>
                                          <div
                                            style={{
                                              fontSize: '.9cqw',
                                              fontWeight: '700',
                                              letterSpacing: '.1em',
                                              textTransform: 'uppercase',
                                              color: 'hsl(0 0% 62%)',
                                            }}
                                          >
                                            {'Código'}
                                          </div>
                                          <div
                                            style={{ fontSize: '1.35cqw', fontWeight: '600', marginTop: '.3cqw', letterSpacing: '.04em' }}
                                          >
                                            {T(v.cvCodigo)}
                                          </div>
                                        </div>
                                        {'\n        '}
                                        <div>
                                          <div
                                            style={{
                                              fontFamily: "'Dancing Script',cursive",
                                              fontSize: '2.6cqw',
                                              fontWeight: '700',
                                              color: '#8f1109',
                                              lineHeight: '1',
                                            }}
                                          >
                                            {'Produto Takeat'}
                                          </div>
                                          <div style={{ height: '1px', background: 'hsl(0 0% 70%)', margin: '.6cqw 0 .5cqw' }} />
                                          <div style={{ fontSize: '.95cqw', color: 'hsl(0 0% 46%)' }}>{'Time de Produto · TakeatHub'}</div>
                                        </div>
                                        {'\n      '}
                                      </div>
                                      {'\n    '}
                                    </div>
                                    {'\n  '}
                                  </div>
                                </div>
                                {'\n          '}
                                <span
                                  style={{
                                    position: 'absolute',
                                    right: '8px',
                                    bottom: '8px',
                                    width: '34px',
                                    height: '34px',
                                    borderRadius: '9px',
                                    background: 'rgba(255,255,255,.92)',
                                    boxShadow: '0 2px 8px rgba(0,0,0,.15)',
                                    color: 'hsl(0 0% 13%)',
                                    display: 'grid',
                                    placeItems: 'center',
                                  }}
                                >
                                  <lu-icon name="maximize-2" size="16" />
                                </span>
                                {'\n        '}
                              </button>
                              {'\n        '}
                              <div
                                style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '12px', padding: '4px 14px' }}
                              >
                                {'\n          '}
                                <div
                                  style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    gap: '12px',
                                    padding: '10px 0',
                                    borderBottom: '1px solid hsl(0 0% 93%)',
                                    fontSize: '13px',
                                  }}
                                >
                                  <span style={{ color: 'hsl(0 0% 46%)' }}>{'Trilha'}</span>
                                  <span style={{ fontWeight: '600', textAlign: 'right' }}>{T(v.cvTrilha)}</span>
                                </div>
                                {'\n          '}
                                <div
                                  style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    gap: '12px',
                                    padding: '10px 0',
                                    borderBottom: '1px solid hsl(0 0% 93%)',
                                    fontSize: '13px',
                                  }}
                                >
                                  <span style={{ color: 'hsl(0 0% 46%)' }}>{'Emitido em'}</span>
                                  <span style={{ fontWeight: '600' }}>{T(v.cvData)}</span>
                                </div>
                                {'\n          '}
                                <div
                                  style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    gap: '12px',
                                    padding: '10px 0',
                                    fontSize: '13px',
                                  }}
                                >
                                  <span style={{ color: 'hsl(0 0% 46%)' }}>{'Código de validação'}</span>
                                  <span style={{ fontWeight: '600', letterSpacing: '.04em' }}>{T(v.cvCodigo)}</span>
                                </div>
                                {'\n        '}
                              </div>
                              {'\n        '}
                              <button
                                onClick={v.onCvPrint}
                                style={{
                                  width: '100%',
                                  height: '52px',
                                  border: 'none',
                                  borderRadius: '12px',
                                  background: 'hsl(6 91% 47%)',
                                  color: '#fff',
                                  fontSize: '15px',
                                  fontWeight: '700',
                                  cursor: 'pointer',
                                  boxShadow: '0 4px 0 hsl(6 100% 34%)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                  transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                                }}
                                className="scp0"
                              >
                                <lu-icon name="printer" size="18" />
                                {'Baixar PDF / Imprimir'}
                              </button>
                              {'\n        '}
                              <button
                                onClick={v.onCvShare}
                                style={{
                                  width: '100%',
                                  height: '48px',
                                  borderRadius: '12px',
                                  border: '1px solid hsl(0 0% 90%)',
                                  background: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '600',
                                  cursor: 'pointer',
                                  color: 'hsl(0 0% 13%)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px',
                                }}
                              >
                                <lu-icon name="share-2" size="16" />
                                {'Compartilhar imagem'}
                              </button>
                              {'\n      '}
                            </div>
                            {'\n      '}
                            {v.cvFull ? (
                              <>
                                {'\n        '}
                                <div
                                  onClick={v.onCvFullClose}
                                  style={{
                                    position: 'absolute',
                                    inset: '0',
                                    zIndex: '90',
                                    background: 'rgba(10,4,4,.86)',
                                    animation: 'fadeIn .2s both',
                                    cursor: 'zoom-out',
                                  }}
                                >
                                  {'\n          '}
                                  <div
                                    style={{
                                      position: 'absolute',
                                      top: '50%',
                                      left: '50%',
                                      width: 'min(calc(min(100dvh, 844px) - 72px), calc((min(100vw, 390px) - 28px) * 1.414))',
                                      transform: 'translate(-50%,-50%) rotate(90deg)',
                                    }}
                                  >
                                    <div style={{ containerType: 'inline-size', width: '100%' }}>
                                      {'\n  '}
                                      <div
                                        style={{
                                          position: 'relative',
                                          width: '100%',
                                          aspectRatio: '297/210',
                                          fontFamily: "'Poppins',sans-serif",
                                          color: 'hsl(0 0% 13%)',
                                          display: 'grid',
                                          gridTemplateColumns: '31% 1fr',
                                          background: '#fff',
                                          overflow: 'hidden',
                                          borderRadius: '1.4cqw',
                                          boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                          animation: 'reveal3d .6s cubic-bezier(.16,1,.3,1) both',
                                        }}
                                      >
                                        {'\n    '}
                                        <div
                                          style={{
                                            position: 'relative',
                                            background: '#df1c0d',
                                            overflow: 'hidden',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            justifyContent: 'space-between',
                                            padding: '7cqw 4.5cqw 5cqw',
                                          }}
                                        >
                                          {'\n      '}
                                          <div
                                            style={{
                                              position: 'absolute',
                                              inset: '-20%',
                                              transform: 'rotate(-8deg)',
                                              background: 'url("assets/takeat-mark.png") 0 0/7cqw 7cqw repeat',
                                              filter: 'brightness(0) invert(1)',
                                              opacity: '.07',
                                            }}
                                          />
                                          {'\n      '}
                                          <div
                                            style={{
                                              position: 'absolute',
                                              inset: '0',
                                              background: 'linear-gradient(135deg,rgba(255,255,255,.10),rgba(0,0,0,.34) 135%)',
                                            }}
                                          />
                                          {'\n      '}
                                          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '1.4cqw' }}>
                                            {'\n        '}
                                            <span
                                              style={{
                                                width: '4.6cqw',
                                                height: '4.6cqw',
                                                background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                                filter: 'brightness(0) invert(1)',
                                                flex: 'none',
                                              }}
                                            />
                                            {'\n        '}
                                            <span style={{ display: 'flex', flexDirection: 'column', lineHeight: '1', color: '#fff' }}>
                                              <span style={{ fontSize: '2.5cqw', fontWeight: '800', letterSpacing: '-.02em' }}>
                                                {'TakeatHub'}
                                              </span>
                                              <span
                                                style={{
                                                  fontFamily: "'Dancing Script',cursive",
                                                  fontSize: '2.9cqw',
                                                  fontWeight: '700',
                                                  marginTop: '.2cqw',
                                                }}
                                              >
                                                {'Academy'}
                                              </span>
                                            </span>
                                            {'\n      '}
                                          </div>
                                          {'\n      '}
                                          <div
                                            style={{
                                              position: 'relative',
                                              width: '19cqw',
                                              height: '19cqw',
                                              margin: '0 auto',
                                              background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                              filter: 'brightness(0) invert(1) drop-shadow(0 2cqw 3cqw rgba(0,0,0,.3))',
                                              opacity: '.95',
                                            }}
                                          />
                                          {'\n      '}
                                          <div
                                            style={{
                                              position: 'relative',
                                              color: 'rgba(255,255,255,.88)',
                                              fontSize: '1.15cqw',
                                              lineHeight: '1.55',
                                            }}
                                          >
                                            {'\n        '}
                                            <div
                                              style={{
                                                fontSize: '.95cqw',
                                                fontWeight: '700',
                                                letterSpacing: '.15em',
                                                textTransform: 'uppercase',
                                                color: 'rgba(255,255,255,.72)',
                                                marginBottom: '.8cqw',
                                              }}
                                            >
                                              {'Plataforma interna Takeat'}
                                            </div>
                                            {
                                              '\n        Trilhas de aprendizado sobre a plataforma, os processos internos e as regras de atendimento de cada equipe.\n      '
                                            }
                                          </div>
                                          {'\n    '}
                                        </div>
                                        {'\n    '}
                                        <div
                                          style={{
                                            position: 'relative',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            padding: '6.5cqw 6cqw 5cqw 6cqw',
                                          }}
                                        >
                                          {'\n      '}
                                          <div
                                            style={{
                                              position: 'absolute',
                                              right: '-3cqw',
                                              bottom: '-3cqw',
                                              width: '26cqw',
                                              height: '26cqw',
                                              background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                                              opacity: '.045',
                                              transform: 'rotate(8deg)',
                                            }}
                                          />
                                          {'\n      '}
                                          <div
                                            style={{
                                              display: 'flex',
                                              alignItems: 'flex-start',
                                              justifyContent: 'space-between',
                                              gap: '3cqw',
                                            }}
                                          >
                                            {'\n        '}
                                            <div>
                                              {'\n          '}
                                              <div
                                                style={{
                                                  fontSize: '1.1cqw',
                                                  fontWeight: '700',
                                                  letterSpacing: '.16em',
                                                  textTransform: 'uppercase',
                                                  color: '#df1c0d',
                                                  whiteSpace: 'nowrap',
                                                }}
                                              >
                                                {'Certificado de conclusão'}
                                              </div>
                                              {'\n          '}
                                              <div
                                                style={{
                                                  width: '5cqw',
                                                  height: '.35cqw',
                                                  borderRadius: '999px',
                                                  background: '#df1c0d',
                                                  marginTop: '1.2cqw',
                                                }}
                                              />
                                              {'\n        '}
                                            </div>
                                            {'\n        '}
                                            <div
                                              style={{
                                                position: 'relative',
                                                width: '10cqw',
                                                height: '10cqw',
                                                flex: 'none',
                                                borderRadius: '999px',
                                                background: 'linear-gradient(145deg,#FFE9A0,#F5B83B 50%,#C7801E)',
                                                boxShadow: '0 .8cqw 1.6cqw rgba(199,128,30,.35),inset 0 .2cqw 0 rgba(255,255,255,.6)',
                                                display: 'grid',
                                                placeItems: 'center',
                                              }}
                                            >
                                              {'\n          '}
                                              <div
                                                style={{
                                                  position: 'absolute',
                                                  inset: '.7cqw',
                                                  borderRadius: '999px',
                                                  border: '.18cqw dashed rgba(255,255,255,.75)',
                                                }}
                                              />
                                              {'\n          '}
                                              <div
                                                style={{
                                                  position: 'absolute',
                                                  inset: '1.4cqw',
                                                  borderRadius: '999px',
                                                  background: 'radial-gradient(circle at 35% 30%,#FFF6D2,#FFD66B 60%,#E3A325)',
                                                }}
                                              />
                                              {'\n          '}
                                              <div
                                                style={{
                                                  position: 'relative',
                                                  width: '6.6cqw',
                                                  height: '6.6cqw',
                                                  background: 'url("assets/takeat-mark.png") center/62% no-repeat',
                                                  filter: 'drop-shadow(0 .15cqw .2cqw rgba(0,0,0,.25))',
                                                }}
                                              />
                                              {'\n        '}
                                            </div>
                                            {'\n      '}
                                          </div>
                                          {'\n      '}
                                          <div style={{ marginTop: 'auto', marginBottom: 'auto', padding: '2cqw 0' }}>
                                            {'\n        '}
                                            <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>{'Certificamos que'}</div>
                                            {'\n        '}
                                            <div
                                              style={{
                                                fontSize: '4.6cqw',
                                                fontWeight: '800',
                                                letterSpacing: '-.03em',
                                                lineHeight: '1.05',
                                                margin: '.8cqw 0 1.6cqw',
                                                textWrap: 'balance',
                                              }}
                                            >
                                              {T(v.cvNome)}
                                            </div>
                                            {'\n        '}
                                            <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>
                                              {'concluiu o Desafio Mestre da trilha'}
                                            </div>
                                            {'\n        '}
                                            <div
                                              style={{
                                                fontSize: '2.5cqw',
                                                fontWeight: '700',
                                                letterSpacing: '-.01em',
                                                lineHeight: '1.2',
                                                marginTop: '.4cqw',
                                                color: 'hsl(0 0% 13%)',
                                                textWrap: 'balance',
                                              }}
                                            >
                                              {T(v.cvTrilha)}
                                            </div>
                                            {'\n        '}
                                            <p
                                              style={{
                                                margin: '1.8cqw 0 0',
                                                fontSize: '1.2cqw',
                                                lineHeight: '1.6',
                                                color: 'hsl(0 0% 40%)',
                                                maxWidth: '46ch',
                                              }}
                                            >
                                              {T(v.cvDesc)}
                                            </p>
                                            {'\n      '}
                                          </div>
                                          {'\n      '}
                                          <div
                                            style={{
                                              display: 'grid',
                                              gridTemplateColumns: '1fr 1fr 1.2fr',
                                              gap: '3cqw',
                                              alignItems: 'end',
                                              paddingTop: '2cqw',
                                              borderTop: '1px solid hsl(0 0% 90%)',
                                            }}
                                          >
                                            {'\n        '}
                                            <div>
                                              <div
                                                style={{
                                                  fontSize: '.9cqw',
                                                  fontWeight: '700',
                                                  letterSpacing: '.1em',
                                                  textTransform: 'uppercase',
                                                  color: 'hsl(0 0% 62%)',
                                                }}
                                              >
                                                {'Emitido em'}
                                              </div>
                                              <div style={{ fontSize: '1.35cqw', fontWeight: '600', marginTop: '.3cqw' }}>
                                                {T(v.cvData)}
                                              </div>
                                            </div>
                                            {'\n        '}
                                            <div>
                                              <div
                                                style={{
                                                  fontSize: '.9cqw',
                                                  fontWeight: '700',
                                                  letterSpacing: '.1em',
                                                  textTransform: 'uppercase',
                                                  color: 'hsl(0 0% 62%)',
                                                }}
                                              >
                                                {'Código'}
                                              </div>
                                              <div
                                                style={{
                                                  fontSize: '1.35cqw',
                                                  fontWeight: '600',
                                                  marginTop: '.3cqw',
                                                  letterSpacing: '.04em',
                                                }}
                                              >
                                                {T(v.cvCodigo)}
                                              </div>
                                            </div>
                                            {'\n        '}
                                            <div>
                                              <div
                                                style={{
                                                  fontFamily: "'Dancing Script',cursive",
                                                  fontSize: '2.6cqw',
                                                  fontWeight: '700',
                                                  color: '#8f1109',
                                                  lineHeight: '1',
                                                }}
                                              >
                                                {'Produto Takeat'}
                                              </div>
                                              <div style={{ height: '1px', background: 'hsl(0 0% 70%)', margin: '.6cqw 0 .5cqw' }} />
                                              <div style={{ fontSize: '.95cqw', color: 'hsl(0 0% 46%)' }}>
                                                {'Time de Produto · TakeatHub'}
                                              </div>
                                            </div>
                                            {'\n      '}
                                          </div>
                                          {'\n    '}
                                        </div>
                                        {'\n  '}
                                      </div>
                                    </div>
                                  </div>
                                  {'\n          '}
                                  <button
                                    onClick={v.onCvFullClose}
                                    aria-label="Fechar"
                                    style={{
                                      position: 'absolute',
                                      top: '12px',
                                      right: '12px',
                                      width: '44px',
                                      height: '44px',
                                      borderRadius: '12px',
                                      border: 'none',
                                      background: 'rgba(255,255,255,.14)',
                                      color: '#fff',
                                      display: 'grid',
                                      placeItems: 'center',
                                      cursor: 'pointer',
                                    }}
                                  >
                                    <lu-icon name="x" size="20" />
                                  </button>
                                  {'\n        '}
                                </div>
                                {'\n      '}
                              </>
                            ) : null}
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subResgate ? (
                          <>
                            {'\n      '}
                            <div style={{ padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                              {'\n        '}
                              {v.rsForm ? (
                                <>
                                  {'\n          '}
                                  <div
                                    style={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      alignItems: 'center',
                                      textAlign: 'center',
                                      gap: '8px',
                                      padding: '8px 0 4px',
                                    }}
                                  >
                                    <span
                                      style={{
                                        width: '64px',
                                        height: '64px',
                                        borderRadius: '18px',
                                        background: 'hsl(38 92% 50% / .12)',
                                        color: '#d97706',
                                        display: 'grid',
                                        placeItems: 'center',
                                      }}
                                    >
                                      <lu-icon name="gift" size="30" />
                                    </span>
                                    <div style={{ fontSize: '17px', fontWeight: '700', whiteSpace: 'nowrap' }}>{'Resgatar código'}</div>
                                    <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', maxWidth: '30ch' }}>
                                      {'Digite o código. Você vê o prêmio antes de confirmar.'}
                                    </div>
                                  </div>
                                  {'\n          '}
                                  <input
                                    value={D(v.rsCode, '')}
                                    onChange={v.onRsCode}
                                    placeholder="Digite o código"
                                    style={{
                                      width: '100%',
                                      height: '52px',
                                      borderRadius: '10px',
                                      border: '1.5px solid hsl(0 0% 90%)',
                                      padding: '0 14px',
                                      fontSize: '16px',
                                      fontWeight: '600',
                                      letterSpacing: '.06em',
                                      textTransform: 'uppercase',
                                      textAlign: 'center',
                                      background: '#fff',
                                    }}
                                  />
                                  {'\n          '}
                                  {v.rsHasErr ? (
                                    <>
                                      <div style={{ fontSize: '13px', fontWeight: '500', color: 'hsl(6 91% 47%)', textAlign: 'center' }}>
                                        {T(v.rsErr)}
                                      </div>
                                    </>
                                  ) : null}
                                  {'\n          '}
                                  <button
                                    onClick={v.onRsCheck}
                                    disabled={v.rsDisabled}
                                    style={{
                                      width: '100%',
                                      height: '52px',
                                      border: 'none',
                                      borderRadius: '12px',
                                      background: 'hsl(6 91% 47%)',
                                      color: '#fff',
                                      fontSize: '15px',
                                      fontWeight: '700',
                                      cursor: 'pointer',
                                      boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                    }}
                                  >
                                    {'Verificar código'}
                                  </button>
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n        '}
                              {v.rsPreview ? (
                                <>
                                  {'\n          '}
                                  <div
                                    style={{
                                      fontSize: '11px',
                                      fontWeight: '700',
                                      letterSpacing: '.09em',
                                      textTransform: 'uppercase',
                                      color: 'hsl(6 91% 47%)',
                                      textAlign: 'center',
                                      whiteSpace: 'nowrap',
                                    }}
                                  >
                                    {'Seu prêmio'}
                                  </div>
                                  {'\n          '}
                                  <div
                                    style={css(
                                      `display:flex;flex-direction:column;align-items:center;gap:6px;padding:22px 16px;border-radius:12px;border:1px solid hsl(0 0% 90%);border-top:${S(v.rsTop)};background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);animation:reveal3d .6s cubic-bezier(.16,1,.3,1) both`,
                                    )}
                                  >
                                    {'\n            '}
                                    <span
                                      style={css(
                                        `border-radius:999px;padding:2px 10px;font-size:11px;font-weight:600;background:${S(v.rsRbg)};color:${S(v.rsRfg)}`,
                                      )}
                                    >
                                      {T(v.rsRar)}
                                    </span>
                                    {'\n            '}
                                    <span
                                      style={{
                                        position: 'relative',
                                        width: '132px',
                                        height: '132px',
                                        display: 'inline-flex',
                                        margin: '8px 0',
                                      }}
                                    >
                                      <span
                                        style={{
                                          position: 'absolute',
                                          top: '18px',
                                          left: '18px',
                                          width: '96px',
                                          height: '96px',
                                          borderRadius: '999px',
                                          background: 'hsl(6 91% 47%)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                          fontSize: '32px',
                                          fontWeight: '700',
                                        }}
                                      >
                                        {T(v.rsAv?.ini)}
                                      </span>
                                      <span
                                        style={css(
                                          `position:absolute;inset:0;display:block;background:url(${S(v.rsAv?.src)}) center/contain no-repeat`,
                                        )}
                                      />
                                    </span>
                                    {'\n            '}
                                    <div style={{ fontSize: '18px', fontWeight: '700', whiteSpace: 'nowrap' }}>{T(v.rsNome)}</div>
                                    {'\n            '}
                                    <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                      {T(v.rsCol)}
                                      {' · grátis com código'}
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n          '}
                                  <button
                                    onClick={v.onRsConfirm}
                                    style={{
                                      width: '100%',
                                      height: '52px',
                                      border: 'none',
                                      borderRadius: '12px',
                                      background: 'hsl(6 91% 47%)',
                                      color: '#fff',
                                      fontSize: '15px',
                                      fontWeight: '700',
                                      cursor: 'pointer',
                                      boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                    }}
                                  >
                                    {'Confirmar resgate'}
                                  </button>
                                  {'\n          '}
                                  <button
                                    onClick={v.onRsOther}
                                    style={{
                                      width: '100%',
                                      height: '46px',
                                      borderRadius: '12px',
                                      border: '1px solid hsl(0 0% 90%)',
                                      background: '#fff',
                                      fontSize: '14px',
                                      fontWeight: '500',
                                      cursor: 'pointer',
                                      color: 'hsl(0 0% 13%)',
                                    }}
                                  >
                                    {'Usar outro código'}
                                  </button>
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n      '}
                            </div>
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subGloss ? (
                          <>
                            {'\n      '}
                            <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                              {'\n        '}
                              <div style={{ position: 'relative' }}>
                                <span
                                  style={{
                                    position: 'absolute',
                                    left: '12px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    color: 'hsl(0 0% 46%)',
                                    display: 'grid',
                                  }}
                                >
                                  <lu-icon name="search" size="16" />
                                </span>
                                <input
                                  value={D(v.gloss, '')}
                                  onChange={v.onGloss}
                                  placeholder="Buscar termo (ex.: CMV, TEF, sangria)"
                                  style={{
                                    width: '100%',
                                    height: '46px',
                                    borderRadius: '9px',
                                    border: '1px solid hsl(0 0% 90%)',
                                    padding: '0 12px 0 36px',
                                    fontSize: '14px',
                                    background: '#fff',
                                  }}
                                />
                              </div>
                              {'\n        '}
                              {L(v.glossItems).map((g, $i35) => (
                                <Fragment key={$i35}>
                                  {'\n          '}
                                  <div
                                    style={{
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '14px',
                                      padding: '14px 16px',
                                      boxShadow: '0 1px 4px rgba(0,0,0,.06)',
                                    }}
                                  >
                                    {'\n            '}
                                    <div style={{ fontSize: '15px', fontWeight: '700' }}>{T(g?.t)}</div>
                                    {'\n            '}
                                    <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', lineHeight: '1.5', marginTop: '4px' }}>
                                      {T(g?.d)}
                                    </div>
                                    {'\n            '}
                                    <button
                                      onClick={g?.onPractice}
                                      style={{
                                        marginTop: '10px',
                                        minHeight: '40px',
                                        padding: '0 12px',
                                        borderRadius: '9px',
                                        border: '1px solid hsl(0 0% 90%)',
                                        background: '#fff',
                                        fontSize: '12.5px',
                                        fontWeight: '600',
                                        cursor: 'pointer',
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        gap: '6px',
                                        color: 'hsl(0 0% 13%)',
                                      }}
                                    >
                                      <lu-icon name="dumbbell" size="14" />
                                      {'Praticar este termo'}
                                    </button>
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </Fragment>
                              ))}
                              {'\n      '}
                            </div>
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n\n    '}
                        {v.subLeader ? (
                          <>
                            {'\n      '}
                            <div style={{ padding: '14px 16px 28px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                              {'\n        '}
                              <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '2px' }}>
                                {'\n          '}
                                {L(v.leaderTabs).map((t, $i36) => (
                                  <Fragment key={$i36}>
                                    <button
                                      onClick={t?.onClick}
                                      style={css(
                                        `flex:none;min-height:40px;padding:0 15px;border-radius:999px;border:1px solid ${S(t?.bd)};background:${S(t?.bg)};color:${S(t?.fg)};box-shadow:${S(t?.sh)};font-size:13px;font-weight:600;cursor:pointer`,
                                      )}
                                    >
                                      {T(t?.t)}
                                    </button>
                                  </Fragment>
                                ))}
                                {'\n        '}
                              </div>
                              {'\n\n        '}
                              {v.ltUnits ? (
                                <>
                                  {'\n          '}
                                  <p style={{ margin: '0', fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                                    {'Unidades-base da rubrica da Monitoria. Ligue ou desligue para o time '}
                                    <b style={{ color: 'hsl(0 0% 13%)' }}>{T(v.leadTeam)}</b>
                                    {'.'}
                                  </p>
                                  {'\n          '}
                                  {v.noBase ? (
                                    <>
                                      <div
                                        style={{
                                          padding: '12px 14px',
                                          borderRadius: '12px',
                                          background: 'hsl(40 92% 46% / .15)',
                                          border: '1px solid hsl(40 92% 46% / .3)',
                                          fontSize: '12.5px',
                                          color: 'hsl(32 82% 32%)',
                                        }}
                                      >
                                        {'Esta equipe começa vazia. Ligue as unidades que fazem sentido ou crie regras próprias.'}
                                      </div>
                                    </>
                                  ) : null}
                                  {'\n          '}
                                  <div
                                    style={{
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '16px',
                                      overflow: 'hidden',
                                    }}
                                  >
                                    {'\n            '}
                                    {L(v.baseUnits).map((u, $i37) => (
                                      <Fragment key={$i37}>
                                        {'\n              '}
                                        <div
                                          style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '12px',
                                            padding: '12px 14px',
                                            borderBottom: '1px solid hsl(0 0% 93%)',
                                          }}
                                        >
                                          {'\n                '}
                                          <div style={{ flex: '1', minWidth: '0' }}>
                                            <div
                                              style={{
                                                fontSize: '13.5px',
                                                fontWeight: '600',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px',
                                              }}
                                            >
                                              {T(u?.t)}
                                              {u?.crit ? (
                                                <>
                                                  <span
                                                    style={{
                                                      fontSize: '10px',
                                                      fontWeight: '700',
                                                      padding: '2px 7px',
                                                      borderRadius: '999px',
                                                      background: 'hsl(6 91% 47% / .12)',
                                                      color: 'hsl(6 91% 47%)',
                                                    }}
                                                  >
                                                    {'Obrigatório'}
                                                  </span>
                                                </>
                                              ) : null}
                                            </div>
                                            <div
                                              style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', lineHeight: '1.4', marginTop: '2px' }}
                                            >
                                              {T(u?.regra)}
                                            </div>
                                            <div style={{ fontSize: '10.5px', color: 'hsl(0 0% 62%)', marginTop: '2px' }}>{T(u?.n)}</div>
                                          </div>
                                          {'\n                '}
                                          <button
                                            onClick={u?.onToggle}
                                            aria-label="Ligar ou desligar"
                                            style={{
                                              width: '44px',
                                              height: '44px',
                                              border: 'none',
                                              background: 'none',
                                              display: 'grid',
                                              placeItems: 'center',
                                              cursor: 'pointer',
                                              padding: '0',
                                              flex: 'none',
                                            }}
                                          >
                                            <span
                                              style={css(
                                                `position:relative;width:38px;height:22px;border-radius:999px;background:${S(u?.trk)};transition:background .15s`,
                                              )}
                                            >
                                              <span
                                                style={css(
                                                  `position:absolute;top:2px;left:${S(u?.knob)};width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .15s`,
                                                )}
                                              />
                                            </span>
                                          </button>
                                          {'\n              '}
                                        </div>
                                        {'\n            '}
                                      </Fragment>
                                    ))}
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n\n        '}
                              {v.ltRules ? (
                                <>
                                  {'\n          '}
                                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                                    <p style={{ margin: '0', fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                                      {'Regras próprias do time viram unidades na trilha ao publicar.'}
                                    </p>
                                    <button
                                      onClick={v.onNewRule}
                                      style={{
                                        flex: 'none',
                                        minHeight: '40px',
                                        padding: '0 14px',
                                        border: 'none',
                                        borderRadius: '10px',
                                        background: 'hsl(6 91% 47%)',
                                        color: '#fff',
                                        fontSize: '13px',
                                        fontWeight: '600',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '6px',
                                        boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                                      }}
                                    >
                                      <lu-icon name="plus" size="15" />
                                      {'Nova regra'}
                                    </button>
                                  </div>
                                  {'\n          '}
                                  {v.ruleFormOpen ? (
                                    <>
                                      {'\n            '}
                                      <div
                                        style={{
                                          background: '#fff',
                                          border: '1px solid hsl(0 0% 90%)',
                                          borderRadius: '16px',
                                          padding: '16px',
                                          display: 'flex',
                                          flexDirection: 'column',
                                          gap: '12px',
                                          animation: 'modalIn .2s both',
                                        }}
                                      >
                                        {'\n              '}
                                        <div style={{ fontSize: '15px', fontWeight: '700' }}>{'Nova regra do time'}</div>
                                        {'\n              '}
                                        <div>
                                          <label
                                            style={{
                                              display: 'block',
                                              fontSize: '11.5px',
                                              fontWeight: '600',
                                              color: 'hsl(0 0% 46%)',
                                              marginBottom: '6px',
                                            }}
                                          >
                                            {'Título'}
                                          </label>
                                          <input
                                            value={D(v.rfT, '')}
                                            onChange={v.onRfT}
                                            placeholder="Ex.: Checklist de implantação"
                                            style={{
                                              width: '100%',
                                              height: '42px',
                                              borderRadius: '9px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              padding: '0 12px',
                                              fontSize: '13.5px',
                                            }}
                                          />
                                        </div>
                                        {'\n              '}
                                        <div>
                                          <label
                                            style={{
                                              display: 'block',
                                              fontSize: '11.5px',
                                              fontWeight: '600',
                                              color: 'hsl(0 0% 46%)',
                                              marginBottom: '6px',
                                            }}
                                          >
                                            {'Descrição'}
                                          </label>
                                          <textarea
                                            value={D(v.rfD, '')}
                                            onChange={v.onRfD}
                                            rows="3"
                                            placeholder="O que a regra pede, em uma ou duas frases."
                                            style={{
                                              width: '100%',
                                              borderRadius: '9px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              padding: '10px 12px',
                                              fontSize: '13.5px',
                                              resize: 'vertical',
                                            }}
                                          />
                                        </div>
                                        {'\n              '}
                                        <div>
                                          <label
                                            style={{
                                              display: 'block',
                                              fontSize: '11.5px',
                                              fontWeight: '600',
                                              color: 'hsl(150 55% 35%)',
                                              marginBottom: '6px',
                                            }}
                                          >
                                            {'Exemplo bom'}
                                          </label>
                                          <textarea
                                            value={D(v.rfB, '')}
                                            onChange={v.onRfB}
                                            rows="2"
                                            style={{
                                              width: '100%',
                                              borderRadius: '9px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              padding: '10px 12px',
                                              fontSize: '13.5px',
                                              resize: 'vertical',
                                            }}
                                          />
                                        </div>
                                        {'\n              '}
                                        <div>
                                          <label
                                            style={{
                                              display: 'block',
                                              fontSize: '11.5px',
                                              fontWeight: '600',
                                              color: 'hsl(6 91% 47%)',
                                              marginBottom: '6px',
                                            }}
                                          >
                                            {'Exemplo ruim'}
                                          </label>
                                          <textarea
                                            value={D(v.rfR, '')}
                                            onChange={v.onRfR}
                                            rows="2"
                                            style={{
                                              width: '100%',
                                              borderRadius: '9px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              padding: '10px 12px',
                                              fontSize: '13.5px',
                                              resize: 'vertical',
                                            }}
                                          />
                                        </div>
                                        {'\n              '}
                                        <div>
                                          <label
                                            style={{
                                              display: 'block',
                                              fontSize: '11.5px',
                                              fontWeight: '600',
                                              color: 'hsl(0 0% 46%)',
                                              marginBottom: '6px',
                                            }}
                                          >
                                            {'Artigo da Wiki (opcional)'}
                                          </label>
                                          <input
                                            value={D(v.rfW, '')}
                                            onChange={v.onRfW}
                                            placeholder="wiki/artigos/..."
                                            style={{
                                              width: '100%',
                                              height: '42px',
                                              borderRadius: '9px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              padding: '0 12px',
                                              fontSize: '13.5px',
                                            }}
                                          />
                                        </div>
                                        {'\n              '}
                                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                                          <button
                                            onClick={v.onCancelRule}
                                            style={{
                                              minHeight: '40px',
                                              padding: '0 14px',
                                              borderRadius: '10px',
                                              border: '1px solid hsl(0 0% 90%)',
                                              background: '#fff',
                                              fontSize: '13px',
                                              fontWeight: '500',
                                              cursor: 'pointer',
                                              color: 'hsl(0 0% 13%)',
                                            }}
                                          >
                                            {'Cancelar'}
                                          </button>
                                          <button
                                            onClick={v.onSaveRule}
                                            style={{
                                              minHeight: '40px',
                                              padding: '0 14px',
                                              border: 'none',
                                              borderRadius: '10px',
                                              background: 'hsl(6 91% 47%)',
                                              color: '#fff',
                                              fontSize: '13px',
                                              fontWeight: '600',
                                              cursor: 'pointer',
                                            }}
                                          >
                                            {'Salvar rascunho'}
                                          </button>
                                        </div>
                                        {'\n            '}
                                      </div>
                                      {'\n          '}
                                    </>
                                  ) : null}
                                  {'\n          '}
                                  {v.noRules ? (
                                    <>
                                      <div
                                        style={{
                                          padding: '28px',
                                          textAlign: 'center',
                                          fontSize: '13px',
                                          color: 'hsl(0 0% 46%)',
                                          background: '#fff',
                                          border: '1px solid hsl(0 0% 90%)',
                                          borderRadius: '16px',
                                        }}
                                      >
                                        {'Nenhuma regra própria ainda.'}
                                      </div>
                                    </>
                                  ) : null}
                                  {'\n          '}
                                  {L(v.rules).map((r, $i38) => (
                                    <Fragment key={$i38}>
                                      {'\n            '}
                                      <div
                                        style={{
                                          background: '#fff',
                                          border: '1px solid hsl(0 0% 90%)',
                                          borderRadius: '16px',
                                          overflow: 'hidden',
                                          boxShadow: '0 1px 4px rgba(0,0,0,.06)',
                                        }}
                                      >
                                        {'\n              '}
                                        <button
                                          onClick={r?.onToggle}
                                          style={{
                                            width: '100%',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            padding: '14px 16px',
                                            border: 'none',
                                            background: 'none',
                                            cursor: 'pointer',
                                            textAlign: 'left',
                                            minHeight: '56px',
                                          }}
                                        >
                                          {'\n                '}
                                          <div style={{ flex: '1', minWidth: '0' }}>
                                            <div style={{ fontSize: '14px', fontWeight: '700' }}>{T(r?.t)}</div>
                                            <div style={{ display: 'flex', gap: '6px', marginTop: '4px', alignItems: 'center' }}>
                                              {r?.pub ? (
                                                <>
                                                  <span
                                                    style={{
                                                      fontSize: '10.5px',
                                                      fontWeight: '600',
                                                      padding: '2px 8px',
                                                      borderRadius: '999px',
                                                      background: 'hsl(150 55% 40% / .14)',
                                                      color: 'hsl(150 55% 40%)',
                                                    }}
                                                  >
                                                    {'Publicado'}
                                                  </span>
                                                </>
                                              ) : null}
                                              {r?.draft ? (
                                                <>
                                                  <span
                                                    style={{
                                                      fontSize: '10.5px',
                                                      fontWeight: '600',
                                                      padding: '2px 8px',
                                                      borderRadius: '999px',
                                                      background: 'hsl(40 92% 46% / .15)',
                                                      color: 'hsl(32 82% 42%)',
                                                    }}
                                                  >
                                                    {'Rascunho'}
                                                  </span>
                                                </>
                                              ) : null}
                                              <span style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)' }}>{T(r?.nq)}</span>
                                            </div>
                                          </div>
                                          {'\n                '}
                                          <lu-icon name="chevron-down" size="18" />
                                          {'\n              '}
                                        </button>
                                        {'\n              '}
                                        {r?.open ? (
                                          <>
                                            {'\n                '}
                                            <div
                                              style={{
                                                padding: '0 16px 16px',
                                                display: 'flex',
                                                flexDirection: 'column',
                                                gap: '10px',
                                                borderTop: '1px solid hsl(0 0% 93%)',
                                              }}
                                            >
                                              {'\n                  '}
                                              <p
                                                style={{ margin: '12px 0 0', fontSize: '13px', lineHeight: '1.5', color: 'hsl(0 0% 30%)' }}
                                              >
                                                {T(r?.d)}
                                              </p>
                                              {'\n                  '}
                                              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '8px' }}>
                                                <div
                                                  style={{
                                                    padding: '10px 12px',
                                                    borderRadius: '10px',
                                                    background: 'hsl(150 55% 40% / .08)',
                                                    fontSize: '12.5px',
                                                    lineHeight: '1.45',
                                                  }}
                                                >
                                                  <b style={{ color: 'hsl(150 55% 35%)' }}>{'Bom:'}</b> {T(r?.bom)}
                                                </div>
                                                <div
                                                  style={{
                                                    padding: '10px 12px',
                                                    borderRadius: '10px',
                                                    background: 'hsl(6 91% 47% / .06)',
                                                    fontSize: '12.5px',
                                                    lineHeight: '1.45',
                                                  }}
                                                >
                                                  <b style={{ color: 'hsl(6 91% 47%)' }}>{'Ruim:'}</b> {T(r?.ruim)}
                                                </div>
                                              </div>
                                              {'\n                  '}
                                              <div
                                                style={{
                                                  display: 'flex',
                                                  alignItems: 'center',
                                                  gap: '6px',
                                                  fontSize: '12px',
                                                  color: 'hsl(0 0% 46%)',
                                                }}
                                              >
                                                <lu-icon name="book-text" size="14" />
                                                {T(r?.wiki)}
                                              </div>
                                              {'\n                  '}
                                              {L(r?.qs).map((q, $i39) => (
                                                <Fragment key={$i39}>
                                                  <div
                                                    style={{
                                                      padding: '10px 12px',
                                                      border: '1px solid hsl(0 0% 93%)',
                                                      borderRadius: '10px',
                                                    }}
                                                  >
                                                    <div
                                                      style={{
                                                        fontSize: '10.5px',
                                                        fontWeight: '700',
                                                        letterSpacing: '.06em',
                                                        textTransform: 'uppercase',
                                                        color: 'hsl(0 0% 62%)',
                                                      }}
                                                    >
                                                      {T(q?.tipo)}
                                                    </div>
                                                    <div style={{ fontSize: '12.5px', fontWeight: '600', marginTop: '2px' }}>{T(q?.t)}</div>
                                                    <div style={{ fontSize: '11.5px', color: 'hsl(150 55% 35%)', marginTop: '4px' }}>
                                                      {'Correta: '}
                                                      {T(q?.ans)}
                                                    </div>
                                                  </div>
                                                </Fragment>
                                              ))}
                                              {'\n                  '}
                                              {r?.showQForm ? (
                                                <>
                                                  {'\n                    '}
                                                  <div
                                                    style={{
                                                      border: '1px solid hsl(6 91% 47% / .35)',
                                                      borderRadius: '14px',
                                                      padding: '14px',
                                                      display: 'flex',
                                                      flexDirection: 'column',
                                                      gap: '12px',
                                                      background: 'hsl(0 0% 98.5%)',
                                                    }}
                                                  >
                                                    {'\n                      '}
                                                    <div
                                                      style={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'space-between',
                                                        gap: '8px',
                                                      }}
                                                    >
                                                      <div style={{ fontSize: '14px', fontWeight: '700' }}>{'Nova questão'}</div>
                                                      <button
                                                        onClick={v.onHubia}
                                                        style={{
                                                          minHeight: '38px',
                                                          padding: '0 12px',
                                                          borderRadius: '9px',
                                                          border: '1px solid hsl(6 91% 47% / .35)',
                                                          background: 'hsl(6 91% 47% / .06)',
                                                          color: 'hsl(6 91% 47%)',
                                                          fontSize: '12.5px',
                                                          fontWeight: '600',
                                                          cursor: 'pointer',
                                                          display: 'flex',
                                                          alignItems: 'center',
                                                          gap: '6px',
                                                        }}
                                                      >
                                                        <hubia-orb size="16" />
                                                        {'Gerar com Hubia'}
                                                      </button>
                                                    </div>
                                                    {'\n                      '}
                                                    <div
                                                      style={{
                                                        display: 'flex',
                                                        background: 'hsl(0 0% 93%)',
                                                        borderRadius: '8px',
                                                        padding: '3px',
                                                        gap: '2px',
                                                      }}
                                                    >
                                                      {L(v.qfTipos).map((t, $i40) => (
                                                        <Fragment key={$i40}>
                                                          <button
                                                            onClick={t?.onClick}
                                                            style={css(
                                                              `flex:1;min-height:36px;border:none;border-radius:6px;background:${S(t?.bg)};color:${S(t?.fg)};box-shadow:${S(t?.sh)};font-size:11.5px;font-weight:600;cursor:pointer`,
                                                            )}
                                                          >
                                                            {T(t?.t)}
                                                          </button>
                                                        </Fragment>
                                                      ))}
                                                    </div>
                                                    {'\n                      '}
                                                    {v.qfHubia ? (
                                                      <>
                                                        <div
                                                          style={{
                                                            fontSize: '11.5px',
                                                            color: 'hsl(0 0% 46%)',
                                                            display: 'flex',
                                                            gap: '6px',
                                                            alignItems: 'center',
                                                          }}
                                                        >
                                                          <lu-icon name="sparkles" size="13" />
                                                          {'Rascunho da Hubia. A Hubia pode errar. Confira antes de salvar.'}
                                                        </div>
                                                      </>
                                                    ) : null}
                                                    {'\n                      '}
                                                    <div>
                                                      <label
                                                        style={{
                                                          display: 'block',
                                                          fontSize: '11.5px',
                                                          fontWeight: '600',
                                                          color: 'hsl(0 0% 46%)',
                                                          marginBottom: '6px',
                                                        }}
                                                      >
                                                        {'Enunciado'}
                                                      </label>
                                                      <textarea
                                                        value={D(v.qfEnun, '')}
                                                        onChange={v.onQfEnun}
                                                        rows="3"
                                                        style={{
                                                          width: '100%',
                                                          borderRadius: '9px',
                                                          border: '1px solid hsl(0 0% 90%)',
                                                          padding: '10px 12px',
                                                          fontSize: '13px',
                                                          resize: 'vertical',
                                                          background: '#fff',
                                                        }}
                                                      />
                                                    </div>
                                                    {'\n                      '}
                                                    <div>
                                                      <label
                                                        style={{
                                                          display: 'block',
                                                          fontSize: '11.5px',
                                                          fontWeight: '600',
                                                          color: 'hsl(0 0% 46%)',
                                                          marginBottom: '6px',
                                                        }}
                                                      >
                                                        {'Alternativas · toque no círculo para marcar a correta'}
                                                      </label>
                                                      {'\n                        '}
                                                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                                        {'\n                          '}
                                                        {L(v.qfOpts).map((o, $i41) => (
                                                          <Fragment key={$i41}>
                                                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                              <button
                                                                onClick={o?.onCorrect}
                                                                aria-label="Marcar como correta"
                                                                style={{
                                                                  width: '44px',
                                                                  height: '44px',
                                                                  border: 'none',
                                                                  background: 'none',
                                                                  display: 'grid',
                                                                  placeItems: 'center',
                                                                  cursor: 'pointer',
                                                                  padding: '0',
                                                                  flex: 'none',
                                                                }}
                                                              >
                                                                <span
                                                                  style={css(
                                                                    `width:20px;height:20px;border-radius:999px;border:2px solid ${S(o?.rbd)};background:${S(o?.rbg)}`,
                                                                  )}
                                                                />
                                                              </button>
                                                              {v.qfNotVF ? (
                                                                <>
                                                                  <input
                                                                    value={D(o?.v, '')}
                                                                    onChange={o?.onChange}
                                                                    placeholder={o?.ph}
                                                                    style={{
                                                                      flex: '1',
                                                                      minWidth: '0',
                                                                      height: '40px',
                                                                      borderRadius: '9px',
                                                                      border: '1px solid hsl(0 0% 90%)',
                                                                      padding: '0 10px',
                                                                      fontSize: '13px',
                                                                      background: '#fff',
                                                                    }}
                                                                  />
                                                                </>
                                                              ) : null}
                                                              {v.qfVF ? (
                                                                <>
                                                                  <span style={{ fontSize: '13px', fontWeight: '600' }}>{T(o?.v)}</span>
                                                                </>
                                                              ) : null}
                                                            </div>
                                                          </Fragment>
                                                        ))}
                                                        {'\n                        '}
                                                      </div>
                                                      {'\n                      '}
                                                    </div>
                                                    {'\n                      '}
                                                    <div>
                                                      <label
                                                        style={{
                                                          display: 'block',
                                                          fontSize: '11.5px',
                                                          fontWeight: '600',
                                                          color: 'hsl(0 0% 46%)',
                                                          marginBottom: '6px',
                                                        }}
                                                      >
                                                        {'Explicação do "Por quê?"'}
                                                      </label>
                                                      <textarea
                                                        value={D(v.qfExp, '')}
                                                        onChange={v.onQfExp}
                                                        rows="2"
                                                        style={{
                                                          width: '100%',
                                                          borderRadius: '9px',
                                                          border: '1px solid hsl(0 0% 90%)',
                                                          padding: '10px 12px',
                                                          fontSize: '13px',
                                                          resize: 'vertical',
                                                          background: '#fff',
                                                        }}
                                                      />
                                                    </div>
                                                    {'\n                      '}
                                                    <div
                                                      style={{
                                                        border: '1px dashed hsl(0 0% 80%)',
                                                        borderRadius: '12px',
                                                        padding: '12px',
                                                        background: '#fff',
                                                      }}
                                                    >
                                                      <div
                                                        style={{
                                                          fontSize: '10.5px',
                                                          fontWeight: '700',
                                                          letterSpacing: '.06em',
                                                          textTransform: 'uppercase',
                                                          color: 'hsl(0 0% 62%)',
                                                          marginBottom: '6px',
                                                        }}
                                                      >
                                                        {'Pré-visualização · '}
                                                        {T(v.prevTipo)}
                                                      </div>
                                                      <div
                                                        style={{
                                                          fontSize: '13.5px',
                                                          fontWeight: '700',
                                                          lineHeight: '1.4',
                                                          marginBottom: '8px',
                                                        }}
                                                      >
                                                        {T(v.prevEnun)}
                                                      </div>
                                                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                                        {L(v.prevOpts).map((o, $i42) => (
                                                          <Fragment key={$i42}>
                                                            <div
                                                              style={css(
                                                                `padding:9px 12px;border-radius:10px;border:1.5px solid ${S(o?.bd)};font-size:12.5px`,
                                                              )}
                                                            >
                                                              {T(o?.t)}
                                                            </div>
                                                          </Fragment>
                                                        ))}
                                                      </div>
                                                    </div>
                                                    {'\n                      '}
                                                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                                                      <button
                                                        onClick={v.onCancelQ}
                                                        style={{
                                                          minHeight: '40px',
                                                          padding: '0 14px',
                                                          borderRadius: '10px',
                                                          border: '1px solid hsl(0 0% 90%)',
                                                          background: '#fff',
                                                          fontSize: '13px',
                                                          fontWeight: '500',
                                                          cursor: 'pointer',
                                                          color: 'hsl(0 0% 13%)',
                                                        }}
                                                      >
                                                        {'Cancelar'}
                                                      </button>
                                                      <button
                                                        onClick={v.onAddQ}
                                                        style={{
                                                          minHeight: '40px',
                                                          padding: '0 14px',
                                                          border: 'none',
                                                          borderRadius: '10px',
                                                          background: 'hsl(6 91% 47%)',
                                                          color: '#fff',
                                                          fontSize: '13px',
                                                          fontWeight: '600',
                                                          cursor: 'pointer',
                                                        }}
                                                      >
                                                        {'Adicionar questão'}
                                                      </button>
                                                    </div>
                                                    {'\n                    '}
                                                  </div>
                                                  {'\n                  '}
                                                </>
                                              ) : null}
                                              {'\n                  '}
                                              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                                                {'\n                    '}
                                                <button
                                                  onClick={r?.onNewQ}
                                                  style={{
                                                    minHeight: '40px',
                                                    padding: '0 12px',
                                                    borderRadius: '10px',
                                                    border: '1px solid hsl(0 0% 90%)',
                                                    background: '#fff',
                                                    fontSize: '12.5px',
                                                    fontWeight: '600',
                                                    cursor: 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '6px',
                                                    color: 'hsl(0 0% 13%)',
                                                  }}
                                                >
                                                  <lu-icon name="plus" size="14" />
                                                  {'Criar questão'}
                                                </button>
                                                {'\n                    '}
                                                {r?.draft ? (
                                                  <>
                                                    <button
                                                      onClick={r?.onPublish}
                                                      style={{
                                                        minHeight: '40px',
                                                        padding: '0 14px',
                                                        border: 'none',
                                                        borderRadius: '10px',
                                                        background: 'hsl(6 91% 47%)',
                                                        color: '#fff',
                                                        fontSize: '12.5px',
                                                        fontWeight: '600',
                                                        cursor: 'pointer',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '6px',
                                                      }}
                                                    >
                                                      <lu-icon name="send" size="14" />
                                                      {'Publicar'}
                                                    </button>
                                                  </>
                                                ) : null}
                                                {'\n                    '}
                                                {r?.pub ? (
                                                  <>
                                                    <button
                                                      onClick={r?.onUnpub}
                                                      style={{
                                                        minHeight: '40px',
                                                        padding: '0 12px',
                                                        borderRadius: '10px',
                                                        border: '1px solid hsl(0 0% 90%)',
                                                        background: '#fff',
                                                        fontSize: '12.5px',
                                                        fontWeight: '500',
                                                        cursor: 'pointer',
                                                        color: 'hsl(6 91% 47%)',
                                                      }}
                                                    >
                                                      {'Despublicar'}
                                                    </button>
                                                  </>
                                                ) : null}
                                                {'\n                  '}
                                              </div>
                                              {'\n                '}
                                            </div>
                                            {'\n              '}
                                          </>
                                        ) : null}
                                        {'\n            '}
                                      </div>
                                      {'\n          '}
                                    </Fragment>
                                  ))}
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n\n        '}
                              {v.ltMand ? (
                                <>
                                  {'\n          '}
                                  <div
                                    style={{
                                      background: '#fff',
                                      border: '1px solid hsl(0 0% 90%)',
                                      borderRadius: '16px',
                                      padding: '16px',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '16px',
                                    }}
                                  >
                                    {'\n            '}
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                                      <div>
                                        <div style={{ fontSize: '14px', fontWeight: '600' }}>{'Trilha obrigatória'}</div>
                                        <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>
                                          {'Aparece com prazo para o público escolhido.'}
                                        </div>
                                      </div>
                                      <button
                                        onClick={v.onMToggle}
                                        aria-label="Obrigatória"
                                        style={{
                                          width: '44px',
                                          height: '44px',
                                          border: 'none',
                                          background: 'none',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                          padding: '0',
                                        }}
                                      >
                                        <span
                                          style={css(
                                            `position:relative;width:38px;height:22px;border-radius:999px;background:${S(v.mTrk)};transition:background .15s`,
                                          )}
                                        >
                                          <span
                                            style={css(
                                              `position:absolute;top:2px;left:${S(v.mKnob)};width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .15s`,
                                            )}
                                          />
                                        </span>
                                      </button>
                                    </div>
                                    {'\n            '}
                                    <div>
                                      <label
                                        style={{
                                          display: 'block',
                                          fontSize: '11.5px',
                                          fontWeight: '600',
                                          color: 'hsl(0 0% 46%)',
                                          marginBottom: '6px',
                                        }}
                                      >
                                        {'Prazo'}
                                      </label>
                                      <input
                                        type="date"
                                        value={D(v.mPrazo, '')}
                                        onChange={v.onMPrazo}
                                        style={{
                                          width: '100%',
                                          height: '44px',
                                          borderRadius: '9px',
                                          border: '1px solid hsl(0 0% 90%)',
                                          padding: '0 12px',
                                          fontSize: '14px',
                                          background: '#fff',
                                        }}
                                      />
                                    </div>
                                    {'\n            '}
                                    <div>
                                      <label
                                        style={{
                                          display: 'block',
                                          fontSize: '11.5px',
                                          fontWeight: '600',
                                          color: 'hsl(0 0% 46%)',
                                          marginBottom: '6px',
                                        }}
                                      >
                                        {'Público'}
                                      </label>
                                      <div
                                        style={{
                                          display: 'flex',
                                          background: 'hsl(0 0% 95%)',
                                          borderRadius: '8px',
                                          padding: '4px',
                                          gap: '2px',
                                        }}
                                      >
                                        <button
                                          onClick={v.onPubTime}
                                          style={css(
                                            `flex:1;min-height:40px;border:none;border-radius:6px;background:${S(v.mPubTime?.bg)};color:${S(v.mPubTime?.fg)};box-shadow:${S(v.mPubTime?.sh)};font-size:13px;font-weight:500;cursor:pointer`,
                                          )}
                                        >
                                          {'Time inteiro'}
                                        </button>
                                        <button
                                          onClick={v.onPubNov}
                                          style={css(
                                            `flex:1;min-height:40px;border:none;border-radius:6px;background:${S(v.mPubNov?.bg)};color:${S(v.mPubNov?.fg)};box-shadow:${S(v.mPubNov?.sh)};font-size:13px;font-weight:500;cursor:pointer`,
                                          )}
                                        >
                                          {'Novos contratados'}
                                        </button>
                                      </div>
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n\n        '}
                              {v.ltPanel ? (
                                <>
                                  {'\n          '}
                                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                                    {'\n            '}
                                    <div
                                      style={{
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        borderRadius: '15px',
                                        padding: '14px',
                                      }}
                                    >
                                      <div style={{ fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em' }}>{T(v.teamAvg)}</div>
                                      <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{'conclusão média do time'}</div>
                                    </div>
                                    {'\n            '}
                                    <div
                                      style={{
                                        background: '#fff',
                                        border: '1px solid hsl(0 0% 90%)',
                                        borderRadius: '15px',
                                        padding: '14px',
                                      }}
                                    >
                                      <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginBottom: '6px' }}>
                                        {'Regras com mais erro'}
                                      </div>
                                      {L(v.worst).map((w, $i43) => (
                                        <Fragment key={$i43}>
                                          <div
                                            style={css(
                                              `font-size:12px;font-weight:600;color:${S(w?.fg)};white-space:nowrap;overflow:hidden;text-overflow:ellipsis`,
                                            )}
                                          >
                                            {T(w?.t)}
                                            {' · '}
                                            {T(w?.vS)}
                                          </div>
                                        </Fragment>
                                      ))}
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n          '}
                                  <div
                                    style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '16px', padding: '16px' }}
                                  >
                                    {'\n            '}
                                    <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '12px' }}>
                                      {'Conclusão por pessoa'}
                                    </div>
                                    {'\n            '}
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                                      {'\n              '}
                                      {L(v.members).map((m, $i44) => (
                                        <Fragment key={$i44}>
                                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                            <span
                                              style={{
                                                width: '32px',
                                                height: '32px',
                                                borderRadius: '999px',
                                                background: 'hsl(6 91% 47%)',
                                                color: '#fff',
                                                display: 'grid',
                                                placeItems: 'center',
                                                fontSize: '11px',
                                                fontWeight: '700',
                                                flex: 'none',
                                              }}
                                            >
                                              {T(m?.av?.ini)}
                                            </span>
                                            <div style={{ flex: '1', minWidth: '0' }}>
                                              <div
                                                style={{
                                                  display: 'flex',
                                                  justifyContent: 'space-between',
                                                  fontSize: '12.5px',
                                                  fontWeight: '600',
                                                }}
                                              >
                                                <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                  {T(m?.nome)}
                                                </span>
                                                <span style={css(`color:${S(m?.fg)}`)}>{T(m?.pctS)}</span>
                                              </div>
                                              <div
                                                style={{
                                                  height: '6px',
                                                  borderRadius: '999px',
                                                  background: 'hsl(0 0% 93%)',
                                                  marginTop: '5px',
                                                  overflow: 'hidden',
                                                }}
                                              >
                                                <div
                                                  style={css(`height:100%;width:${S(m?.pctS)};background:${S(m?.fg)};border-radius:999px`)}
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </Fragment>
                                      ))}
                                      {'\n            '}
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n          '}
                                  <div
                                    style={{ background: '#fff', border: '1px solid hsl(0 0% 90%)', borderRadius: '16px', padding: '16px' }}
                                  >
                                    {'\n            '}
                                    <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '12px' }}>{'Precisão por regra'}</div>
                                    {'\n            '}
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                      {'\n              '}
                                      {L(v.prec).map((x, $i45) => (
                                        <Fragment key={$i45}>
                                          <div>
                                            <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', fontSize: '12px' }}>
                                              <span style={{ fontWeight: '600' }}>{T(x?.t)}</span>
                                              <span style={css(`color:${S(x?.fg)};font-weight:700`)}>
                                                {T(x?.vS)}
                                                {' · '}
                                                {T(x?.band)}
                                              </span>
                                            </div>
                                            <div
                                              style={{
                                                height: '6px',
                                                borderRadius: '999px',
                                                background: 'hsl(0 0% 93%)',
                                                marginTop: '5px',
                                                overflow: 'hidden',
                                              }}
                                            >
                                              <div
                                                style={css(`height:100%;width:${S(x?.vS)};background:${S(x?.fg)};border-radius:999px`)}
                                              />
                                            </div>
                                          </div>
                                        </Fragment>
                                      ))}
                                      {'\n            '}
                                    </div>
                                    {'\n          '}
                                  </div>
                                  {'\n        '}
                                </>
                              ) : null}
                              {'\n      '}
                            </div>
                            {'\n    '}
                          </>
                        ) : null}
                        {'\n    '}
                      </div>
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.isTabs ? (
                  <>
                    {'\n  '}
                    <div
                      style={{
                        flex: 'none',
                        display: 'flex',
                        background: '#fff',
                        borderTop: '1px solid hsl(0 0% 90%)',
                        padding: '6px 4px calc(6px + env(safe-area-inset-bottom))',
                        position: 'relative',
                        zIndex: '30',
                      }}
                    >
                      {'\n    '}
                      {L(v.tabs).map((t, $i46) => (
                        <Fragment key={$i46}>
                          {'\n      '}
                          <button
                            onClick={t?.onClick}
                            style={css(
                              `flex:1;min-height:54px;border:none;background:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;color:${S(t?.fg)};font-size:10.5px;font-weight:${S(t?.fw)}`,
                            )}
                          >
                            <span
                              style={css(
                                `width:48px;height:30px;border-radius:999px;display:grid;place-items:center;background:${S(t?.bg)};transition:background .2s`,
                              )}
                            >
                              <lu-icon name={t?.icon} size="20" />
                            </span>
                            {T(t?.label)}
                          </button>
                          {'\n    '}
                        </Fragment>
                      ))}
                      {'\n  '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
              </div>
            </>
          ) : null}
          {v.isLesson ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '50',
                  display: 'flex',
                  flexDirection: 'column',
                  background: 'hsl(0 0% 98%)',
                  animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                }}
              >
                {'\n  '}
                <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px' }}>
                  {'\n    '}
                  <button
                    onClick={v.onExit}
                    aria-label="Sair da lição"
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '12px',
                      border: 'none',
                      background: 'none',
                      color: 'hsl(0 0% 46%)',
                      display: 'grid',
                      placeItems: 'center',
                      cursor: 'pointer',
                      flex: 'none',
                    }}
                  >
                    <lu-icon name="x" size="24" />
                  </button>
                  {'\n    '}
                  <div
                    style={{
                      position: 'relative',
                      flex: '1',
                      height: '14px',
                      borderRadius: '999px',
                      background: 'hsl(0 0% 91%)',
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={css(
                        `position:relative;height:100%;width:${S(v.lessonPct)};background:hsl(6 91% 47%);border-radius:999px;transition:width .55s cubic-bezier(.34,1.56,.64,1);overflow:hidden`,
                      )}
                    >
                      <span
                        style={{
                          position: 'absolute',
                          top: '3px',
                          left: '8px',
                          right: '8px',
                          height: '3px',
                          borderRadius: '999px',
                          background: 'rgba(255,255,255,.35)',
                        }}
                      />
                      {T(v.shineEl)}
                    </div>
                  </div>
                  {'\n    '}
                  {v.showCombo ? <>{T(v.comboEl)}</> : null}
                  {'\n    '}
                  {v.isTimed ? (
                    <>
                      <span
                        style={css(
                          `display:flex;align-items:center;gap:4px;font-size:13px;font-weight:700;color:${S(v.timerFg)};font-variant-numeric:tabular-nums`,
                        )}
                      >
                        <lu-icon name="timer" size="16" />
                        {T(v.secsLeft)}
                      </span>
                    </>
                  ) : null}
                  {'\n    '}
                  <button
                    onClick={v.onLessonReport}
                    aria-label="Reportar problema nesta questão"
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '12px',
                      border: 'none',
                      background: 'none',
                      color: 'hsl(0 0% 46%)',
                      display: 'grid',
                      placeItems: 'center',
                      cursor: 'pointer',
                      flex: 'none',
                    }}
                  >
                    <lu-icon name="flag" size="20" />
                  </button>
                  {'\n  '}
                </div>
                {'\n  '}
                <div style={{ flex: '1', minHeight: '0', overflowY: 'auto', padding: '6px 20px 220px' }}>
                  {'\n    '}
                  {v.isTip ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both', display: 'flex', flexDirection: 'column', gap: '14px', paddingTop: '10px' }}>
                        {'\n        '}
                        <span
                          style={{
                            alignSelf: 'flex-start',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '11px',
                            fontWeight: '700',
                            letterSpacing: '.08em',
                            textTransform: 'uppercase',
                            color: 'hsl(40 92% 40%)',
                            background: 'hsl(40 92% 46% / .15)',
                            padding: '5px 10px',
                            borderRadius: '999px',
                          }}
                        >
                          <lu-icon name="lightbulb" size="13" />
                          {'Cartão de dica'}
                        </span>
                        {'\n        '}
                        <h2 style={{ margin: '0', fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em' }}>{T(v.tipTitle)}</h2>
                        {'\n        '}
                        <div
                          style={{
                            background: '#fff',
                            border: '1px solid hsl(0 0% 90%)',
                            borderRadius: '16px',
                            padding: '18px',
                            boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                            fontSize: '15px',
                            lineHeight: '1.6',
                          }}
                        >
                          {T(v.tipText)}
                        </div>
                        {'\n        '}
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px',
                            padding: '12px 14px',
                            borderRadius: '12px',
                            background: '#fff',
                            border: '1px solid hsl(0 0% 90%)',
                          }}
                        >
                          <span
                            style={{
                              width: '34px',
                              height: '34px',
                              borderRadius: '10px',
                              background: 'hsl(6 91% 47% / .12)',
                              color: 'hsl(6 91% 47%)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name="book-text" size="17" />
                          </span>
                          <div style={{ minWidth: '0' }}>
                            <div style={{ fontSize: '12px', fontWeight: '700', color: 'hsl(6 91% 47%)' }}>{'Ver na Wiki'}</div>
                            <div style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', wordBreak: 'break-word' }}>{T(v.tipFonte)}</div>
                          </div>
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.notTip ? (
                    <>
                      {'\n      '}
                      <div style={{ animation: 'up8 .3s both' }}>
                        {'\n        '}
                        <span
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '11px',
                            fontWeight: '700',
                            letterSpacing: '.08em',
                            textTransform: 'uppercase',
                            color: 'hsl(6 91% 47%)',
                            marginBottom: '10px',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          <lu-icon name={v.typeIcon} size="14" />
                          {T(v.typeLabel)}
                        </span>
                        {'\n        '}
                        {v.isPlainQ ? (
                          <>
                            <h2
                              style={{
                                margin: '0 0 20px',
                                fontSize: '19px',
                                fontWeight: '700',
                                lineHeight: '1.35',
                                letterSpacing: '-.01em',
                                textWrap: 'pretty',
                              }}
                            >
                              {T(v.enun)}
                            </h2>
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isCenario ? (
                          <>
                            {'\n          '}
                            <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', marginBottom: '20px' }}>
                              {'\n            '}
                              <span
                                style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '12px',
                                  background: 'hsl(212 72% 48% / .12)',
                                  color: 'hsl(212 72% 48%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  flex: 'none',
                                }}
                              >
                                <lu-icon name="store" size="20" />
                              </span>
                              {'\n            '}
                              <div
                                style={{
                                  flex: '1',
                                  background: '#fff',
                                  border: '1px solid hsl(0 0% 90%)',
                                  borderRadius: '4px 16px 16px 16px',
                                  padding: '14px 16px',
                                  boxShadow: '0 1px 4px rgba(0,0,0,.06)',
                                }}
                              >
                                <div
                                  style={{
                                    fontSize: '11px',
                                    fontWeight: '700',
                                    letterSpacing: '.06em',
                                    textTransform: 'uppercase',
                                    color: 'hsl(212 72% 48%)',
                                    marginBottom: '4px',
                                  }}
                                >
                                  {'Caso de turno'}
                                </div>
                                <div style={{ fontSize: '16px', fontWeight: '600', lineHeight: '1.45', textWrap: 'pretty' }}>
                                  {T(v.enun)}
                                </div>
                              </div>
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isDiag ? (
                          <>
                            {'\n          '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '16px',
                                marginBottom: '20px',
                                overflow: 'hidden',
                                boxShadow: '0 1px 4px rgba(0,0,0,.06)',
                              }}
                            >
                              {'\n            '}
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                  padding: '9px 14px',
                                  background: 'hsl(40 92% 46% / .12)',
                                  borderBottom: '1px solid hsl(40 92% 46% / .25)',
                                  fontSize: '11px',
                                  fontWeight: '700',
                                  letterSpacing: '.06em',
                                  textTransform: 'uppercase',
                                  color: 'hsl(32 82% 36%)',
                                }}
                              >
                                <lu-icon name="triangle-alert" size="14" />
                                {'Sintoma relatado'}
                              </div>
                              {'\n            '}
                              <div
                                style={{
                                  padding: '14px 16px',
                                  fontSize: '15.5px',
                                  fontWeight: '600',
                                  lineHeight: '1.5',
                                  textWrap: 'pretty',
                                }}
                              >
                                {T(v.enun)}
                              </div>
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isLacuna ? (
                          <>
                            {'\n          '}
                            <div
                              style={{ fontSize: '19px', fontWeight: '700', lineHeight: '1.6', marginBottom: '22px', textWrap: 'pretty' }}
                            >
                              {T(v.lacA)}
                              <span
                                style={css(
                                  `display:inline-block;min-width:96px;margin:0 4px;padding:0 10px;border-bottom:3px solid ${S(v.lacBd)};color:${S(v.lacFg)};text-align:center;transition:all .2s`,
                                )}
                              >
                                {T(v.lacBlank)}
                              </span>
                              {T(v.lacB)}
                            </div>
                            {'\n          '}
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                              {'\n            '}
                              {L(v.opts).map((o, $i47) => (
                                <Fragment key={$i47}>
                                  <button
                                    onClick={o?.onClick}
                                    style={css(
                                      `min-height:48px;padding:0 16px;border-radius:12px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};box-shadow:${S(o?.sh)};transform:${S(o?.tr)};animation:${S(o?.anim)};font-size:14.5px;font-weight:600;cursor:pointer;transition:transform .15s cubic-bezier(.16,1,.3,1), border-color .15s, background .15s`,
                                    )}
                                  >
                                    {T(o?.text)}
                                  </button>
                                </Fragment>
                              ))}
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isTouch ? (
                          <>
                            {'\n          '}
                            <h2 style={{ margin: '0 0 14px', fontSize: '18px', fontWeight: '700', lineHeight: '1.35', textWrap: 'pretty' }}>
                              {T(v.touchQ)}
                            </h2>
                            {'\n          '}
                            <div
                              style={{
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '14px',
                                overflow: 'hidden',
                                background: '#fff',
                                boxShadow: '0 4px 12px rgba(0,0,0,.08)',
                              }}
                            >
                              {'\n            '}
                              <div
                                style={{
                                  height: '34px',
                                  background: 'hsl(0 0% 98.5%)',
                                  borderBottom: '1px solid hsl(0 0% 93%)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '6px',
                                  padding: '0 10px',
                                }}
                              >
                                <span style={{ width: '8px', height: '8px', borderRadius: '999px', background: '#ff5f57' }} />
                                <span style={{ width: '8px', height: '8px', borderRadius: '999px', background: '#febc2e' }} />
                                <span style={{ width: '8px', height: '8px', borderRadius: '999px', background: '#28c840' }} />
                                <span
                                  style={{
                                    marginLeft: '6px',
                                    fontSize: '11px',
                                    color: 'hsl(0 0% 46%)',
                                    whiteSpace: 'nowrap',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                  }}
                                >
                                  {T(v.touchCap)}
                                </span>
                              </div>
                              {'\n            '}
                              <div style={{ display: 'grid', gridTemplateColumns: '150px 1fr', minHeight: '230px' }}>
                                {'\n              '}
                                <div
                                  style={{
                                    borderRight: '1px solid hsl(0 0% 93%)',
                                    padding: '8px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '6px',
                                    background: '#fff',
                                  }}
                                >
                                  {'\n                '}
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 4px 8px' }}>
                                    <span
                                      style={{
                                        width: '20px',
                                        height: '20px',
                                        background: 'url("assets/shape-b.svg") center/contain no-repeat',
                                      }}
                                    />
                                    <span style={{ fontSize: '11px', fontWeight: '800' }}>{'Takeat'}</span>
                                  </div>
                                  {'\n                '}
                                  {L(v.opts).map((o, $i48) => (
                                    <Fragment key={$i48}>
                                      <button
                                        onClick={o?.onClick}
                                        style={css(
                                          `position:relative;min-height:44px;text-align:left;padding:8px;border-radius:9px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:11.5px;font-weight:600;line-height:1.25;display:flex;align-items:center;gap:7px;cursor:pointer;animation:${S(o?.anim)}`,
                                        )}
                                      >
                                        <span
                                          style={{
                                            width: '14px',
                                            height: '14px',
                                            borderRadius: '4px',
                                            background: 'hsl(0 0% 88%)',
                                            flex: 'none',
                                          }}
                                        />
                                        {T(o?.text)}
                                        {o?.sel ? (
                                          <>
                                            <span
                                              style={{
                                                position: 'absolute',
                                                inset: '-5px',
                                                borderRadius: '12px',
                                                border: '2px solid hsl(6 91% 47% / .6)',
                                                animation: 'pulseRing 1.6s infinite',
                                                pointerEvents: 'none',
                                              }}
                                            />
                                          </>
                                        ) : null}
                                      </button>
                                    </Fragment>
                                  ))}
                                  {'\n              '}
                                </div>
                                {'\n              '}
                                <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                  {'\n                '}
                                  <div style={{ height: '12px', width: '60%', borderRadius: '4px', background: 'hsl(0 0% 93%)' }} />
                                  <div style={{ height: '46px', borderRadius: '10px', background: 'hsl(0 0% 96%)' }} />
                                  <div style={{ height: '8px', width: '80%', borderRadius: '4px', background: 'hsl(0 0% 93%)' }} />
                                  <div style={{ height: '8px', width: '55%', borderRadius: '4px', background: 'hsl(0 0% 93%)' }} />
                                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
                                    <div style={{ height: '40px', borderRadius: '8px', background: 'hsl(0 0% 96%)' }} />
                                    <div style={{ height: '40px', borderRadius: '8px', background: 'hsl(0 0% 96%)' }} />
                                  </div>
                                  {'\n              '}
                                </div>
                                {'\n            '}
                              </div>
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isOptList ? (
                          <>
                            {'\n          '}
                            <div style={css(`display:grid;grid-template-columns:${S(v.optCols)};gap:10px`)}>
                              {'\n            '}
                              {L(v.opts).map((o, $i49) => (
                                <Fragment key={$i49}>
                                  {'\n              '}
                                  <button
                                    onClick={o?.onClick}
                                    style={css(
                                      `min-height:56px;padding:12px 16px;border-radius:14px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};box-shadow:${S(o?.sh)};transform:${S(o?.tr)};animation:${S(o?.anim)};font-size:14.5px;font-weight:600;line-height:1.4;text-align:left;cursor:pointer;transition:transform .15s cubic-bezier(.16,1,.3,1), border-color .15s, background .15s;text-wrap:pretty`,
                                    )}
                                  >
                                    {T(o?.text)}
                                  </button>
                                  {'\n            '}
                                </Fragment>
                              ))}
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isNumeric ? (
                          <>
                            {'\n          '}
                            <div
                              style={css(
                                `background:#fff;border:2px solid ${S(v.numBd)};border-radius:16px;padding:14px 16px;transition:border-color .2s`,
                              )}
                            >
                              <div
                                style={{
                                  fontSize: '11px',
                                  fontWeight: '700',
                                  letterSpacing: '.06em',
                                  textTransform: 'uppercase',
                                  color: 'hsl(0 0% 46%)',
                                  marginBottom: '6px',
                                }}
                              >
                                {'Sua resposta'}
                              </div>
                              <input
                                value={D(v.numVal, '')}
                                onChange={v.onNum}
                                onKeyDown={v.onNumKey}
                                inputMode="decimal"
                                placeholder="Digite o valor"
                                style={{
                                  width: '100%',
                                  border: 'none',
                                  fontSize: '28px',
                                  fontWeight: '800',
                                  letterSpacing: '-.02em',
                                  padding: '0',
                                  background: 'transparent',
                                  color: 'hsl(0 0% 13%)',
                                }}
                              />
                            </div>
                            {'\n          '}
                            <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginTop: '8px' }}>
                              {'Vale só o número: formato livre (ex.: 20h12, 12,50, 30%).'}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isOrder ? (
                          <>
                            {'\n          '}
                            <div
                              style={{
                                fontSize: '12px',
                                color: 'hsl(0 0% 46%)',
                                marginBottom: '10px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '6px',
                              }}
                            >
                              <lu-icon name="grip-vertical" size="14" />
                              {'Arraste os blocos para a ordem certa'}
                            </div>
                            {'\n          '}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                              {'\n            '}
                              {L(v.ordItems).map((o, $i50) => (
                                <Fragment key={$i50}>
                                  {'\n              '}
                                  <div
                                    onPointerDown={o?.onDown}
                                    onPointerMove={o?.onMove}
                                    onPointerUp={o?.onUp}
                                    onPointerCancel={o?.onUp}
                                    style={css(
                                      `position:relative;z-index:${S(o?.z)};height:56px;display:flex;align-items:center;gap:10px;padding:0 12px;border-radius:12px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};box-shadow:${S(o?.shadow)};transform:${S(o?.tf)};transition:${S(o?.trans)};touch-action:none;user-select:none;cursor:grab`,
                                    )}
                                  >
                                    {'\n                '}
                                    <span
                                      style={css(
                                        `width:26px;height:26px;border-radius:8px;background:${S(o?.nbg)};color:${S(o?.nfg)};display:grid;place-items:center;font-size:12px;font-weight:800;flex:none`,
                                      )}
                                    >
                                      {T(o?.num)}
                                    </span>
                                    {'\n                '}
                                    <span
                                      style={{
                                        flex: '1',
                                        fontSize: '13.5px',
                                        fontWeight: '600',
                                        lineHeight: '1.3',
                                        overflow: 'hidden',
                                        display: '-webkit-box',
                                        WebkitLineClamp: '2',
                                        WebkitBoxOrient: 'vertical',
                                      }}
                                    >
                                      {T(o?.text)}
                                    </span>
                                    {'\n                '}
                                    <span style={{ color: 'hsl(0 0% 70%)', display: 'grid' }}>
                                      <lu-icon name="grip-vertical" size="18" />
                                    </span>
                                    {'\n              '}
                                  </div>
                                  {'\n            '}
                                </Fragment>
                              ))}
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isPairs ? (
                          <>
                            {'\n          '}
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', alignItems: 'start' }}>
                              {'\n            '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                {L(v.pairL).map((o, $i51) => (
                                  <Fragment key={$i51}>
                                    <button
                                      onClick={o?.onClick}
                                      style={css(
                                        `min-height:60px;padding:10px 12px;border-radius:12px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:13px;font-weight:600;line-height:1.3;cursor:pointer;box-shadow:0 3px 0 hsl(0 0% 88%);transform:${S(o?.tr)};animation:${S(o?.anim)};pointer-events:${S(o?.pe)};transition:transform .15s, border-color .15s, background .15s`,
                                      )}
                                    >
                                      {T(o?.text)}
                                    </button>
                                  </Fragment>
                                ))}
                              </div>
                              {'\n            '}
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                {L(v.pairR).map((o, $i52) => (
                                  <Fragment key={$i52}>
                                    <button
                                      onClick={o?.onClick}
                                      style={css(
                                        `min-height:60px;padding:10px 12px;border-radius:12px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:13px;font-weight:600;line-height:1.3;cursor:pointer;box-shadow:0 3px 0 hsl(0 0% 88%);transform:${S(o?.tr)};animation:${S(o?.anim)};pointer-events:${S(o?.pe)};transition:transform .15s, border-color .15s, background .15s`,
                                      )}
                                    >
                                      {T(o?.text)}
                                    </button>
                                  </Fragment>
                                ))}
                              </div>
                              {'\n          '}
                            </div>
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.isOnde ? (
                          <>
                            {'\n          '}
                            <div
                              style={{
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '16px',
                                overflow: 'hidden',
                                boxShadow: '0 1px 4px rgba(0,0,0,.08)',
                              }}
                            >
                              {'\n            '}
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                  padding: '8px 10px',
                                  background: 'hsl(0 0% 98.5%)',
                                  borderBottom: '1px solid hsl(0 0% 93%)',
                                  minHeight: '52px',
                                }}
                              >
                                {'\n              '}
                                {v.ondeCanBack ? (
                                  <>
                                    <button
                                      onClick={v.onOndeBack}
                                      aria-label="Voltar no menu"
                                      style={{
                                        width: '36px',
                                        height: '36px',
                                        borderRadius: '8px',
                                        border: '1px solid hsl(0 0% 90%)',
                                        background: '#fff',
                                        color: 'hsl(0 0% 46%)',
                                        display: 'grid',
                                        placeItems: 'center',
                                        cursor: 'pointer',
                                        flex: 'none',
                                      }}
                                    >
                                      <lu-icon name="chevron-left" size="16" />
                                    </button>
                                  </>
                                ) : null}
                                {'\n              '}
                                <span style={{ fontSize: '12px', fontWeight: '600', color: 'hsl(0 0% 46%)', lineHeight: '1.35' }}>
                                  {T(v.ondeCrumb)}
                                </span>
                                {'\n            '}
                              </div>
                              {'\n            '}
                              {L(v.ondeRows).map((o, $i53) => (
                                <Fragment key={$i53}>
                                  {'\n              '}
                                  <button
                                    onClick={o?.onClick}
                                    style={css(
                                      `width:100%;min-height:52px;display:flex;align-items:center;gap:10px;padding:10px 14px;border:none;border-bottom:1px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:14px;font-weight:600;text-align:left;cursor:pointer;line-height:1.3`,
                                    )}
                                  >
                                    {'\n                '}
                                    <span style={{ flex: '1' }}>{T(o?.label)}</span>
                                    {'\n                '}
                                    {o?.kids ? (
                                      <>
                                        <lu-icon name="chevron-right" size="17" />
                                      </>
                                    ) : null}
                                    {'\n                '}
                                    {o?.sel ? (
                                      <>
                                        <lu-icon name="circle-check" size="18" />
                                      </>
                                    ) : null}
                                    {'\n              '}
                                  </button>
                                  {'\n            '}
                                </Fragment>
                              ))}
                              {'\n          '}
                            </div>
                            {'\n          '}
                            {v.hasOndeSel ? (
                              <>
                                <div
                                  style={{
                                    marginTop: '10px',
                                    fontSize: '12.5px',
                                    color: 'hsl(6 91% 47%)',
                                    fontWeight: '600',
                                    display: 'flex',
                                    gap: '6px',
                                    alignItems: 'flex-start',
                                  }}
                                >
                                  <lu-icon name="map-pin" size="14" />
                                  <span>{T(v.ondeSel)}</span>
                                </div>
                              </>
                            ) : null}
                            {'\n        '}
                          </>
                        ) : null}
                        {'\n        '}
                        {v.pairsHint ? (
                          <>
                            <div style={{ marginTop: '16px', fontSize: '12px', color: 'hsl(0 0% 46%)', textAlign: 'center' }}>
                              {'Toque em um item de cada coluna · '}
                              {T(v.pairMist)}
                            </div>
                          </>
                        ) : null}
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n  '}
                </div>
                {'\n  '}
                {v.isTip ? (
                  <>
                    <div
                      style={{
                        position: 'absolute',
                        left: '0',
                        right: '0',
                        bottom: '0',
                        padding: '12px 20px calc(18px + env(safe-area-inset-bottom))',
                        background: '#fff',
                        borderTop: '1px solid hsl(0 0% 93%)',
                      }}
                    >
                      <button
                        onClick={v.onTipGo}
                        style={{
                          width: '100%',
                          height: '54px',
                          border: 'none',
                          borderRadius: '12px',
                          background: 'hsl(6 91% 47%)',
                          color: '#fff',
                          fontSize: '15px',
                          fontWeight: '700',
                          cursor: 'pointer',
                          boxShadow: '0 4px 0 hsl(6 100% 34%)',
                          transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                        }}
                        className="scp0"
                      >
                        {'Entendi, vamos lá'}
                      </button>
                    </div>
                  </>
                ) : null}
                {'\n  '}
                {v.showCheck ? (
                  <>
                    <div
                      style={{
                        position: 'absolute',
                        left: '0',
                        right: '0',
                        bottom: '0',
                        padding: '12px 20px calc(18px + env(safe-area-inset-bottom))',
                        background: '#fff',
                        borderTop: '1px solid hsl(0 0% 93%)',
                      }}
                    >
                      <button
                        onClick={v.onCheck}
                        disabled={v.checkDisabled}
                        style={css(
                          `width:100%;height:54px;border:none;border-radius:12px;background:${S(v.checkBg)};color:${S(v.checkFg)};font-size:15px;font-weight:700;cursor:pointer;box-shadow:${S(v.checkSh)};transition:background .2s, color .2s, transform .25s cubic-bezier(.34,1.56,.64,1)`,
                        )}
                        className="scp0"
                      >
                        {'Verificar'}
                      </button>
                    </div>
                  </>
                ) : null}
                {'\n  '}
                {v.fbOpen ? (
                  <>
                    {'\n    '}
                    <div
                      style={css(
                        `position:absolute;left:0;right:0;bottom:0;z-index:5;padding:18px 20px calc(18px + env(safe-area-inset-bottom));background:${S(v.fbBg)};border-top:1px solid hsl(0 0% 90%);border-radius:20px 20px 0 0;box-shadow:0 -10px 30px rgba(0,0,0,.08);animation:sheetUp .32s cubic-bezier(.16,1,.3,1) both`,
                      )}
                    >
                      {'\n      '}
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '14px' }}>
                        {'\n        '}
                        <span
                          style={css(
                            `width:44px;height:44px;border-radius:999px;background:#fff;color:${S(v.fbFg)};display:grid;place-items:center;flex:none;box-shadow:0 2px 6px rgba(0,0,0,.08)`,
                          )}
                        >
                          {v.fbOk ? (
                            <>
                              <lu-icon name="circle-check" size="28" stroke="2.4" draw="" />
                            </>
                          ) : null}
                          {v.fbBad ? (
                            <>
                              <lu-icon name="circle-x" size="28" stroke="2.4" />
                            </>
                          ) : null}
                        </span>
                        {'\n        '}
                        <div style={{ flex: '1', minWidth: '0' }}>
                          <div style={css(`font-size:18px;font-weight:800;color:${S(v.fbFg)}`)}>{T(v.fbTitle)}</div>
                          {v.fbBad ? (
                            <>
                              <div
                                style={{
                                  fontSize: '14px',
                                  fontWeight: '600',
                                  color: 'hsl(0 0% 20%)',
                                  lineHeight: '1.45',
                                  marginTop: '4px',
                                  whiteSpace: 'pre-line',
                                }}
                              >
                                {T(v.fbCorrect)}
                              </div>
                            </>
                          ) : null}
                          {v.fbRequeue ? (
                            <>
                              <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginTop: '6px' }}>
                                {'Sem problema: essa questão volta no fim da lição.'}
                              </div>
                            </>
                          ) : null}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n      '}
                      <div style={{ display: 'flex', gap: '10px' }}>
                        {'\n        '}
                        <button
                          onClick={v.onWhy}
                          style={{
                            height: '52px',
                            padding: '0 16px',
                            borderRadius: '12px',
                            border: '1px solid hsl(6 91% 47% / .35)',
                            background: '#fff',
                            color: 'hsl(6 91% 47%)',
                            fontSize: '14px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            flex: 'none',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          <hubia-orb size="18" />
                          {'Por quê?'}
                        </button>
                        {'\n        '}
                        <button
                          onClick={v.onNext}
                          style={css(
                            `flex:1;height:52px;border:none;border-radius:12px;background:${S(v.fbBtn)};color:#fff;font-size:15px;font-weight:700;cursor:pointer;box-shadow:${S(v.fbBtnSh)};transition:transform .25s cubic-bezier(.34,1.56,.64,1)`,
                          )}
                          className="scp0"
                        >
                          {'Continuar'}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.whyOpen ? (
                  <>
                    {'\n    '}
                    <div
                      onClick={v.onWhyClose}
                      style={{
                        position: 'absolute',
                        inset: '0',
                        zIndex: '8',
                        background: 'rgba(0,0,0,.45)',
                        display: 'flex',
                        alignItems: 'flex-end',
                        animation: 'fadeIn .2s both',
                      }}
                    >
                      {'\n      '}
                      <div
                        onClick={v.stopProp}
                        style={{
                          width: '100%',
                          maxHeight: '85%',
                          overflowY: 'auto',
                          background: '#fff',
                          borderRadius: '20px 20px 0 0',
                          padding: '10px 18px calc(20px + env(safe-area-inset-bottom))',
                          animation: 'sheetUp .35s cubic-bezier(.16,1,.3,1) both',
                        }}
                      >
                        {'\n        '}
                        <div
                          style={{
                            width: '48px',
                            height: '6px',
                            borderRadius: '999px',
                            background: 'hsl(0 0% 90%)',
                            margin: '0 auto 14px',
                          }}
                        />
                        {'\n        '}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
                          <span
                            style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '12px',
                              background: 'hsl(6 91% 47% / .10)',
                              display: 'grid',
                              placeItems: 'center',
                            }}
                          >
                            <hubia-orb size="26" animate="" />
                          </span>
                          <div>
                            <div style={{ fontSize: '15px', fontWeight: '700' }}>{'Hubia'}</div>
                            <div style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', whiteSpace: 'nowrap' }}>
                              {'Assistente do TakeatHub'}
                            </div>
                          </div>
                        </div>
                        {'\n        '}
                        <div
                          style={{
                            background: 'hsl(0 0% 95%)',
                            borderRadius: '4px 14px 14px 14px',
                            padding: '13px 15px',
                            fontSize: '14px',
                            lineHeight: '1.55',
                            marginBottom: '12px',
                          }}
                        >
                          {T(v.whyText)}
                        </div>
                        {'\n        '}
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px',
                            padding: '12px',
                            borderRadius: '12px',
                            border: '1px solid hsl(0 0% 90%)',
                          }}
                        >
                          <span
                            style={{
                              width: '32px',
                              height: '32px',
                              borderRadius: '9px',
                              background: 'hsl(6 91% 47% / .12)',
                              color: 'hsl(6 91% 47%)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name="book-text" size="16" />
                          </span>
                          <div style={{ minWidth: '0' }}>
                            <div
                              style={{
                                fontSize: '11px',
                                fontWeight: '700',
                                letterSpacing: '.06em',
                                textTransform: 'uppercase',
                                color: 'hsl(0 0% 62%)',
                              }}
                            >
                              {'Fonte'}
                            </div>
                            <div style={{ fontSize: '12.5px', fontWeight: '600', wordBreak: 'break-word' }}>{T(v.whyFonte)}</div>
                          </div>
                        </div>
                        {'\n        '}
                        <div style={{ fontSize: '11px', color: 'hsl(0 0% 62%)', margin: '12px 0 14px', textAlign: 'center' }}>
                          {'A Hubia pode errar. Confira o que for importante.'}
                        </div>
                        {'\n        '}
                        <button
                          onClick={v.onWhyClose}
                          style={{
                            width: '100%',
                            height: '50px',
                            border: 'none',
                            borderRadius: '12px',
                            background: 'hsl(6 91% 47%)',
                            color: '#fff',
                            fontSize: '15px',
                            fontWeight: '700',
                            cursor: 'pointer',
                          }}
                        >
                          {'Entendi'}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
              </div>
            </>
          ) : null}
          {v.isEnd ? (
            <>
              <div
                style={{
                  flex: '1',
                  minHeight: '0',
                  position: 'relative',
                  overflowY: 'auto',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  padding: '30px 22px 24px',
                  animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                }}
              >
                {'\n  '}
                {T(v.particlesEl)}
                {'\n  '}
                <div
                  style={css(
                    `position:relative;width:96px;height:96px;border-radius:28px;background:${S(v.endIconBg)};color:#fff;display:grid;place-items:center;box-shadow:0 14px 30px rgba(255,138,61,.35);animation:popIn .6s cubic-bezier(.34,1.56,.64,1) both`,
                  )}
                >
                  <lu-icon name={v.endIcon} size="46" stroke="2" />
                </div>
                {'\n  '}
                <h1
                  style={{
                    position: 'relative',
                    margin: '22px 0 6px',
                    fontSize: '26px',
                    fontWeight: '800',
                    letterSpacing: '-.02em',
                    textAlign: 'center',
                    animation: 'rise .5s .1s both',
                  }}
                >
                  {T(v.endTitle)}
                </h1>
                {'\n  '}
                <p
                  style={{
                    position: 'relative',
                    margin: '0 0 22px',
                    fontSize: '14px',
                    color: 'hsl(0 0% 46%)',
                    textAlign: 'center',
                    maxWidth: '32ch',
                    animation: 'rise .5s .15s both',
                  }}
                >
                  {T(v.endSub)}
                </p>
                {'\n  '}
                <div style={{ position: 'relative', width: '100%', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px' }}>
                  {'\n    '}
                  {L(v.endStats).map((k, $i54) => (
                    <Fragment key={$i54}>
                      {'\n      '}
                      <div
                        ref={k?.ref}
                        style={css(
                          `background:#fff;border:1px solid hsl(0 0% 90%);border-radius:15px;padding:12px 10px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.05);animation:rise .45s ${S(k?.d)} cubic-bezier(.16,1,.3,1) both`,
                        )}
                      >
                        <span
                          style={css(
                            `width:32px;height:32px;border-radius:10px;background:${S(k?.bg)};color:${S(k?.fg)};display:grid;place-items:center;margin:0 auto 8px`,
                          )}
                        >
                          <lu-icon name={k?.icon} size="16" />
                        </span>
                        <div style={{ fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em', fontVariantNumeric: 'tabular-nums' }}>
                          {T(k?.val)}
                        </div>
                        <div style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', fontWeight: '500' }}>{T(k?.label)}</div>
                      </div>
                      {'\n    '}
                    </Fragment>
                  ))}
                  {'\n  '}
                </div>
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    display: 'flex',
                    gap: '8px',
                    flexWrap: 'wrap',
                    justifyContent: 'center',
                    marginTop: '14px',
                  }}
                >
                  {'\n    '}
                  {v.endPerfect ? (
                    <>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '12px',
                          fontWeight: '700',
                          padding: '6px 12px',
                          borderRadius: '999px',
                          background: 'hsl(40 92% 46% / .15)',
                          color: 'hsl(32 82% 40%)',
                          animation: 'popIn .4s .45s both',
                        }}
                      >
                        <lu-icon name="sparkles" size="14" />
                        {'Lição perfeita +5 XP'}
                      </span>
                    </>
                  ) : null}
                  {'\n    '}
                  {v.endCombo ? (
                    <>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '12px',
                          fontWeight: '700',
                          padding: '6px 12px',
                          borderRadius: '999px',
                          background: 'hsl(6 91% 47% / .12)',
                          color: 'hsl(6 91% 47%)',
                          animation: 'popIn .4s .52s both',
                        }}
                      >
                        <lu-icon name="flame" size="14" />
                        {T(v.endComboT)}
                      </span>
                    </>
                  ) : null}
                  {'\n  '}
                </div>
                {'\n  '}
                <div style={{ flex: '1', minHeight: '20px' }} />
                {'\n  '}
                <button
                  onClick={v.onEndNext}
                  style={{
                    position: 'relative',
                    width: '100%',
                    height: '54px',
                    border: 'none',
                    borderRadius: '12px',
                    background: 'hsl(6 91% 47%)',
                    color: '#fff',
                    fontSize: '15px',
                    fontWeight: '700',
                    cursor: 'pointer',
                    boxShadow: '0 4px 0 hsl(6 100% 34%)',
                    transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                    animation: 'rise .4s .5s both',
                  }}
                  className="scp0"
                >
                  {'Continuar'}
                </button>
                {'\n  '}
                <button
                  onClick={v.onEndReport}
                  style={{
                    position: 'relative',
                    marginTop: '8px',
                    minHeight: '44px',
                    padding: '0 12px',
                    border: 'none',
                    background: 'none',
                    color: 'hsl(0 0% 46%)',
                    fontSize: '13px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    animation: 'rise .4s .6s both',
                  }}
                >
                  <lu-icon name="message-square-warning" size="15" />
                  {'Enviar feedback desta fase'}
                </button>
              </div>
            </>
          ) : null}
          {v.isPost ? (
            <>
              <div
                style={{
                  flex: '1',
                  minHeight: '0',
                  overflowY: 'auto',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  padding: '34px 22px 24px',
                  animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                }}
              >
                {'\n  '}
                {v.postStreak ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        color: 'hsl(28 90% 52%)',
                        animation: 'flameGrow .7s cubic-bezier(.34,1.56,.64,1) both',
                        filter: 'drop-shadow(0 12px 24px hsl(28 90% 52% / .4))',
                      }}
                    >
                      <lu-icon name="flame" size="120" stroke="1.6" fill="hsl(40 92% 56%)" />
                    </div>
                    {'\n    '}
                    <div
                      style={{
                        fontSize: '64px',
                        fontWeight: '800',
                        lineHeight: '72px',
                        letterSpacing: '-.03em',
                        color: 'hsl(28 90% 48%)',
                        marginTop: '6px',
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    >
                      {T(v.rollEl)}
                    </div>
                    {'\n    '}
                    <h1 style={{ margin: '4px 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em', textAlign: 'center' }}>
                      {T(v.streakTitle)}
                    </h1>
                    {'\n    '}
                    <p style={{ margin: '0 0 22px', fontSize: '14px', color: 'hsl(0 0% 46%)', textAlign: 'center' }}>{T(v.streakSub)}</p>
                    {'\n    '}
                    <div
                      style={{
                        width: '100%',
                        background: '#fff',
                        border: '1px solid hsl(0 0% 90%)',
                        borderRadius: '16px',
                        padding: '16px',
                        display: 'grid',
                        gridTemplateColumns: 'repeat(7,1fr)',
                        gap: '6px',
                      }}
                    >
                      {'\n      '}
                      {L(v.week).map((d, $i55) => (
                        <Fragment key={$i55}>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)' }}>{T(d?.l)}</span>
                            <span
                              style={css(
                                `position:relative;width:34px;height:34px;border-radius:999px;border:2px solid ${S(d?.bd)};display:grid;place-items:center;color:${S(d?.fg)};overflow:hidden`,
                              )}
                            >
                              <span
                                style={css(`position:absolute;inset:0;border-radius:999px;background:${S(d?.bg)};animation:${S(d?.anim)}`)}
                              />
                              {d?.on ? (
                                <>
                                  <span style={{ position: 'relative', display: 'grid' }}>
                                    <lu-icon name="check" size="16" stroke="3" />
                                  </span>
                                </>
                              ) : null}
                            </span>
                          </div>
                        </Fragment>
                      ))}
                      {'\n    '}
                    </div>
                    {'\n    '}
                    {v.hasMilestone ? (
                      <>
                        <div
                          style={{
                            marginTop: '14px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            padding: '10px 14px',
                            borderRadius: '12px',
                            background: 'hsl(40 92% 46% / .15)',
                            color: 'hsl(32 82% 36%)',
                            fontSize: '13px',
                            fontWeight: '700',
                          }}
                        >
                          <img src="assets/academy-book.png" width="20" height="20" alt="" />
                          {T(v.milestoneT)}
                        </div>
                      </>
                    ) : null}
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.postGoal ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        position: 'relative',
                        width: '150px',
                        height: '150px',
                        animation: 'popIn .6s cubic-bezier(.34,1.56,.64,1) both',
                      }}
                    >
                      <svg width="150" height="150" viewBox="0 0 36 36">
                        <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(0 0% 92%)" strokeWidth="3" />
                        <circle
                          cx="18"
                          cy="18"
                          r="15.9"
                          fill="none"
                          stroke="hsl(150 55% 40%)"
                          strokeWidth="3"
                          strokeLinecap="round"
                          pathLength="1"
                          transform="rotate(-90 18 18)"
                          style={{ strokeDasharray: '1', animation: 'drawLine .9s .2s cubic-bezier(.16,1,.3,1) both' }}
                        />
                      </svg>
                      <span style={{ position: 'absolute', inset: '0', display: 'grid', placeItems: 'center', color: 'hsl(40 92% 46%)' }}>
                        <lu-icon name="zap" size="56" fill="currentColor" />
                      </span>
                    </div>
                    {'\n    '}
                    <h1 style={{ margin: '22px 0 6px', fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em', textAlign: 'center' }}>
                      {T(v.goalT)}
                    </h1>
                    {'\n    '}
                    <p style={{ margin: '0', fontSize: '14px', color: 'hsl(0 0% 46%)', textAlign: 'center' }}>{T(v.goalS)}</p>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.postBadge ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        fontSize: '11px',
                        fontWeight: '700',
                        letterSpacing: '.09em',
                        textTransform: 'uppercase',
                        color: 'hsl(6 91% 47%)',
                        marginBottom: '16px',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {'Novo emblema'}
                    </div>
                    {'\n    '}
                    <div
                      style={{
                        position: 'relative',
                        width: '150px',
                        height: '168px',
                        animation: 'reveal3d .7s cubic-bezier(.16,1,.3,1) both',
                        filter: 'drop-shadow(0 18px 30px rgba(0,0,0,.22))',
                      }}
                    >
                      <div
                        style={css(
                          `position:absolute;inset:0;background:${S(v.bG)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%);display:grid;place-items:center;color:#fff;overflow:hidden`,
                        )}
                      >
                        <lu-icon name={v.bIcon} size="62" stroke="1.8" />
                        <span
                          style={{
                            position: 'absolute',
                            top: '0',
                            bottom: '0',
                            left: '0',
                            width: '40%',
                            background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.7),transparent)',
                            animation: 'sheen 1.2s .6s ease-in-out both',
                          }}
                        />
                      </div>
                    </div>
                    {'\n    '}
                    <h1 style={{ margin: '24px 0 6px', fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em', textAlign: 'center' }}>
                      {T(v.bNome)}
                    </h1>
                    {'\n    '}
                    <p style={{ margin: '0', fontSize: '14px', color: 'hsl(0 0% 46%)', textAlign: 'center' }}>{T(v.bSub)}</p>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.postCert ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        fontSize: '11px',
                        fontWeight: '700',
                        letterSpacing: '.09em',
                        textTransform: 'uppercase',
                        color: 'hsl(6 91% 47%)',
                        marginBottom: '16px',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {'Certificado Takeat'}
                    </div>
                    {'\n    '}
                    <div
                      style={{
                        position: 'relative',
                        width: '100%',
                        borderRadius: '18px',
                        background: '#fff',
                        border: '1px solid hsl(0 0% 90%)',
                        boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                        overflow: 'hidden',
                        animation: 'reveal3d .7s cubic-bezier(.16,1,.3,1) both',
                      }}
                    >
                      {'\n      '}
                      <div style={{ height: '8px', background: '#df1c0d' }} />
                      {'\n      '}
                      <div style={{ padding: '22px 20px 20px', position: 'relative' }}>
                        {'\n        '}
                        <div
                          style={{
                            position: 'absolute',
                            right: '14px',
                            bottom: '14px',
                            width: '70px',
                            height: '70px',
                            background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                            opacity: '.08',
                          }}
                        />
                        {'\n        '}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '18px' }}>
                          <span
                            style={{ width: '22px', height: '22px', background: 'url("assets/takeat-mark.png") center/contain no-repeat' }}
                          />
                          <span style={{ display: 'flex', flexDirection: 'column', lineHeight: '1' }}>
                            <span style={{ fontSize: '13px', fontWeight: '800' }}>{'TakeatHub'}</span>
                            <span style={{ fontFamily: "'Dancing Script',cursive", fontSize: '15px', fontWeight: '700', color: '#df1c0d' }}>
                              {'Academy'}
                            </span>
                          </span>
                        </div>
                        {'\n        '}
                        <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{'Certificamos que'}</div>
                        {'\n        '}
                        <div
                          style={{ fontSize: '24px', fontWeight: '800', letterSpacing: '-.02em', lineHeight: '1.15', margin: '4px 0 10px' }}
                        >
                          {T(v.cNome)}
                        </div>
                        {'\n        '}
                        <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{'concluiu o Desafio Mestre da trilha'}</div>
                        {'\n        '}
                        <div style={{ fontSize: '16px', fontWeight: '700', marginTop: '2px' }}>{T(v.cTrilha)}</div>
                        {'\n        '}
                        <div style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', marginTop: '16px' }}>
                          {'Emitido em '}
                          {T(v.cData)}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n      '}
                      <span
                        style={{
                          position: 'absolute',
                          top: '0',
                          bottom: '0',
                          left: '0',
                          width: '35%',
                          background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.8),transparent)',
                          animation: 'sheen 1.3s .6s ease-in-out both',
                          pointerEvents: 'none',
                        }}
                      />
                      {'\n    '}
                    </div>
                    {'\n    '}
                    <div style={{ marginTop: '16px', display: 'flex', gap: '8px', width: '100%' }}>
                      <button
                        onClick={v.onPrintCert}
                        style={{
                          flex: '1',
                          minHeight: '46px',
                          padding: '0 14px',
                          border: '1px solid hsl(6 91% 47% / .35)',
                          borderRadius: '10px',
                          background: 'hsl(6 91% 47% / .06)',
                          color: 'hsl(6 91% 47%)',
                          fontSize: '13px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '8px',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <lu-icon name="file-badge" size="16" />
                        {'Ver certificado'}
                      </button>
                      <button
                        onClick={v.onShare}
                        style={{
                          flex: '1',
                          minHeight: '46px',
                          padding: '0 14px',
                          borderRadius: '10px',
                          border: '1px solid hsl(0 0% 90%)',
                          background: '#fff',
                          fontSize: '13px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '8px',
                          color: 'hsl(0 0% 13%)',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <lu-icon name="share-2" size="16" />
                        {'Compartilhar'}
                      </button>
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                <div style={{ flex: '1', minHeight: '24px' }} />
                {'\n  '}
                <button
                  onClick={v.onPostNext}
                  style={{
                    width: '100%',
                    height: '54px',
                    border: 'none',
                    borderRadius: '12px',
                    background: 'hsl(6 91% 47%)',
                    color: '#fff',
                    fontSize: '15px',
                    fontWeight: '700',
                    cursor: 'pointer',
                    boxShadow: '0 4px 0 hsl(6 100% 34%)',
                    transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                  }}
                  className="scp0"
                >
                  {T(v.postBtn)}
                </button>
              </div>
            </>
          ) : null}
          {v.isFlash ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '50',
                  display: 'flex',
                  flexDirection: 'column',
                  background: 'hsl(0 0% 98%)',
                  animation: 'scrIn .32s cubic-bezier(.16,1,.3,1) both',
                }}
              >
                {'\n  '}
                <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px' }}>
                  {'\n    '}
                  <button
                    onClick={v.onFlashQuit}
                    aria-label="Sair"
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '12px',
                      border: 'none',
                      background: 'none',
                      color: 'hsl(0 0% 46%)',
                      display: 'grid',
                      placeItems: 'center',
                      cursor: 'pointer',
                    }}
                  >
                    <lu-icon name="x" size="24" />
                  </button>
                  {'\n    '}
                  <div style={{ flex: '1', height: '14px', borderRadius: '999px', background: 'hsl(0 0% 91%)', overflow: 'hidden' }}>
                    <div
                      style={css(
                        `height:100%;width:${S(v.flashW)};background:hsl(40 92% 46%);border-radius:999px;transition:width .5s linear`,
                      )}
                    />
                  </div>
                  {'\n    '}
                  <span
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      fontSize: '13px',
                      fontWeight: '700',
                      fontVariantNumeric: 'tabular-nums',
                      color: 'hsl(0 0% 46%)',
                    }}
                  >
                    <lu-icon name="timer" size="16" />
                    {T(v.flashLeft)}
                  </span>
                  {'\n  '}
                </div>
                {'\n  '}
                {v.flashPlaying ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        flex: '1',
                        minHeight: '0',
                        overflowY: 'auto',
                        padding: '6px 20px 28px',
                        display: 'flex',
                        flexDirection: 'column',
                      }}
                    >
                      {'\n      '}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                        <span
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '11px',
                            fontWeight: '700',
                            letterSpacing: '.08em',
                            textTransform: 'uppercase',
                            color: 'hsl(40 92% 40%)',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          <lu-icon name="timer" size="14" />
                          {'Desafio relâmpago'}
                        </span>
                        <span style={{ fontSize: '15px', fontWeight: '800', whiteSpace: 'nowrap' }}>
                          {T(v.flashScore)}
                          {' pares'}
                        </span>
                      </div>
                      {'\n      '}
                      <h2 style={{ margin: '0 0 18px', fontSize: '19px', fontWeight: '700' }}>{'Combine cada termo com o significado'}</h2>
                      {'\n      '}
                      <div style={{ flex: '1', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', alignContent: 'center' }}>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                          {L(v.flL).map((o, $i56) => (
                            <Fragment key={$i56}>
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `flex:1;min-height:96px;max-height:132px;padding:12px 14px;border-radius:14px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:17px;font-weight:700;cursor:pointer;box-shadow:0 3px 0 hsl(0 0% 88%);animation:${S(o?.anim)};pointer-events:${S(o?.pe)}`,
                                )}
                              >
                                {T(o?.text)}
                              </button>
                            </Fragment>
                          ))}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                          {L(v.flR).map((o, $i57) => (
                            <Fragment key={$i57}>
                              <button
                                onClick={o?.onClick}
                                style={css(
                                  `flex:1;min-height:96px;max-height:132px;padding:12px 14px;border-radius:14px;border:2px solid ${S(o?.bd)};background:${S(o?.bg)};color:${S(o?.fg)};font-size:14px;font-weight:600;line-height:1.3;cursor:pointer;box-shadow:0 3px 0 hsl(0 0% 88%);animation:${S(o?.anim)};pointer-events:${S(o?.pe)}`,
                                )}
                              >
                                {T(o?.text)}
                              </button>
                            </Fragment>
                          ))}
                        </div>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
                {'\n  '}
                {v.flashDone ? (
                  <>
                    {'\n    '}
                    <div
                      style={{
                        flex: '1',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        padding: '30px 22px 24px',
                        animation: 'up8 .3s both',
                      }}
                    >
                      {'\n      '}
                      <div
                        style={{
                          width: '96px',
                          height: '96px',
                          borderRadius: '28px',
                          background: 'linear-gradient(145deg,#FFD66B,#FF8A3D)',
                          color: '#fff',
                          display: 'grid',
                          placeItems: 'center',
                          animation: 'popIn .6s cubic-bezier(.34,1.56,.64,1) both',
                        }}
                      >
                        <lu-icon name="timer" size="46" />
                      </div>
                      {'\n      '}
                      <h1 style={{ margin: '22px 0 6px', fontSize: '26px', fontWeight: '800' }}>
                        {T(v.flashScore)}
                        {' pares em 60 s'}
                      </h1>
                      {'\n      '}
                      {v.flashRec ? (
                        <>
                          <span
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '6px',
                              fontSize: '12px',
                              fontWeight: '700',
                              padding: '6px 12px',
                              borderRadius: '999px',
                              background: 'hsl(40 92% 46% / .15)',
                              color: 'hsl(32 82% 40%)',
                              marginBottom: '6px',
                            }}
                          >
                            <lu-icon name="sparkles" size="14" />
                            {'Novo recorde!'}
                          </span>
                        </>
                      ) : null}
                      {'\n      '}
                      <p style={{ margin: '0', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                        {T(v.flashRecT)}
                        {' · '}
                        {T(v.flashXp)}
                      </p>
                      {'\n      '}
                      <div style={{ flex: '1' }} />
                      {'\n      '}
                      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        {'\n        '}
                        <button
                          onClick={v.onFlashAgain}
                          style={{
                            width: '100%',
                            height: '54px',
                            border: 'none',
                            borderRadius: '12px',
                            background: 'hsl(6 91% 47%)',
                            color: '#fff',
                            fontSize: '15px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            boxShadow: '0 4px 0 hsl(6 100% 34%)',
                          }}
                          className="scp0"
                        >
                          {'Jogar de novo'}
                        </button>
                        {'\n        '}
                        <button
                          onClick={v.onFlashExit}
                          style={{
                            width: '100%',
                            height: '50px',
                            borderRadius: '12px',
                            border: '1px solid hsl(0 0% 90%)',
                            background: '#fff',
                            fontSize: '14px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            color: 'hsl(0 0% 13%)',
                          }}
                        >
                          {'Voltar para Praticar'}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </div>
                    {'\n  '}
                  </>
                ) : null}
              </div>
            </>
          ) : null}
          {v.sheetOpen ? (
            <>
              <div
                onClick={v.onSheetClose}
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '80',
                  background: 'rgba(0,0,0,.45)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  onClick={v.stopProp}
                  style={{
                    width: '100%',
                    maxHeight: '86%',
                    overflowY: 'auto',
                    background: '#fff',
                    borderRadius: '20px 20px 0 0',
                    padding: '10px 16px calc(22px + env(safe-area-inset-bottom))',
                    animation: 'sheetUp .35s cubic-bezier(.16,1,.3,1) both',
                  }}
                >
                  {'\n    '}
                  <div
                    style={{ width: '48px', height: '6px', borderRadius: '999px', background: 'hsl(0 0% 90%)', margin: '0 auto 14px' }}
                  />
                  {'\n    '}
                  {v.sheetTracks ? (
                    <>
                      {'\n      '}
                      <h3 style={{ margin: '0 0 4px', fontSize: '17px', fontWeight: '700' }}>{'Trilhas'}</h3>
                      {'\n      '}
                      <p style={{ margin: '0 0 14px', fontSize: '12.5px', color: 'hsl(0 0% 46%)' }}>
                        {'A ordem segue a sua persona. A recomendada está destacada.'}
                      </p>
                      {'\n      '}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {'\n        '}
                        {L(v.trackRows).map((t, $i58) => (
                          <Fragment key={$i58}>
                            {'\n          '}
                            <button
                              onClick={t?.onClick}
                              style={css(
                                `display:flex;align-items:center;gap:12px;padding:12px;border-radius:14px;border:1.5px solid ${S(t?.bd)};background:${S(t?.bg)};cursor:pointer;text-align:left;min-height:64px`,
                              )}
                            >
                              {'\n            '}
                              <span
                                style={{
                                  width: '40px',
                                  height: '40px',
                                  borderRadius: '12px',
                                  background: 'hsl(6 91% 47% / .12)',
                                  color: 'hsl(6 91% 47%)',
                                  display: 'grid',
                                  placeItems: 'center',
                                  flex: 'none',
                                }}
                              >
                                <lu-icon name={t?.icon} size="19" />
                              </span>
                              {'\n            '}
                              <span style={{ flex: '1', minWidth: '0' }}>
                                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                  <span
                                    style={{
                                      fontSize: '13.5px',
                                      fontWeight: '700',
                                      whiteSpace: 'nowrap',
                                      overflow: 'hidden',
                                      textOverflow: 'ellipsis',
                                    }}
                                  >
                                    {T(t?.nome)}
                                  </span>
                                  {t?.rec ? (
                                    <>
                                      <span
                                        style={{
                                          flex: 'none',
                                          fontSize: '10px',
                                          fontWeight: '700',
                                          padding: '2px 7px',
                                          borderRadius: '999px',
                                          background: 'hsl(6 91% 47%)',
                                          color: '#fff',
                                        }}
                                      >
                                        {'Recomendada'}
                                      </span>
                                    </>
                                  ) : null}
                                </span>
                                <span style={{ display: 'block', fontSize: '11.5px', color: 'hsl(0 0% 46%)' }}>{T(t?.sub)}</span>
                                <span
                                  style={{
                                    display: 'block',
                                    height: '5px',
                                    borderRadius: '999px',
                                    background: 'hsl(0 0% 93%)',
                                    marginTop: '6px',
                                    overflow: 'hidden',
                                  }}
                                >
                                  <span
                                    style={css(
                                      `display:block;height:100%;width:${S(t?.pct)};background:hsl(6 91% 47%);border-radius:999px`,
                                    )}
                                  />
                                </span>
                              </span>
                              {'\n            '}
                              <span style={{ fontSize: '12px', fontWeight: '700', color: 'hsl(0 0% 46%)', flex: 'none' }}>{T(t?.pct)}</span>
                              {'\n          '}
                            </button>
                            {'\n        '}
                          </Fragment>
                        ))}
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.sheetStreak ? (
                    <>
                      {'\n      '}
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '14px' }}>
                        <span style={{ color: 'hsl(28 90% 52%)' }}>
                          <lu-icon name="flame" size="40" fill="hsl(40 92% 56%)" />
                        </span>
                        <div>
                          <div style={{ fontSize: '22px', fontWeight: '800' }}>
                            {T(v.sCount)}
                            {' dias de ofensiva'}
                          </div>
                          <div style={{ fontSize: '12.5px', color: 'hsl(0 0% 46%)' }}>
                            {T(v.sBest)}
                            {' · hoje é '}
                            {T(v.sToday)}
                          </div>
                        </div>
                      </div>
                      {'\n      '}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: '6px', marginBottom: '14px' }}>
                        {L(v.sWeek).map((d, $i59) => (
                          <Fragment key={$i59}>
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                              <span style={{ fontSize: '11px', fontWeight: '600', color: 'hsl(0 0% 46%)' }}>{T(d?.l)}</span>
                              <span
                                style={css(
                                  `width:36px;height:36px;border-radius:999px;background:${S(d?.bg)};color:${S(d?.fg)};border:2px solid ${S(d?.bd)};display:grid;place-items:center;font-size:12px;font-weight:700`,
                                )}
                              >
                                {T(d?.n)}
                              </span>
                            </div>
                          </Fragment>
                        ))}
                      </div>
                      {'\n      '}
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          padding: '12px',
                          borderRadius: '12px',
                          background: 'hsl(190 65% 42% / .1)',
                          color: 'hsl(190 65% 30%)',
                          fontSize: '13px',
                          fontWeight: '600',
                          marginBottom: '12px',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <lu-icon name="snowflake" size="18" />
                        {T(v.sFreezes)}
                        <span style={{ fontWeight: '500', opacity: '.8' }}>{'· 1 grátis por semana'}</span>
                      </div>
                      {'\n      '}
                      <div
                        style={{
                          fontSize: '11px',
                          fontWeight: '700',
                          letterSpacing: '.08em',
                          textTransform: 'uppercase',
                          color: 'hsl(0 0% 62%)',
                          marginBottom: '8px',
                        }}
                      >
                        {'Marcos'}
                      </div>
                      {'\n      '}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '8px', marginBottom: '14px' }}>
                        {L(v.sMiles).map((m, $i60) => (
                          <Fragment key={$i60}>
                            <div
                              style={css(
                                `padding:10px 4px;border-radius:12px;background:${S(m?.bg)};color:${S(m?.fg)};text-align:center;font-size:12px;font-weight:700`,
                              )}
                            >
                              {T(m?.t)}
                            </div>
                          </Fragment>
                        ))}
                      </div>
                      {'\n      '}
                      <button
                        onClick={v.onAdvanceDay2}
                        style={{
                          width: '100%',
                          minHeight: '44px',
                          borderRadius: '10px',
                          border: '1px dashed hsl(0 0% 80%)',
                          background: 'transparent',
                          color: 'hsl(0 0% 46%)',
                          fontSize: '12.5px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '8px',
                        }}
                      >
                        <lu-icon name="calendar-plus" size="15" />
                        {'Debug · avançar dia'}
                      </button>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.sheetCoins ? (
                    <>
                      {'\n      '}
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          paddingBottom: '12px',
                          borderBottom: '1px solid hsl(0 0% 90%)',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <img src="assets/academy-book.png" width="28" height="28" alt="" />
                          <div>
                            <div style={{ fontSize: '19px', fontWeight: '700', lineHeight: '1', fontVariantNumeric: 'tabular-nums' }}>
                              {T(v.cSaldo)}
                            </div>
                            <div style={{ fontSize: '11px', color: 'hsl(0 0% 46%)' }}>{'Takitos'}</div>
                          </div>
                        </div>
                        <button
                          onClick={v.onCLoja}
                          style={{
                            minHeight: '40px',
                            padding: '0 12px',
                            borderRadius: '6px',
                            border: '1px solid hsl(0 0% 90%)',
                            background: '#fff',
                            fontSize: '13px',
                            fontWeight: '500',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            color: 'hsl(0 0% 13%)',
                          }}
                        >
                          <lu-icon name="store" size="14" />
                          {'Loja'}
                        </button>
                      </div>
                      {'\n      '}
                      <div
                        style={{
                          padding: '10px 0',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '12px',
                          fontWeight: '500',
                          color: 'hsl(0 0% 46%)',
                        }}
                      >
                        <span style={{ color: 'hsl(6 91% 47%)', display: 'grid' }}>
                          <lu-icon name="sparkles" size="14" />
                        </span>
                        {'Missões em andamento'}
                      </div>
                      {'\n      '}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '12px' }}>
                        {L(v.cMissions).map((m, $i61) => (
                          <Fragment key={$i61}>
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px' }}>
                                <span style={{ fontSize: '14px' }}>{T(m?.t)}</span>
                                <span
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '2px',
                                    fontSize: '12px',
                                    fontWeight: '600',
                                    color: '#d97706',
                                  }}
                                >
                                  {T(m?.r)}
                                  <img src="assets/academy-book.png" width="12" height="12" alt="" />
                                </span>
                              </div>
                              <div
                                style={{
                                  height: '6px',
                                  borderRadius: '999px',
                                  background: 'hsl(0 0% 93%)',
                                  marginTop: '6px',
                                  overflow: 'hidden',
                                }}
                              >
                                <div style={css(`height:100%;width:${S(m?.pct)};background:hsl(6 91% 47%);border-radius:999px`)} />
                              </div>
                              <div style={{ fontSize: '10px', color: 'hsl(0 0% 46%)', textAlign: 'right', marginTop: '2px' }}>
                                {T(m?.prog)}
                              </div>
                            </div>
                          </Fragment>
                        ))}
                      </div>
                      {'\n      '}
                      <div
                        style={{
                          borderTop: '1px solid hsl(0 0% 90%)',
                          paddingTop: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                        }}
                      >
                        <span style={{ fontSize: '11px', color: 'hsl(0 0% 46%)' }}>{T(v.cDone)}</span>
                        <button
                          onClick={v.onCAll}
                          style={{
                            minHeight: '40px',
                            padding: '0 10px',
                            border: 'none',
                            background: 'none',
                            fontSize: '12px',
                            fontWeight: '500',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                            color: 'hsl(0 0% 13%)',
                          }}
                        >
                          {'Ver tudo'}
                          <lu-icon name="arrow-right" size="14" />
                        </button>
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.sheetUnit ? (
                    <>
                      {'\n      '}
                      <h3 style={{ margin: '0 0 8px', fontSize: '18px', fontWeight: '700' }}>{T(v.uTitle)}</h3>
                      {'\n      '}
                      {v.uHasRegra ? (
                        <>
                          <div
                            style={{
                              padding: '12px 14px',
                              borderRadius: '12px',
                              background: 'hsl(6 91% 47% / .06)',
                              border: '1px solid hsl(6 91% 47% / .2)',
                              fontSize: '13.5px',
                              lineHeight: '1.5',
                              marginBottom: '12px',
                            }}
                          >
                            <b style={{ color: 'hsl(6 91% 47%)' }}>{'Regra-base:'}</b> {T(v.uRegra)}
                          </div>
                        </>
                      ) : null}
                      {'\n      '}
                      {v.uHasScore ? (
                        <>
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                              fontSize: '12.5px',
                              fontWeight: '600',
                              marginBottom: '12px',
                            }}
                          >
                            <lu-icon name="clipboard-check" size="15" />
                            {T(v.uScore)}
                            {' · faixas Alto ≥ 80, Médio ≥ 60, Baixo < 60'}
                          </div>
                        </>
                      ) : null}
                      {'\n      '}
                      <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', marginBottom: '8px' }}>{T(v.uQs)}</div>
                      {'\n      '}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        {L(v.uLicoes).map((l, $i62) => (
                          <Fragment key={$i62}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', minHeight: '36px' }}>
                              {l?.done ? (
                                <>
                                  <span style={{ color: 'hsl(150 55% 40%)', display: 'grid' }}>
                                    <lu-icon name="circle-check" size="17" />
                                  </span>
                                </>
                              ) : null}
                              <span>{T(l?.t)}</span>
                            </div>
                          </Fragment>
                        ))}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.chestOpen ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  background: 'rgba(10,4,4,.72)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '28px',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div style={{ position: 'relative', width: '220px', height: '220px', display: 'grid', placeItems: 'center' }}>
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      inset: '-30px',
                      borderRadius: '999px',
                      background: 'radial-gradient(circle,rgba(255,214,107,.75),rgba(255,138,61,.25) 45%,transparent 70%)',
                      animation: 'glow .6s 1.05s cubic-bezier(.16,1,.3,1) both',
                    }}
                  />
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      inset: '-40px',
                      borderRadius: '999px',
                      background: 'repeating-conic-gradient(rgba(255,214,107,.22) 0 10deg,transparent 10deg 24deg)',
                      animation: 'glow .6s 1.05s both, raysSpin 14s 1.05s linear infinite',
                    }}
                  />
                  {'\n    '}
                  <div style={{ position: 'relative', width: '156px', height: '132px', animation: 'chestShake .7s ease-in-out both' }}>
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        left: '8px',
                        right: '8px',
                        bottom: '-12px',
                        height: '18px',
                        borderRadius: '50%',
                        background: 'rgba(0,0,0,.45)',
                        filter: 'blur(7px)',
                      }}
                    />
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        left: '0',
                        right: '0',
                        bottom: '0',
                        height: '84px',
                        borderRadius: '8px 8px 16px 16px',
                        background: 'linear-gradient(180deg,#A85A2A,#7A3A14 55%,#552508)',
                        boxShadow: 'inset 0 -7px 0 rgba(0,0,0,.28),inset 0 3px 0 rgba(255,255,255,.14)',
                        overflow: 'hidden',
                      }}
                    >
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          inset: '0',
                          background: 'repeating-linear-gradient(90deg,rgba(0,0,0,.14) 0 2px,transparent 2px 26px)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          left: '0',
                          right: '0',
                          top: '0',
                          height: '9px',
                          background: 'linear-gradient(180deg,#FFE9A0,#F5B83B 50%,#B8741C)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          left: '0',
                          right: '0',
                          bottom: '0',
                          height: '10px',
                          background: 'linear-gradient(180deg,#F5B83B,#B8741C)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          top: '0',
                          bottom: '0',
                          left: '20px',
                          width: '14px',
                          background: 'linear-gradient(90deg,#B8741C,#FFE9A0 45%,#E3A325 70%,#9A5E14)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          top: '0',
                          bottom: '0',
                          right: '20px',
                          width: '14px',
                          background: 'linear-gradient(90deg,#B8741C,#FFE9A0 45%,#E3A325 70%,#9A5E14)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          left: '50%',
                          top: '4px',
                          width: '34px',
                          height: '40px',
                          marginLeft: '-17px',
                          borderRadius: '7px 7px 12px 12px',
                          background: 'linear-gradient(160deg,#FFF0B8,#F5B83B 45%,#B8741C)',
                          boxShadow: '0 3px 6px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.6)',
                          display: 'grid',
                          placeItems: 'center',
                        }}
                      >
                        <span style={{ width: '8px', height: '14px', borderRadius: '4px 4px 2px 2px', background: '#3d1a05' }} />
                      </div>
                      {'\n      '}
                    </div>
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        left: '12px',
                        right: '12px',
                        top: '44px',
                        height: '16px',
                        borderRadius: '50%',
                        background: 'radial-gradient(ellipse at 50% 100%,#FFF3C4,#FFD66B 45%,rgba(255,138,61,0) 75%)',
                        animation: 'glow .5s .95s both',
                        zIndex: '1',
                      }}
                    />
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        left: '-5px',
                        right: '-5px',
                        top: '0',
                        height: '58px',
                        borderRadius: '70px 70px 8px 8px / 44px 44px 8px 8px',
                        background: 'linear-gradient(180deg,#C0703A,#8A4418 60%,#6A300C)',
                        boxShadow: 'inset 0 5px 0 rgba(255,255,255,.18),inset 0 -5px 0 rgba(0,0,0,.25)',
                        transformOrigin: '12% 100%',
                        animation: 'lidOpen .55s .75s cubic-bezier(.34,1.56,.64,1) both',
                        zIndex: '2',
                        overflow: 'hidden',
                      }}
                    >
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          inset: '0',
                          background: 'repeating-linear-gradient(90deg,rgba(0,0,0,.12) 0 2px,transparent 2px 26px)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          top: '0',
                          bottom: '0',
                          left: '25px',
                          width: '14px',
                          background: 'linear-gradient(90deg,#B8741C,#FFE9A0 45%,#E3A325 70%,#9A5E14)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          top: '0',
                          bottom: '0',
                          right: '25px',
                          width: '14px',
                          background: 'linear-gradient(90deg,#B8741C,#FFE9A0 45%,#E3A325 70%,#9A5E14)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          left: '0',
                          right: '0',
                          bottom: '0',
                          height: '10px',
                          background: 'linear-gradient(180deg,#FFE9A0,#F5B83B 50%,#B8741C)',
                        }}
                      />
                      {'\n        '}
                      <div
                        style={{
                          position: 'absolute',
                          left: '18%',
                          top: '8px',
                          width: '40%',
                          height: '10px',
                          borderRadius: '999px',
                          background: 'rgba(255,255,255,.2)',
                          filter: 'blur(2px)',
                        }}
                      />
                      {'\n      '}
                    </div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div
                    style={{
                      position: 'absolute',
                      top: '6px',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      animation: 'rewardRise .55s 1.05s cubic-bezier(.34,1.56,.64,1) both',
                      zIndex: '3',
                    }}
                  >
                    {'\n      '}
                    {v.chestCoin ? (
                      <>
                        <img
                          src="assets/academy-book.png"
                          width="70"
                          height="70"
                          alt=""
                          style={{ filter: 'drop-shadow(0 8px 16px rgba(0,0,0,.35))' }}
                        />
                      </>
                    ) : null}
                    {'\n      '}
                    {v.chestNotCoin ? (
                      <>
                        <span
                          style={{
                            width: '70px',
                            height: '70px',
                            borderRadius: '20px',
                            background: '#fff',
                            color: 'hsl(40 92% 46%)',
                            display: 'grid',
                            placeItems: 'center',
                            boxShadow: '0 8px 16px rgba(0,0,0,.35)',
                          }}
                        >
                          <lu-icon name={v.chestIcon} size="36" />
                        </span>
                      </>
                    ) : null}
                    {'\n    '}
                  </div>
                  {'\n  '}
                </div>
                {'\n  '}
                <div style={{ textAlign: 'center', color: '#fff', marginTop: '22px', animation: 'rise .4s 1.2s both' }}>
                  <div style={{ fontSize: '24px', fontWeight: '800', whiteSpace: 'nowrap' }}>{T(v.chestTitle)}</div>
                  <div style={{ fontSize: '13.5px', opacity: '.8', marginTop: '4px' }}>{T(v.chestSub)}</div>
                </div>
                {'\n  '}
                <button
                  onClick={v.onCollect}
                  style={{
                    marginTop: '26px',
                    width: '100%',
                    maxWidth: '300px',
                    height: '54px',
                    border: 'none',
                    borderRadius: '12px',
                    background: 'linear-gradient(145deg,#FFD66B,#FF8A3D)',
                    color: '#fff',
                    fontSize: '15px',
                    fontWeight: '800',
                    cursor: 'pointer',
                    boxShadow: '0 4px 0 hsl(28 80% 38%)',
                    animation: 'rise .4s 1.3s both',
                  }}
                  className="scp0"
                >
                  {'Coletar'}
                </button>
              </div>
            </>
          ) : null}
          {v.repOpen ? (
            <>
              <div
                onClick={v.onRepClose}
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '97',
                  background: 'rgba(0,0,0,.45)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  onClick={v.stopProp}
                  style={{
                    width: '100%',
                    maxHeight: '92%',
                    display: 'flex',
                    flexDirection: 'column',
                    background: '#fff',
                    borderRadius: '20px 20px 0 0',
                    animation: 'sheetUp .35s cubic-bezier(.16,1,.3,1) both',
                  }}
                >
                  {'\n    '}
                  <div style={{ flex: 'none', padding: '10px 16px 0' }}>
                    <div
                      style={{ width: '48px', height: '6px', borderRadius: '999px', background: 'hsl(0 0% 90%)', margin: '0 auto 12px' }}
                    />
                  </div>
                  {'\n    '}
                  {v.repForm ? (
                    <>
                      {'\n      '}
                      <div
                        style={{
                          flex: '1',
                          minHeight: '0',
                          overflowY: 'auto',
                          padding: '0 16px 12px',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '14px',
                        }}
                      >
                        {'\n        '}
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                          <h3 style={{ margin: '0', fontSize: '18px', fontWeight: '700', whiteSpace: 'nowrap' }}>{'Enviar feedback'}</h3>
                          <button
                            onClick={v.onRepClose}
                            aria-label="Fechar"
                            style={{
                              width: '36px',
                              height: '36px',
                              borderRadius: '9px',
                              border: '1px solid hsl(0 0% 90%)',
                              background: '#fff',
                              color: 'hsl(0 0% 46%)',
                              display: 'grid',
                              placeItems: 'center',
                              cursor: 'pointer',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name="x" size="16" />
                          </button>
                        </div>
                        {'\n        '}
                        <div
                          style={{
                            display: 'flex',
                            gap: '10px',
                            alignItems: 'flex-start',
                            padding: '10px 12px',
                            borderRadius: '12px',
                            background: 'hsl(0 0% 97%)',
                            border: '1px solid hsl(0 0% 92%)',
                          }}
                        >
                          {'\n          '}
                          <span
                            style={{
                              width: '30px',
                              height: '30px',
                              borderRadius: '9px',
                              background: 'hsl(6 91% 47% / .12)',
                              color: 'hsl(6 91% 47%)',
                              display: 'grid',
                              placeItems: 'center',
                              flex: 'none',
                            }}
                          >
                            <lu-icon name={v.repCtxIcon} size="15" />
                          </span>
                          {'\n          '}
                          <div style={{ minWidth: '0', flex: '1' }}>
                            <div style={{ fontSize: '11.5px', fontWeight: '700', color: 'hsl(6 91% 47%)' }}>{T(v.repCtxLabel)}</div>
                            {v.repHasCtxTitle ? (
                              <>
                                <div
                                  style={{
                                    fontSize: '12.5px',
                                    lineHeight: '1.45',
                                    color: 'hsl(0 0% 25%)',
                                    marginTop: '2px',
                                    overflow: 'hidden',
                                    display: '-webkit-box',
                                    WebkitLineClamp: '2',
                                    WebkitBoxOrient: 'vertical',
                                  }}
                                >
                                  {T(v.repCtxTitle)}
                                </div>
                              </>
                            ) : null}
                          </div>
                          {'\n        '}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                          {L(v.repCats).map((c, $i63) => (
                            <Fragment key={$i63}>
                              <button
                                onClick={c?.onClick}
                                style={css(
                                  `min-height:44px;padding:0 12px;border-radius:10px;border:1.5px solid ${S(c?.bd)};background:${S(c?.bg2)};color:${S(c?.fg2)};font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:8px;white-space:nowrap;text-align:left;transition:all .15s`,
                                )}
                              >
                                <lu-icon name={c?.icon} size="15" />
                                {T(c?.t)}
                              </button>
                            </Fragment>
                          ))}
                        </div>
                        {'\n        '}
                        <div>
                          {'\n          '}
                          <textarea
                            value={D(v.repText, '')}
                            onChange={v.onRepText}
                            rows="6"
                            placeholder="Conte o que aconteceu ou o que pode melhorar. Escreva o quanto precisar."
                            style={{
                              width: '100%',
                              minHeight: '140px',
                              borderRadius: '12px',
                              border: '1.5px solid hsl(0 0% 90%)',
                              padding: '12px 14px',
                              fontSize: '14px',
                              lineHeight: '1.55',
                              resize: 'vertical',
                              background: '#fff',
                              color: 'hsl(0 0% 13%)',
                            }}
                          />
                          {'\n        '}
                        </div>
                        {'\n        '}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          {'\n          '}
                          <input type="file" multiple="" ref={v.repFileRef} onChange={v.onRepFiles} style={{ display: 'none' }} />
                          {'\n          '}
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                            <button
                              onClick={v.onRepPick}
                              style={{
                                minHeight: '42px',
                                padding: '0 14px',
                                borderRadius: '10px',
                                border: '1px dashed hsl(0 0% 78%)',
                                background: '#fff',
                                color: 'hsl(0 0% 13%)',
                                fontSize: '13px',
                                fontWeight: '600',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              <lu-icon name="paperclip" size="15" />
                              {'Adicionar anexo'}
                            </button>
                            <span
                              style={{ fontSize: '11px', color: 'hsl(0 0% 62%)', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}
                            >
                              {T(v.repCount)}
                            </span>
                          </div>
                          {'\n          '}
                          {v.repHasFiles ? (
                            <>
                              {'\n            '}
                              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '8px' }}>
                                {'\n              '}
                                {L(v.repFiles).map((a, $i64) => (
                                  <Fragment key={$i64}>
                                    {'\n                '}
                                    <div
                                      style={{
                                        position: 'relative',
                                        borderRadius: '10px',
                                        border: '1px solid hsl(0 0% 90%)',
                                        background: 'hsl(0 0% 98%)',
                                        overflow: 'hidden',
                                        animation: 'popIn .25s both',
                                      }}
                                    >
                                      {'\n                  '}
                                      {a?.hasThumb ? (
                                        <>
                                          <div style={css(`height:72px;background:url(${S(a?.thumb)}) center/cover no-repeat`)} />
                                        </>
                                      ) : null}
                                      {'\n                  '}
                                      {a?.noThumb ? (
                                        <>
                                          <div style={{ height: '72px', display: 'grid', placeItems: 'center', color: 'hsl(0 0% 46%)' }}>
                                            <lu-icon name={a?.icon} size="24" />
                                          </div>
                                        </>
                                      ) : null}
                                      {'\n                  '}
                                      <div style={{ padding: '5px 7px', borderTop: '1px solid hsl(0 0% 92%)' }}>
                                        <div
                                          style={{
                                            fontSize: '10.5px',
                                            fontWeight: '600',
                                            whiteSpace: 'nowrap',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                          }}
                                        >
                                          {T(a?.nome)}
                                        </div>
                                        <div style={{ fontSize: '10px', color: 'hsl(0 0% 62%)' }}>{T(a?.size)}</div>
                                      </div>
                                      {'\n                  '}
                                      <button
                                        onClick={a?.onRemove}
                                        aria-label="Remover anexo"
                                        style={{
                                          position: 'absolute',
                                          top: '4px',
                                          right: '4px',
                                          width: '26px',
                                          height: '26px',
                                          borderRadius: '8px',
                                          border: 'none',
                                          background: 'rgba(0,0,0,.55)',
                                          color: '#fff',
                                          display: 'grid',
                                          placeItems: 'center',
                                          cursor: 'pointer',
                                        }}
                                      >
                                        <lu-icon name="x" size="13" />
                                      </button>
                                      {'\n                '}
                                    </div>
                                    {'\n              '}
                                  </Fragment>
                                ))}
                                {'\n            '}
                              </div>
                              {'\n          '}
                            </>
                          ) : null}
                          {'\n        '}
                        </div>
                        {'\n        '}
                        {v.repHasErr ? (
                          <>
                            <div style={{ fontSize: '12.5px', fontWeight: '500', color: 'hsl(6 91% 47%)' }}>{T(v.repErr)}</div>
                          </>
                        ) : null}
                        {'\n      '}
                      </div>
                      {'\n      '}
                      <div
                        style={{
                          flex: 'none',
                          padding: '12px 16px calc(16px + env(safe-area-inset-bottom))',
                          borderTop: '1px solid hsl(0 0% 93%)',
                        }}
                      >
                        {'\n        '}
                        <button
                          onClick={v.onRepSend}
                          style={{
                            width: '100%',
                            height: '52px',
                            border: 'none',
                            borderRadius: '12px',
                            background: 'hsl(6 91% 47%)',
                            color: '#fff',
                            fontSize: '15px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            boxShadow: '0 4px 0 hsl(6 100% 34%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '8px',
                            transition: 'transform .25s cubic-bezier(.34,1.56,.64,1)',
                          }}
                          className="scp0"
                        >
                          {'\n          '}
                          {v.repSending ? (
                            <>
                              <span
                                style={{
                                  width: '18px',
                                  height: '18px',
                                  border: '2.5px solid rgba(255,255,255,.4)',
                                  borderTopColor: '#fff',
                                  borderRadius: '50%',
                                  animation: 'spin .7s linear infinite',
                                }}
                              />
                              {'Enviando…'}
                            </>
                          ) : null}
                          {'\n          '}
                          {v.repIdle ? (
                            <>
                              <lu-icon name="send" size="17" />
                              {'Enviar feedback'}
                            </>
                          ) : null}
                          {'\n        '}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n    '}
                  {v.repDone ? (
                    <>
                      {'\n      '}
                      <div
                        style={{
                          padding: '8px 20px calc(20px + env(safe-area-inset-bottom))',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                          textAlign: 'center',
                          gap: '8px',
                        }}
                      >
                        {'\n        '}
                        {v.repSynced ? (
                          <>
                            <span
                              style={{
                                width: '64px',
                                height: '64px',
                                borderRadius: '18px',
                                background: 'hsl(150 55% 40% / .14)',
                                color: 'hsl(150 55% 38%)',
                                display: 'grid',
                                placeItems: 'center',
                                animation: 'popIn .45s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <lu-icon name="circle-check" size="32" draw="" />
                            </span>
                            <div style={{ fontSize: '18px', fontWeight: '700', marginTop: '6px' }}>{'Feedback registrado'}</div>
                            <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', maxWidth: '32ch' }}>
                              {'Salvo na nuvem com o contexto da tela. O time de Produto revisa e corrige.'}
                            </div>
                          </>
                        ) : null}
                        {'\n        '}
                        {v.repPending ? (
                          <>
                            <span
                              style={{
                                width: '64px',
                                height: '64px',
                                borderRadius: '18px',
                                background: 'hsl(40 92% 46% / .15)',
                                color: 'hsl(32 82% 40%)',
                                display: 'grid',
                                placeItems: 'center',
                                animation: 'popIn .45s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <lu-icon name="cloud-off" size="32" />
                            </span>
                            <div style={{ fontSize: '18px', fontWeight: '700', marginTop: '6px' }}>{'Salvo no aparelho'}</div>
                            <div style={{ fontSize: '13px', color: 'hsl(0 0% 46%)', maxWidth: '32ch' }}>
                              {'Você está offline. O feedback vai para a nuvem assim que a conexão voltar.'}
                            </div>
                          </>
                        ) : null}
                        {'\n        '}
                        <div
                          style={{
                            marginTop: '4px',
                            fontSize: '12px',
                            fontWeight: '600',
                            letterSpacing: '.04em',
                            color: 'hsl(0 0% 46%)',
                            padding: '4px 10px',
                            borderRadius: '999px',
                            background: 'hsl(0 0% 95%)',
                          }}
                        >
                          {'Protocolo '}
                          {T(v.repDoneId)}
                        </div>
                        {'\n        '}
                        <button
                          onClick={v.onRepClose}
                          style={{
                            marginTop: '14px',
                            width: '100%',
                            height: '50px',
                            border: 'none',
                            borderRadius: '12px',
                            background: 'hsl(6 91% 47%)',
                            color: '#fff',
                            fontSize: '15px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            boxShadow: '0 4px 0 hsl(6 100% 34%)',
                          }}
                        >
                          {'Fechar'}
                        </button>
                        {'\n        '}
                        <button
                          onClick={v.onRepAnother}
                          style={{
                            width: '100%',
                            height: '44px',
                            border: 'none',
                            background: 'none',
                            color: 'hsl(6 91% 47%)',
                            fontSize: '13.5px',
                            fontWeight: '600',
                            cursor: 'pointer',
                          }}
                        >
                          {'Enviar outro sobre o mesmo ponto'}
                        </button>
                        {'\n      '}
                      </div>
                      {'\n    '}
                    </>
                  ) : null}
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.buyOpen ? (
            <>
              <div
                onClick={v.onBuyCancel}
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  background: 'rgba(0,0,0,.5)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '20px',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  onClick={v.stopProp}
                  style={css(
                    `width:100%;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.35);border-top:${S(v.bTop)};animation:modalIn .22s both`,
                  )}
                >
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      padding: '14px 16px',
                      borderBottom: '1px solid hsl(0 0% 93%)',
                    }}
                  >
                    <h4 style={{ margin: '0', flex: '1', fontSize: '15px', fontWeight: '700' }}>{'Confirmar compra'}</h4>
                    <button
                      onClick={v.onBuyCancel}
                      aria-label="Fechar"
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '8px',
                        border: '1px solid hsl(0 0% 90%)',
                        background: '#fff',
                        color: 'hsl(0 0% 46%)',
                        display: 'grid',
                        placeItems: 'center',
                        cursor: 'pointer',
                      }}
                    >
                      <lu-icon name="x" size="16" />
                    </button>
                  </div>
                  {'\n    '}
                  <div style={{ padding: '18px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                    {'\n      '}
                    {v.bIsVisual ? (
                      <>
                        {'\n        '}
                        <div
                          style={{
                            alignSelf: 'stretch',
                            borderRadius: '14px',
                            overflow: 'hidden',
                            border: '1px solid hsl(0 0% 90%)',
                            marginBottom: '8px',
                          }}
                        >
                          {'\n          '}
                          <div style={css(`height:70px;background:${S(v.bBanner)};transition:background .3s`)} />
                          {'\n          '}
                          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '10px', padding: '0 14px 14px', marginTop: '-34px' }}>
                            {'\n            '}
                            <span
                              style={{
                                position: 'relative',
                                width: '84px',
                                height: '84px',
                                display: 'inline-flex',
                                flex: 'none',
                                animation: 'popIn .5s .1s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <span
                                style={{
                                  position: 'absolute',
                                  top: '12px',
                                  left: '12px',
                                  width: '60px',
                                  height: '60px',
                                  borderRadius: '999px',
                                  background: 'hsl(6 91% 47%)',
                                  color: '#fff',
                                  display: 'grid',
                                  placeItems: 'center',
                                  fontSize: '20px',
                                  fontWeight: '700',
                                  border: '2px solid #fff',
                                }}
                              >
                                {T(v.bAv?.ini)}
                              </span>
                              <span
                                style={css(
                                  `position:absolute;inset:0;display:block;background:url(${S(v.bAv?.src)}) center/contain no-repeat`,
                                )}
                              />
                            </span>
                            {'\n            '}
                            <div style={{ flex: '1', minWidth: '0', paddingBottom: '4px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '15px', fontWeight: '700' }}>
                                <span style={{ minWidth: '0', overflowWrap: 'anywhere' }}>{T(v.bNome)}</span>
                                {v.bIconOn ? (
                                  <>
                                    <span
                                      style={{
                                        width: '22px',
                                        height: '22px',
                                        borderRadius: '7px',
                                        background: 'hsl(6 91% 47% / .12)',
                                        color: 'hsl(6 91% 47%)',
                                        display: 'grid',
                                        placeItems: 'center',
                                        flex: 'none',
                                        animation: 'popIn .4s .3s both',
                                      }}
                                    >
                                      <lu-icon name={v.bIcon} size="13" />
                                    </span>
                                  </>
                                ) : null}
                              </div>
                              <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)' }}>{T(v.bTeam)}</div>
                            </div>
                            {'\n          '}
                          </div>
                          {'\n        '}
                        </div>
                        {'\n      '}
                      </>
                    ) : null}
                    {'\n      '}
                    {v.bIsItem ? (
                      <>
                        <span
                          style={{
                            width: '84px',
                            height: '84px',
                            marginBottom: '8px',
                            borderRadius: '999px',
                            background: 'hsl(40 92% 46% / .12)',
                            color: 'hsl(40 92% 46%)',
                            display: 'grid',
                            placeItems: 'center',
                            animation: 'popIn .5s both',
                          }}
                        >
                          <lu-icon name={v.bItemIcon} size="38" />
                        </span>
                      </>
                    ) : null}
                    {'\n      '}
                    <span
                      style={css(
                        `border-radius:999px;padding:2px 10px;font-size:11px;font-weight:600;background:${S(v.bRbg)};color:${S(v.bRfg)}`,
                      )}
                    >
                      {T(v.bRar)}
                    </span>
                    {'\n      '}
                    <div style={{ fontSize: '17px', fontWeight: '700', textAlign: 'center' }}>{T(v.bNomeI)}</div>
                    {'\n      '}
                    <div style={{ fontSize: '12px', color: 'hsl(0 0% 46%)', textAlign: 'center', textWrap: 'balance' }}>
                      {T(v.bCol)}
                      {' · '}
                      {T(v.bHint)}
                    </div>
                    {'\n      '}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        marginTop: '8px',
                        fontSize: '16px',
                        fontWeight: '800',
                        color: '#d97706',
                      }}
                    >
                      {v.bPago ? (
                        <>
                          <img src="assets/academy-book.png" width="22" height="22" alt="" />
                          {T(v.bPreco)}
                        </>
                      ) : null}
                      {v.bGratis ? (
                        <>
                          <span style={{ color: '#059669' }}>{'Grátis'}</span>
                        </>
                      ) : null}
                    </div>
                    {'\n      '}
                    <div style={{ fontSize: '11.5px', color: 'hsl(0 0% 46%)', whiteSpace: 'nowrap' }}>{T(v.bAfter)}</div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      gap: '8px',
                      padding: '14px 16px',
                      borderTop: '1px solid hsl(0 0% 93%)',
                      background: 'hsl(0 0% 98.5%)',
                    }}
                  >
                    <button
                      onClick={v.onBuyCancel}
                      style={{
                        minHeight: '42px',
                        padding: '0 14px',
                        borderRadius: '10px',
                        border: '1px solid hsl(0 0% 90%)',
                        background: '#fff',
                        fontSize: '13px',
                        fontWeight: '500',
                        cursor: 'pointer',
                        color: 'hsl(0 0% 13%)',
                      }}
                    >
                      {'Cancelar'}
                    </button>
                    <button
                      onClick={v.onBuyConfirm}
                      style={{
                        minHeight: '42px',
                        padding: '0 16px',
                        border: 'none',
                        borderRadius: '10px',
                        background: 'hsl(6 91% 47%)',
                        color: '#fff',
                        fontSize: '13px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        boxShadow: '0 2px 8px hsl(6 91% 47% / .28)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      <lu-icon name="check" size="15" />
                      {'Confirmar compra'}
                    </button>
                  </div>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.wrOpen ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  background: 'rgba(0,0,0,.5)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '22px',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  style={{
                    width: '100%',
                    background: '#fff',
                    borderRadius: '18px',
                    padding: '26px 22px 22px',
                    boxShadow: '0 24px 60px rgba(0,0,0,.35)',
                    textAlign: 'center',
                    animation: 'modalIn .25s both',
                  }}
                >
                  {'\n    '}
                  <div style={{ position: 'relative', width: '110px', height: '122px', margin: '0 auto 18px' }}>
                    {'\n      '}
                    {v.wrChanged ? (
                      <>
                        <div
                          style={css(
                            `position:absolute;inset:0;background:${S(v.wrFromG)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%);display:grid;place-items:center;color:#fff;animation:shrinkOut .35s .3s cubic-bezier(.16,1,.3,1) forwards`,
                          )}
                        >
                          <lu-icon name={v.wrFromIcon} size="44" />
                        </div>
                      </>
                    ) : null}
                    {'\n      '}
                    <div
                      style={css(
                        `position:absolute;inset:0;background:${S(v.wrToG)};clip-path:polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%);display:grid;place-items:center;color:#fff;animation:spinIn .7s .6s cubic-bezier(.34,1.56,.64,1) both`,
                      )}
                      data-comment-anchor="1517808c95-div"
                    >
                      <span
                        style={{
                          position: 'absolute',
                          inset: '6px',
                          clipPath: 'polygon(50% 0,100% 14%,100% 60%,50% 100%,0 60%,0 14%)',
                          background: 'linear-gradient(160deg,rgba(255,255,255,.35),rgba(255,255,255,0) 55%,rgba(0,0,0,.18))',
                        }}
                      />
                      <span style={{ position: 'relative', display: 'grid', marginTop: '-8px' }}>
                        <lu-icon name={v.wrToIcon} size="44" />
                      </span>
                    </div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <h2 style={{ margin: '0 0 6px', fontSize: '20px', fontWeight: '800', letterSpacing: '-.02em' }}>{T(v.wrTitle)}</h2>
                  {'\n    '}
                  <p style={{ margin: '0 0 20px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>{T(v.wrText)}</p>
                  {'\n    '}
                  <button
                    onClick={v.onWrClose}
                    style={{
                      width: '100%',
                      height: '52px',
                      border: 'none',
                      borderRadius: '12px',
                      background: 'hsl(6 91% 47%)',
                      color: '#fff',
                      fontSize: '15px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      boxShadow: '0 4px 0 hsl(6 100% 34%)',
                    }}
                  >
                    {'Começar nova semana'}
                  </button>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.exitAsk ? (
            <>
              <div
                onClick={v.onExitCancel}
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  background: 'rgba(0,0,0,.45)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  onClick={v.stopProp}
                  style={{
                    width: '100%',
                    background: '#fff',
                    borderRadius: '20px 20px 0 0',
                    padding: '22px 20px calc(20px + env(safe-area-inset-bottom))',
                    animation: 'sheetUp .35s cubic-bezier(.16,1,.3,1) both',
                    textAlign: 'center',
                  }}
                >
                  {'\n    '}
                  <h3 style={{ margin: '0 0 6px', fontSize: '18px', fontWeight: '700' }}>{'Sair da lição?'}</h3>
                  {'\n    '}
                  <p style={{ margin: '0 0 18px', fontSize: '14px', color: 'hsl(0 0% 46%)' }}>
                    {'O progresso desta lição será perdido. O que você já revisou continua salvo.'}
                  </p>
                  {'\n    '}
                  <button
                    onClick={v.onExitCancel}
                    style={{
                      width: '100%',
                      height: '52px',
                      border: 'none',
                      borderRadius: '12px',
                      background: 'hsl(6 91% 47%)',
                      color: '#fff',
                      fontSize: '15px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      boxShadow: '0 4px 0 hsl(6 100% 34%)',
                      marginBottom: '10px',
                    }}
                  >
                    {'Continuar a lição'}
                  </button>
                  {'\n    '}
                  <button
                    onClick={v.onExitConfirm}
                    style={{
                      width: '100%',
                      height: '48px',
                      border: 'none',
                      background: 'none',
                      color: 'hsl(6 91% 47%)',
                      fontSize: '14px',
                      fontWeight: '700',
                      cursor: 'pointer',
                    }}
                  >
                    {'Sair'}
                  </button>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.resetAsk ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  background: 'rgba(0,0,0,.45)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '22px',
                  animation: 'fadeIn .2s both',
                }}
              >
                {'\n  '}
                <div
                  style={{
                    width: '100%',
                    background: '#fff',
                    borderRadius: '18px',
                    overflow: 'hidden',
                    boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                    animation: 'modalIn .2s both',
                  }}
                >
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      padding: '16px 18px',
                      borderBottom: '1px solid hsl(0 0% 93%)',
                    }}
                  >
                    <span
                      style={{
                        width: '30px',
                        height: '30px',
                        borderRadius: '8px',
                        background: 'hsl(40 92% 46% / .15)',
                        color: 'hsl(40 92% 46%)',
                        display: 'grid',
                        placeItems: 'center',
                      }}
                    >
                      <lu-icon name="triangle-alert" size="16" />
                    </span>
                    <h4 style={{ margin: '0', fontSize: '15px', fontWeight: '700' }}>{'Resetar progresso'}</h4>
                  </div>
                  {'\n    '}
                  <div style={{ padding: '16px 18px', fontSize: '13px', color: 'hsl(0 0% 46%)' }}>
                    {'XP, ofensiva, trilhas, emblemas e Takitos do Academy voltam ao início. Seu login do Hub continua igual.'}
                  </div>
                  {'\n    '}
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      gap: '8px',
                      padding: '14px 18px',
                      borderTop: '1px solid hsl(0 0% 93%)',
                      background: 'hsl(0 0% 98.5%)',
                    }}
                  >
                    <button
                      onClick={v.onResetCancel}
                      style={{
                        minHeight: '40px',
                        padding: '0 14px',
                        borderRadius: '9px',
                        border: '1px solid hsl(0 0% 90%)',
                        background: '#fff',
                        fontSize: '12.5px',
                        fontWeight: '500',
                        cursor: 'pointer',
                        color: 'hsl(0 0% 13%)',
                      }}
                    >
                      {'Cancelar'}
                    </button>
                    <button
                      onClick={v.onResetConfirm}
                      style={{
                        minHeight: '40px',
                        padding: '0 14px',
                        border: 'none',
                        borderRadius: '9px',
                        background: 'hsl(6 91% 47%)',
                        color: '#fff',
                        fontSize: '12.5px',
                        fontWeight: '600',
                        cursor: 'pointer',
                      }}
                    >
                      {'Resetar'}
                    </button>
                  </div>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.tempOpen ? (
            <>
              <div
                onClick={v.onTempClose}
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '95',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '20px',
                  background: 'rgba(0,0,0,.55)',
                  backdropFilter: 'blur(3px)',
                  animation: 'rise .2s ease',
                }}
              >
                {'\n  '}
                <div
                  onClick={v.stopProp}
                  style={{
                    width: '100%',
                    maxWidth: '440px',
                    height: '520px',
                    maxHeight: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    background: '#f7f7f8',
                    border: '1px solid #e5e5e7',
                    borderRadius: '18px',
                    padding: '22px 22px',
                    boxShadow: '0 24px 60px rgba(0,0,0,.35)',
                    animation: 'modalIn .2s both',
                  }}
                >
                  {'\n    '}
                  {v.tempForm ? (
                    <>
                      <div style={{ flex: '1', display: 'flex', flexDirection: 'column' }}>
                        {'\n      '}
                        <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                position: 'relative',
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#df1c0d',
                                border: '1.5px solid #df1c0d',
                                color: '#fff',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                                animation: 'popIn .4s .25s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <span
                                style={{
                                  position: 'absolute',
                                  inset: '-5px',
                                  borderRadius: '999px',
                                  border: '2px solid rgba(223,28,13,.45)',
                                  animation: 'pulseRing 1.6s cubic-bezier(.16,1,.3,1) infinite',
                                }}
                              />
                              {'1'}
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '700', color: '#141414', whiteSpace: 'nowrap' }}>
                              {'Identificação'}
                            </span>
                          </div>
                          <span style={{ flex: '1', height: '2px', borderRadius: '999px', background: '#e5e5e7', minWidth: '8px' }} />
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#fff',
                                border: '1.5px solid #e5e5e7',
                                color: '#9a9a9a',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                              }}
                            >
                              {'2'}
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>
                              {'Verificação'}
                            </span>
                          </div>
                          <span style={{ flex: '1', height: '2px', borderRadius: '999px', background: '#e5e5e7', minWidth: '8px' }} />
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#fff',
                                border: '1.5px solid #e5e5e7',
                                color: '#9a9a9a',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                              }}
                            >
                              {'3'}
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>
                              {'Cadastro'}
                            </span>
                          </div>
                        </div>
                        {'\n      '}
                        <div
                          style={{
                            flex: 'none',
                            width: '46px',
                            height: '46px',
                            borderRadius: '12px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: 'color-mix(in srgb, #df1c0d 14%, transparent)',
                            marginBottom: '16px',
                            color: '#df1c0d',
                          }}
                        >
                          <lu-icon name="lock" size="22" />
                        </div>
                        {'\n      '}
                        <h2 style={{ margin: '0 0 8px', fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em', color: '#141414' }}>
                          {'Gerar senha temporária'}
                        </h2>
                        {'\n      '}
                        <p style={{ margin: '0 0 20px', fontSize: '14px', lineHeight: '1.6', color: '#6b6b6b' }}>
                          {'Informe seu e-mail. Vamos enviar uma senha temporária direto no seu '}
                          <strong>{'WhatsApp cadastrado'}</strong>
                          {'. Ela vale por 1 hora.'}
                        </p>
                        {'\n      '}
                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '9px' }}>
                          {'E-mail '}
                          <span style={{ color: '#df1c0d' }}>{'*'}</span>
                        </label>
                        {'\n      '}
                        <input
                          type="email"
                          inputMode="email"
                          placeholder="Digite seu e-mail"
                          value={D(v.tempEmail, '')}
                          onChange={v.onTempEmail}
                          style={{
                            width: '100%',
                            height: '52px',
                            padding: '0 16px',
                            borderRadius: '12px',
                            fontSize: '15px',
                            border: '1.5px solid #e5e5e7',
                            background: '#fff',
                            color: '#141414',
                          }}
                        />
                        {'\n      '}
                        {v.hasTempErr ? (
                          <>
                            <p style={{ margin: '12px 0 0', fontSize: '13px', fontWeight: '500', color: '#df1c0d' }}>{T(v.tempErr)}</p>
                          </>
                        ) : null}
                        {'\n      '}
                        <button
                          onClick={v.onTempGen}
                          style={{
                            width: '100%',
                            height: '54px',
                            marginTop: 'auto',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '10px',
                            border: 'none',
                            borderRadius: '12px',
                            background: '#df1c0d',
                            color: '#fff',
                            fontSize: '16px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            boxShadow: '0 10px 24px color-mix(in srgb, #df1c0d 32%, transparent)',
                          }}
                        >
                          {'\n        '}
                          {v.tempLoading ? (
                            <>
                              <span
                                style={{
                                  width: '18px',
                                  height: '18px',
                                  border: '2.5px solid rgba(255,255,255,.4)',
                                  borderTopColor: '#fff',
                                  borderRadius: '50%',
                                  animation: 'spin .7s linear infinite',
                                }}
                              />
                              <span>{'Enviando…'}</span>
                            </>
                          ) : null}
                          {'\n        '}
                          {v.tempIdle ? (
                            <>
                              <span style={{ whiteSpace: 'nowrap' }}>{'Gerar senha temporária'}</span>
                            </>
                          ) : null}
                          {'\n      '}
                        </button>
                        {'\n      '}
                        <button
                          onClick={v.onTempClose}
                          style={{
                            width: '100%',
                            marginTop: '8px',
                            minHeight: '44px',
                            border: 'none',
                            background: 'none',
                            cursor: 'pointer',
                            color: '#6b6b6b',
                            fontSize: '13.5px',
                            fontWeight: '600',
                          }}
                        >
                          {'Cancelar'}
                        </button>
                        {'\n    '}
                      </div>
                    </>
                  ) : null}
                  {'\n    '}
                  {v.tempSent ? (
                    <>
                      <div style={{ flex: '1', display: 'flex', flexDirection: 'column' }}>
                        {'\n      '}
                        <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#10b981',
                                border: '1.5px solid #10b981',
                                color: '#fff',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                                animation: 'popIn .4s .1s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <lu-icon name="check" size="12" stroke="3" draw="" />
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>
                              {'Identificação'}
                            </span>
                          </div>
                          <span
                            style={{
                              flex: '1',
                              height: '2px',
                              borderRadius: '999px',
                              background: 'linear-gradient(90deg,#10b981 50%,#e5e5e7 50%)',
                              backgroundSize: '200% 100%',
                              backgroundPosition: '100% 0',
                              minWidth: '8px',
                              animation: 'trailFill .5s .2s cubic-bezier(.16,1,.3,1) forwards',
                            }}
                          />
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                position: 'relative',
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#df1c0d',
                                border: '1.5px solid #df1c0d',
                                color: '#fff',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                                animation: 'popIn .4s .25s cubic-bezier(.34,1.56,.64,1) both',
                              }}
                            >
                              <span
                                style={{
                                  position: 'absolute',
                                  inset: '-5px',
                                  borderRadius: '999px',
                                  border: '2px solid rgba(223,28,13,.45)',
                                  animation: 'pulseRing 1.6s cubic-bezier(.16,1,.3,1) infinite',
                                }}
                              />
                              {'2'}
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '700', color: '#141414', whiteSpace: 'nowrap' }}>
                              {'Verificação'}
                            </span>
                          </div>
                          <span style={{ flex: '1', height: '2px', borderRadius: '999px', background: '#e5e5e7', minWidth: '8px' }} />
                          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                            <span
                              style={{
                                width: '22px',
                                height: '22px',
                                borderRadius: '999px',
                                background: '#fff',
                                border: '1.5px solid #e5e5e7',
                                color: '#9a9a9a',
                                display: 'grid',
                                placeItems: 'center',
                                fontSize: '11px',
                                fontWeight: '700',
                              }}
                            >
                              {'3'}
                            </span>
                            <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>
                              {'Cadastro'}
                            </span>
                          </div>
                        </div>
                        {'\n      '}
                        <div
                          style={{
                            flex: 'none',
                            width: '46px',
                            height: '46px',
                            borderRadius: '12px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: 'rgba(16,185,129,.14)',
                            marginBottom: '16px',
                            color: '#10b981',
                          }}
                        >
                          <lu-icon name="check" size="24" stroke="2.4" />
                        </div>
                        {'\n      '}
                        <h2 style={{ margin: '0 0 10px', fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em', color: '#141414' }}>
                          {'Senha enviada!'}
                        </h2>
                        {'\n      '}
                        <p style={{ margin: '0 0 8px', fontSize: '14.5px', lineHeight: '1.7', color: '#141414' }}>
                          {'Enviamos uma senha temporária para o WhatsApp de '}
                          <strong>{T(v.tempNome)}</strong>
                          {' no número '}
                          <strong style={{ whiteSpace: 'nowrap' }}>{T(v.tempMasc)}</strong>
                          {'.'}
                        </p>
                        {'\n      '}
                        <p style={{ margin: '0 0 22px', fontSize: '13.5px', lineHeight: '1.6', color: '#6b6b6b' }}>
                          {'Faça login com ela. Ela expira em '}
                          <strong>{'1 hora'}</strong>
                          {' e você definirá uma nova senha ao entrar.'}
                        </p>
                        {'\n      '}
                        <button
                          onClick={v.onTempLogin}
                          style={{
                            width: '100%',
                            height: '54px',
                            marginTop: 'auto',
                            border: 'none',
                            borderRadius: '12px',
                            background: '#df1c0d',
                            color: '#fff',
                            fontSize: '16px',
                            fontWeight: '700',
                            cursor: 'pointer',
                            boxShadow: '0 10px 24px color-mix(in srgb, #df1c0d 32%, transparent)',
                          }}
                        >
                          {'Fazer login'}
                        </button>
                        {'\n    '}
                      </div>
                    </>
                  ) : null}
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          {v.firstOpen ? (
            <>
              <div
                style={{
                  position: 'absolute',
                  inset: '0',
                  zIndex: '96',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '20px',
                  background: 'rgba(0,0,0,.55)',
                  backdropFilter: 'blur(3px)',
                  animation: 'rise .2s ease',
                }}
              >
                {'\n  '}
                <div
                  style={{
                    width: '100%',
                    maxWidth: '440px',
                    height: '700px',
                    maxHeight: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    background: '#f7f7f8',
                    border: '1px solid #e5e5e7',
                    borderRadius: '18px',
                    padding: '22px 20px',
                    boxShadow: '0 24px 60px rgba(0,0,0,.35)',
                    animation: 'modalIn .2s both',
                  }}
                >
                  {'\n    '}
                  <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                      <span
                        style={{
                          width: '22px',
                          height: '22px',
                          borderRadius: '999px',
                          background: '#10b981',
                          border: '1.5px solid #10b981',
                          color: '#fff',
                          display: 'grid',
                          placeItems: 'center',
                          fontSize: '11px',
                          fontWeight: '700',
                          animation: 'popIn .4s .1s cubic-bezier(.34,1.56,.64,1) both',
                        }}
                      >
                        <lu-icon name="check" size="12" stroke="3" draw="" />
                      </span>
                      <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>
                        {'Identificação'}
                      </span>
                    </div>
                    <span
                      style={{
                        flex: '1',
                        height: '2px',
                        borderRadius: '999px',
                        background: 'linear-gradient(90deg,#10b981 50%,#e5e5e7 50%)',
                        backgroundSize: '200% 100%',
                        backgroundPosition: '100% 0',
                        minWidth: '8px',
                        animation: 'trailFill .5s .2s cubic-bezier(.16,1,.3,1) forwards',
                      }}
                    />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                      <span
                        style={{
                          width: '22px',
                          height: '22px',
                          borderRadius: '999px',
                          background: '#10b981',
                          border: '1.5px solid #10b981',
                          color: '#fff',
                          display: 'grid',
                          placeItems: 'center',
                          fontSize: '11px',
                          fontWeight: '700',
                          animation: 'popIn .4s .1s cubic-bezier(.34,1.56,.64,1) both',
                        }}
                      >
                        <lu-icon name="check" size="12" stroke="3" draw="" />
                      </span>
                      <span style={{ fontSize: '10.5px', fontWeight: '500', color: '#6b6b6b', whiteSpace: 'nowrap' }}>{'Verificação'}</span>
                    </div>
                    <span
                      style={{
                        flex: '1',
                        height: '2px',
                        borderRadius: '999px',
                        background: 'linear-gradient(90deg,#10b981 50%,#e5e5e7 50%)',
                        backgroundSize: '200% 100%',
                        backgroundPosition: '100% 0',
                        minWidth: '8px',
                        animation: 'trailFill .5s .2s cubic-bezier(.16,1,.3,1) forwards',
                      }}
                    />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flex: 'none' }}>
                      <span
                        style={{
                          position: 'relative',
                          width: '22px',
                          height: '22px',
                          borderRadius: '999px',
                          background: '#df1c0d',
                          border: '1.5px solid #df1c0d',
                          color: '#fff',
                          display: 'grid',
                          placeItems: 'center',
                          fontSize: '11px',
                          fontWeight: '700',
                          animation: 'popIn .4s .25s cubic-bezier(.34,1.56,.64,1) both',
                        }}
                      >
                        <span
                          style={{
                            position: 'absolute',
                            inset: '-5px',
                            borderRadius: '999px',
                            border: '2px solid rgba(223,28,13,.45)',
                            animation: 'pulseRing 1.6s cubic-bezier(.16,1,.3,1) infinite',
                          }}
                        />
                        {'3'}
                      </span>
                      <span style={{ fontSize: '10.5px', fontWeight: '700', color: '#141414', whiteSpace: 'nowrap' }}>{'Cadastro'}</span>
                    </div>
                  </div>
                  {'\n    '}
                  <div
                    style={{
                      flex: 'none',
                      width: '46px',
                      height: '46px',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      background: 'color-mix(in srgb, #df1c0d 14%, transparent)',
                      marginBottom: '14px',
                      color: '#df1c0d',
                    }}
                  >
                    <lu-icon name="key-round" size="22" />
                  </div>
                  {'\n    '}
                  <h2 style={{ margin: '0 0 6px', fontSize: '22px', fontWeight: '800', letterSpacing: '-.02em', color: '#141414' }}>
                    {'Primeiro acesso'}
                  </h2>
                  {'\n    '}
                  <p style={{ margin: '0 0 18px', fontSize: '13.5px', lineHeight: '1.6', color: '#6b6b6b' }}>
                    {'Defina sua senha e complete o cadastro de '}
                    <b style={{ color: '#141414' }}>{T(v.fEmail)}</b>
                    {'.'}
                  </p>
                  {'\n    '}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    {'\n      '}
                    <div>
                      <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '8px' }}>
                        {'Nova senha '}
                        <span style={{ color: '#df1c0d' }}>{'*'}</span>
                      </label>
                      <input
                        type="password"
                        value={D(v.fPwd, '')}
                        onChange={v.onFPwd}
                        placeholder="Mínimo 6 caracteres"
                        style={{
                          width: '100%',
                          height: '50px',
                          padding: '0 14px',
                          borderRadius: '12px',
                          fontSize: '15px',
                          border: '1.5px solid #e5e5e7',
                          background: '#fff',
                        }}
                      />
                    </div>
                    {'\n      '}
                    <div>
                      <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '8px' }}>
                        {'Confirmar senha '}
                        <span style={{ color: '#df1c0d' }}>{'*'}</span>
                      </label>
                      <input
                        type="password"
                        value={D(v.fPwd2, '')}
                        onChange={v.onFPwd2}
                        placeholder="Repita a nova senha"
                        style={{
                          width: '100%',
                          height: '50px',
                          padding: '0 14px',
                          borderRadius: '12px',
                          fontSize: '15px',
                          border: '1.5px solid #e5e5e7',
                          background: '#fff',
                        }}
                      />
                    </div>
                    {'\n      '}
                    <div>
                      <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '8px' }}>
                        {'Equipe '}
                        <span style={{ color: '#df1c0d' }}>{'*'}</span>
                      </label>
                      <div style={{ position: 'relative' }}>
                        <button
                          onClick={v.fTeamDD?.toggle}
                          style={{
                            width: '100%',
                            height: '50px',
                            borderRadius: '12px',
                            border: '1.5px solid #e5e5e7',
                            background: '#fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '8px',
                            padding: '0 14px',
                            fontSize: '15px',
                            color: 'hsl(0 0% 13%)',
                            cursor: 'pointer',
                            textAlign: 'left',
                          }}
                        >
                          <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{T(v.fTeamDD?.label)}</span>
                          <lu-icon name="chevron-down" size="16" />
                        </button>
                        {v.fTeamDD?.open ? (
                          <>
                            <div
                              style={{
                                position: 'absolute',
                                top: 'calc(100% + 8px)',
                                left: '0',
                                right: '0',
                                zIndex: '30',
                                background: '#fff',
                                border: '1px solid hsl(0 0% 90%)',
                                borderRadius: '13px',
                                boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                                padding: '6px',
                                maxHeight: '232px',
                                overflowY: 'auto',
                                animation: 'modalIn .15s both',
                              }}
                            >
                              {L(v.fTeamDD?.items).map((o, $i65) => (
                                <Fragment key={$i65}>
                                  <button
                                    onClick={o?.onClick}
                                    style={css(
                                      `width:100%;min-height:40px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border:none;border-radius:9px;background:${S(o?.bg)};color:${S(o?.fg)};font-size:13.5px;font-weight:${S(o?.fw)};cursor:pointer;text-align:left`,
                                    )}
                                  >
                                    <span style={{ flex: '1', minWidth: '0', textAlign: 'left' }}>{T(o?.t)}</span>
                                    {o?.sel ? (
                                      <>
                                        <lu-icon name="check" size="15" />
                                      </>
                                    ) : null}
                                  </button>
                                </Fragment>
                              ))}
                            </div>
                          </>
                        ) : null}
                      </div>
                    </div>
                    {'\n      '}
                    <div>
                      <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#141414', marginBottom: '8px' }}>
                        {'Data de nascimento '}
                        <span style={{ color: '#df1c0d' }}>{'*'}</span>
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        placeholder="dd/mm/aaaa"
                        value={D(v.fBirth, '')}
                        onChange={v.onFBirthMask}
                        style={{
                          width: '100%',
                          height: '50px',
                          padding: '0 14px',
                          borderRadius: '12px',
                          fontSize: '15px',
                          border: '1.5px solid #e5e5e7',
                          background: '#fff',
                        }}
                      />
                    </div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  {v.hasFErr ? (
                    <>
                      <p style={{ margin: '12px 0 0', fontSize: '13px', fontWeight: '500', color: '#df1c0d' }}>{T(v.fErr)}</p>
                    </>
                  ) : null}
                  {'\n    '}
                  <button
                    onClick={v.onFirstSave}
                    style={{
                      width: '100%',
                      height: '54px',
                      marginTop: 'auto',
                      flex: 'none',
                      border: 'none',
                      borderRadius: '12px',
                      background: '#df1c0d',
                      color: '#fff',
                      fontSize: '16px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      boxShadow: '0 10px 24px color-mix(in srgb, #df1c0d 32%, transparent)',
                    }}
                  >
                    {'Salvar e entrar'}
                  </button>
                  {'\n  '}
                </div>
              </div>
            </>
          ) : null}
          <div
            style={{
              position: 'absolute',
              top: '10px',
              left: '12px',
              right: '12px',
              zIndex: '110',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
              pointerEvents: 'none',
            }}
          >
            {'\n  '}
            {L(v.toasts).map((t, $i66) => (
              <Fragment key={$i66}>
                {'\n    '}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    padding: '12px 14px',
                    borderRadius: '12px',
                    background: '#fff',
                    border: '1px solid hsl(0 0% 90%)',
                    boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                    fontSize: '13px',
                    fontWeight: '500',
                    color: 'hsl(0 0% 13%)',
                    animation: 'toastIn .3s cubic-bezier(.16,1,.3,1) both',
                  }}
                >
                  <span style={css(`color:${S(t?.fg)};display:grid`)}>
                    <lu-icon name={t?.icon} size="18" />
                  </span>
                  {T(t?.text)}
                </div>
                {'\n  '}
              </Fragment>
            ))}
          </div>
          {'\n'}
          {T(v.flyersEl)}
          {'\n\n'}
        </div>
        {v.printCert ? (
          <>
            <div id="print-cert">
              <div style={{ containerType: 'inline-size', width: '100%' }}>
                {'\n  '}
                <div
                  style={{
                    position: 'relative',
                    width: '100%',
                    aspectRatio: '297/210',
                    fontFamily: "'Poppins',sans-serif",
                    color: 'hsl(0 0% 13%)',
                    display: 'grid',
                    gridTemplateColumns: '31% 1fr',
                    background: '#fff',
                    overflow: 'hidden',
                    borderRadius: '1.4cqw',
                    boxShadow: '0 12px 34px rgba(0,0,0,.14)',
                    animation: 'reveal3d .6s cubic-bezier(.16,1,.3,1) both',
                  }}
                >
                  {'\n    '}
                  <div
                    style={{
                      position: 'relative',
                      background: '#df1c0d',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      padding: '7cqw 4.5cqw 5cqw',
                    }}
                  >
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        inset: '-20%',
                        transform: 'rotate(-8deg)',
                        background: 'url("assets/takeat-mark.png") 0 0/7cqw 7cqw repeat',
                        filter: 'brightness(0) invert(1)',
                        opacity: '.07',
                      }}
                    />
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        inset: '0',
                        background: 'linear-gradient(135deg,rgba(255,255,255,.10),rgba(0,0,0,.34) 135%)',
                      }}
                    />
                    {'\n      '}
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '1.4cqw' }}>
                      {'\n        '}
                      <span
                        style={{
                          width: '4.6cqw',
                          height: '4.6cqw',
                          background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                          filter: 'brightness(0) invert(1)',
                          flex: 'none',
                        }}
                      />
                      {'\n        '}
                      <span style={{ display: 'flex', flexDirection: 'column', lineHeight: '1', color: '#fff' }}>
                        <span style={{ fontSize: '2.5cqw', fontWeight: '800', letterSpacing: '-.02em' }}>{'TakeatHub'}</span>
                        <span style={{ fontFamily: "'Dancing Script',cursive", fontSize: '2.9cqw', fontWeight: '700', marginTop: '.2cqw' }}>
                          {'Academy'}
                        </span>
                      </span>
                      {'\n      '}
                    </div>
                    {'\n      '}
                    <div
                      style={{
                        position: 'relative',
                        width: '19cqw',
                        height: '19cqw',
                        margin: '0 auto',
                        background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                        filter: 'brightness(0) invert(1) drop-shadow(0 2cqw 3cqw rgba(0,0,0,.3))',
                        opacity: '.95',
                      }}
                    />
                    {'\n      '}
                    <div style={{ position: 'relative', color: 'rgba(255,255,255,.88)', fontSize: '1.15cqw', lineHeight: '1.55' }}>
                      {'\n        '}
                      <div
                        style={{
                          fontSize: '.95cqw',
                          fontWeight: '700',
                          letterSpacing: '.15em',
                          textTransform: 'uppercase',
                          color: 'rgba(255,255,255,.72)',
                          marginBottom: '.8cqw',
                        }}
                      >
                        {'Plataforma interna Takeat'}
                      </div>
                      {
                        '\n        Trilhas de aprendizado sobre a plataforma, os processos internos e as regras de atendimento de cada equipe.\n      '
                      }
                    </div>
                    {'\n    '}
                  </div>
                  {'\n    '}
                  <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', padding: '6.5cqw 6cqw 5cqw 6cqw' }}>
                    {'\n      '}
                    <div
                      style={{
                        position: 'absolute',
                        right: '-3cqw',
                        bottom: '-3cqw',
                        width: '26cqw',
                        height: '26cqw',
                        background: 'url("assets/takeat-mark.png") center/contain no-repeat',
                        opacity: '.045',
                        transform: 'rotate(8deg)',
                      }}
                    />
                    {'\n      '}
                    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '3cqw' }}>
                      {'\n        '}
                      <div>
                        {'\n          '}
                        <div
                          style={{
                            fontSize: '1.1cqw',
                            fontWeight: '700',
                            letterSpacing: '.16em',
                            textTransform: 'uppercase',
                            color: '#df1c0d',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {'Certificado de conclusão'}
                        </div>
                        {'\n          '}
                        <div
                          style={{ width: '5cqw', height: '.35cqw', borderRadius: '999px', background: '#df1c0d', marginTop: '1.2cqw' }}
                        />
                        {'\n        '}
                      </div>
                      {'\n        '}
                      <div
                        style={{
                          position: 'relative',
                          width: '10cqw',
                          height: '10cqw',
                          flex: 'none',
                          borderRadius: '999px',
                          background: 'linear-gradient(145deg,#FFE9A0,#F5B83B 50%,#C7801E)',
                          boxShadow: '0 .8cqw 1.6cqw rgba(199,128,30,.35),inset 0 .2cqw 0 rgba(255,255,255,.6)',
                          display: 'grid',
                          placeItems: 'center',
                        }}
                      >
                        {'\n          '}
                        <div
                          style={{
                            position: 'absolute',
                            inset: '.7cqw',
                            borderRadius: '999px',
                            border: '.18cqw dashed rgba(255,255,255,.75)',
                          }}
                        />
                        {'\n          '}
                        <div
                          style={{
                            position: 'absolute',
                            inset: '1.4cqw',
                            borderRadius: '999px',
                            background: 'radial-gradient(circle at 35% 30%,#FFF6D2,#FFD66B 60%,#E3A325)',
                          }}
                        />
                        {'\n          '}
                        <div
                          style={{
                            position: 'relative',
                            width: '6.6cqw',
                            height: '6.6cqw',
                            background: 'url("assets/takeat-mark.png") center/62% no-repeat',
                            filter: 'drop-shadow(0 .15cqw .2cqw rgba(0,0,0,.25))',
                          }}
                        />
                        {'\n        '}
                      </div>
                      {'\n      '}
                    </div>
                    {'\n      '}
                    <div style={{ marginTop: 'auto', marginBottom: 'auto', padding: '2cqw 0' }}>
                      {'\n        '}
                      <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>{'Certificamos que'}</div>
                      {'\n        '}
                      <div
                        style={{
                          fontSize: '4.6cqw',
                          fontWeight: '800',
                          letterSpacing: '-.03em',
                          lineHeight: '1.05',
                          margin: '.8cqw 0 1.6cqw',
                          textWrap: 'balance',
                        }}
                      >
                        {T(v.cvNome)}
                      </div>
                      {'\n        '}
                      <div style={{ fontSize: '1.45cqw', color: 'hsl(0 0% 46%)' }}>{'concluiu o Desafio Mestre da trilha'}</div>
                      {'\n        '}
                      <div
                        style={{
                          fontSize: '2.5cqw',
                          fontWeight: '700',
                          letterSpacing: '-.01em',
                          lineHeight: '1.2',
                          marginTop: '.4cqw',
                          color: 'hsl(0 0% 13%)',
                          textWrap: 'balance',
                        }}
                      >
                        {T(v.cvTrilha)}
                      </div>
                      {'\n        '}
                      <p style={{ margin: '1.8cqw 0 0', fontSize: '1.2cqw', lineHeight: '1.6', color: 'hsl(0 0% 40%)', maxWidth: '46ch' }}>
                        {T(v.cvDesc)}
                      </p>
                      {'\n      '}
                    </div>
                    {'\n      '}
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr 1.2fr',
                        gap: '3cqw',
                        alignItems: 'end',
                        paddingTop: '2cqw',
                        borderTop: '1px solid hsl(0 0% 90%)',
                      }}
                    >
                      {'\n        '}
                      <div>
                        <div
                          style={{
                            fontSize: '.9cqw',
                            fontWeight: '700',
                            letterSpacing: '.1em',
                            textTransform: 'uppercase',
                            color: 'hsl(0 0% 62%)',
                          }}
                        >
                          {'Emitido em'}
                        </div>
                        <div style={{ fontSize: '1.35cqw', fontWeight: '600', marginTop: '.3cqw' }}>{T(v.cvData)}</div>
                      </div>
                      {'\n        '}
                      <div>
                        <div
                          style={{
                            fontSize: '.9cqw',
                            fontWeight: '700',
                            letterSpacing: '.1em',
                            textTransform: 'uppercase',
                            color: 'hsl(0 0% 62%)',
                          }}
                        >
                          {'Código'}
                        </div>
                        <div style={{ fontSize: '1.35cqw', fontWeight: '600', marginTop: '.3cqw', letterSpacing: '.04em' }}>
                          {T(v.cvCodigo)}
                        </div>
                      </div>
                      {'\n        '}
                      <div>
                        <div
                          style={{
                            fontFamily: "'Dancing Script',cursive",
                            fontSize: '2.6cqw',
                            fontWeight: '700',
                            color: '#8f1109',
                            lineHeight: '1',
                          }}
                        >
                          {'Produto Takeat'}
                        </div>
                        <div style={{ height: '1px', background: 'hsl(0 0% 70%)', margin: '.6cqw 0 .5cqw' }} />
                        <div style={{ fontSize: '.95cqw', color: 'hsl(0 0% 46%)' }}>{'Time de Produto · TakeatHub'}</div>
                      </div>
                      {'\n      '}
                    </div>
                    {'\n    '}
                  </div>
                  {'\n  '}
                </div>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </>
  );
}
