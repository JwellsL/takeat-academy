// Lógica do Takeat Academy — portada 1:1 do protótipo (script data-dc-script).
// Estado, regras e renderVals() são os mesmos do HTML de protótipo.
import React from 'react';
import DCLogic from './dc-logic.js';
import * as Hub from './hub.js';

const LS = 'takeat-academy-v0';
const RED = 'hsl(6 91% 47%)', REDT = 'hsl(6 91% 47% / .12)', REDT2 = 'hsl(6 91% 47% / .06)', GREEN = 'hsl(150 55% 40%)', GREENT = 'hsl(150 55% 40% / .12)', BD = 'hsl(0 0% 90%)', MUT = 'hsl(0 0% 46%)', INK = 'hsl(0 0% 13%)', AMBER = 'hsl(40 92% 46%)';
const STEP = 64;
const OFF = [0, 46, 70, 46, 0, -46, -70, -46];

export default class AcademyLogic extends DCLogic {
  state = {
    ready: false, screen: 'splash', tab: 'learn', sub: null, p: null,
    lg: { email: '', pwd: '', show: false, remember: true, loading: false, err: '' },
    temp: null, first: null, onb: { step: 0 }, lesson: null, ex: null, fb: null, why: false, exitAsk: false,
    end: null, endAnim: { xp: 0, acc: 0 }, post: [], postItem: null, popNode: null, sheet: null, toasts: [], flyers: [], chest: null,
    weekResult: null, lbFilter: 'all', lbLoading: false, profTab: 'academy', gloss: '', leaderTab: 'units', ruleForm: null, qForm: null,
    flash: null, bannerUnit: 0, bannerFlip: true, justDone: null, now: Date.now(), loja: { busca: '', tier: 'todas', codigo: '' },
    online: true, resetAsk: false, bumpCoin: 0, bumpXp: 0, particles: 0, tempPwd: null, openRule: null, prof: null, homeLoading: false
  };
  frameRef = React.createRef(); repFileRef = React.createRef(); coinImgRef = React.createRef(); pathRef = React.createRef(); xpRef = React.createRef(); coinRef = React.createRef(); endXpRef = React.createRef();

  get E() { return window.AcademyEngine; }
  get C() { return window.ACADEMY_CFG; }

  defaults() {
    return {
      v: 1, session: null, remembered: '', users: {}, onboarded: false, persona: 'cs', objetivo: null, goalMin: 5, reminder: '09:30', workDays: [1, 2, 3, 4, 5], sound: true,
      role: 'lider', team: 'Suporte', name: '', phone: '', cargo: 'Analista de Suporte',
      xpTotal: 0, xpDay: {}, takitos: 120, streak: { count: 0, last: null, freezes: 1, grantWeek: null, days: [], best: 0 }, done: {}, activeTrack: 'FUN',
      league: { idx: 0, week: null, seed: 1, xp: 0 }, day: {}, month: {}, badges: [], certs: [], hl: {}, errors: {}, stats: { ans: 0, ok: 0 }, flashRecord: 0, boostUntil: 0,
      owned: ['m-bronze'], equipped: 'metal:bronze', dayOffset: 0, nudged: {}, offlineSim: false, levelTest: null,
      leader: { disabled: {}, mandatory: {}, rules: { Suporte: [{ id: 'r1', titulo: 'Modelo de resposta de impressão', descricao: 'Em chamados de impressão, use o modelo "Impressão · checklist" e adapte com o nome da loja e a impressora citada.', bom: 'Oi, Rafa! Vi que a impressora da cozinha parou. Vamos checar 3 pontos rapidinho: cabo, rede e o App de Impressão aberto.', ruim: 'Segue o procedimento padrão de impressão.', wiki: 'wiki/artigos/app-impressao.md', questions: [], published: false }] } }
    };
  }

  componentDidMount() {
    const go = () => {
      if (!(window.AcademyEngine && window.ACADEMY_CFG && window.ACADEMY_BANK && window.ACADEMY_ATD)) return setTimeout(go, 60);
      this.bank = window.ACADEMY_BANK; this.atd = window.ACADEMY_ATD;
      const demo = new URLSearchParams(location.search).get('demo');
      if (demo) return this.startDemo(demo);
      let saved = null; try { saved = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) {}
      const d = this.defaults();
      const p = Object.assign(d, saved || {});
      p.leader = Object.assign(d.leader, p.leader || {});
      this._p = p;
      this.setState({ ready: true, p, online: navigator.onLine, lg: Object.assign({}, this.state.lg, { email: p.remembered || '' }) });
      setTimeout(() => {
        // Só entra direto se ainda houver sessão válida do TakeatHub (funciona offline: a sessão fica no aparelho).
        Hub.supabase.auth.getSession().then(({ data }) => {
          const q = this._p, ok = !!(q.session && data && data.session && (!q.uid || data.session.user.id === q.uid));
          if (!ok && q.session) this.upd(x => { x.session = null; });
          const scr = ok ? (q.onboarded ? 'app' : 'onb') : 'login';
          this.setState({ screen: scr }, () => { if (scr === 'app') this.enterApp(); });
        }).catch(() => this.setState({ screen: 'login' }));
      }, 1700);
    };
    go();
    this.onOn = () => { this.setState({ online: true }); this.flushReports(); }; this.onOff = () => this.setState({ online: false });
    window.addEventListener('online', this.onOn); window.addEventListener('offline', this.onOff);
    this.iv = setInterval(() => this.tick(), 500);
    setTimeout(() => this.flushReports(), 2500);
  }
  componentWillUnmount() { clearInterval(this.iv); window.removeEventListener('online', this.onOn); window.removeEventListener('offline', this.onOff); }

  tick() {
    const s = this.state;
    if (s.screen === 'flash' && s.flash && !s.flash.done) { if (Date.now() >= s.flash.end) this.finishFlash(); else this.setState({ now: Date.now() }); return; }
    if (s.screen === 'lesson' && s.lesson && s.lesson.timed && !s.fb && !s.lesson.tipOpen) {
      if (Date.now() - s.lesson.qStart >= 30000) this.resolve(false, true); else this.setState({ now: Date.now() });
      return;
    }
    if (s.screen === 'app' && Date.now() - s.now > 20000) this.setState({ now: Date.now() });
  }

  // ---------- modo demonstração (canvas de fluxo): ?demo=<estado>, sem persistir ----------
  startDemo(demo) {
    this.demo = true;
    const p = this.defaults(), em = 'ana.prado@takeat.app';
    p.session = demo === 'loading' || demo === 'path' ? { email: em } : null; p.name = 'Ana Prado'; p.onboarded = demo === 'loading' || demo === 'path';
    this._p = p;
    const lg = Object.assign({}, this.state.lg, { email: /^(login|splash)$/.test(demo) ? '' : em, pwd: /^(loginErr|first)$/.test(demo) ? 'academy12' : '' });
    const st = { ready: true, p, online: true, lg };
    const m = demo.match(/^onb(\d)$/);
    if (demo === 'splash') st.screen = 'splash';
    else if (demo === 'login') st.screen = 'login';
    else if (demo === 'loginErr') Object.assign(st, { screen: 'login', lg: Object.assign(lg, { err: 'E-mail ou senha incorretos.' }) });
    else if (demo === 'temp') Object.assign(st, { screen: 'login', temp: { step: 'form', err: '' } });
    else if (demo === 'tempSent') Object.assign(st, { screen: 'login', temp: { step: 'sent', nome: 'Ana Prado', masc: '(27) •••••-4821', pwd: 'TK-7316' } });
    else if (demo === 'first') Object.assign(st, { screen: 'login', first: { email: em, pwd: 'segredo', pwd2: 'segredo', team: 'Suporte', birth: '10/04/1995', err: '' } });
    else if (m) { const n = +m[1]; st.screen = 'onb'; st.onb = { step: n, persona: 'cs', objetivo: n >= 1 ? 'chegando' : null, goalMin: n >= 2 ? 5 : null, nivel: n >= 3 ? 'basico' : null, reminder: '09:30' }; if (n === 0) st.onb.persona = 'cs'; }
    else if (demo === 'loading') Object.assign(st, { screen: 'app', tab: 'learn', homeLoading: true });
    else Object.assign(st, { screen: 'app', tab: 'learn' });
    this.setState(st, () => { if (demo === 'path') setTimeout(() => this.scrollToCurrent(false), 300); });
  }

  dd(id, label, opts) {
    const open = this.state.dd === id;
    return { label, open, toggle: e => { if (e && e.stopPropagation) e.stopPropagation(); this.setState({ dd: open ? null : id }); },
      items: opts.map(o => ({ t: o.t, sel: !!o.sel, dot: o.dot || 'transparent', bg: o.sel ? REDT : 'transparent', fg: o.sel ? RED : INK, fw: o.sel ? 600 : 500, onClick: e => { if (e && e.stopPropagation) e.stopPropagation(); this.setState({ dd: null }); o.onPick(); } })) };
  }
  timeVals(cur, set) {
    const [hh, mm] = String(cur || '09:30').split(':').map(Number), z = n => String(n).padStart(2, '0');
    const typed = (part) => e => { const d = e.target.value.replace(/\D/g, '').slice(-2); let n = d === '' ? 0 : +d; n = part === 'h' ? Math.min(23, n) : Math.min(59, n); set(part === 'h' ? z(n) + ':' + z(mm) : z(hh) + ':' + z(n)); };
    const mk = (H, M) => set(z((H + 24) % 24) + ':' + z((M + 60) % 60));
    return { onH: typed('h'), onM: typed('m'), focus: e => e.target.select(), hh: z(hh), mm: z(mm), hUp: () => mk(hh + 1, mm), hDown: () => mk(hh - 1, mm), mUp: () => mk(hh, mm + 5 - (mm % 5)), mDown: () => mk(hh, mm % 5 ? mm - (mm % 5) : mm - 5) };
  }

  // ---------- persistência ----------
  save(p) { this._p = p; this.setState({ p }); if (this.demo) return; try { localStorage.setItem(LS, JSON.stringify(p)); } catch (e) {} }
  upd(fn) { const p = JSON.parse(JSON.stringify(this._p)); const r = fn(p); this.save(p); return r; }
  today() { return new Date(Date.now() + ((this._p && this._p.dayOffset) || 0) * this.E.DAY); }
  tk() { return this.E.dkey(this.today()); }
  addXp(p, n) {
    if (n <= 0) return 0;
    if (Date.now() < p.boostUntil) n *= 2;
    const k = this.tk(); p.xpTotal += n; p.xpDay[k] = (p.xpDay[k] || 0) + n; p.league.xp += n; this.E.dayRec(p, k).xp += n;
    return n;
  }
  checkMissions(p) {
    const k = this.tk(), dr = this.E.dayRec(p, k), got = [];
    this.E.missionsFor(this.C, k).forEach(m => { if (!dr.claimed[m.k] && (dr[m.m] || 0) >= m.meta) { dr.claimed[m.k] = true; p.takitos += this.C.MISSION_REWARD; got.push(m); } });
    return got;
  }
  units(tid) { return this.E.getUnits(this.C, this.bank, this.atd, this._p, tid || this._p.activeTrack); }
  trackList() { return [{ id: 'ATD', nome: 'Regras de Atendimento · ' + this._p.team, icon: 'headset' }].concat(this.C.TRACKS); }
  trackInfo(id) { return this.trackList().find(t => t.id === id) || this.C.TRACKS[0]; }
  qById(id) {
    let q = this.bank.find(x => x.id === id) || this.atd.find(x => x.id === id);
    if (q) return q;
    const rules = this._p.leader.rules; Object.keys(rules).forEach(t => rules[t].forEach(r => r.questions.forEach(x => { if (x.id === id) q = x; })));
    return q;
  }
  isLeader() { return ['lider', 'admin', 'master'].indexOf(this._p.role) >= 0; }
  toast(text, icon, tone) {
    const id = Math.random().toString(36).slice(2);
    this.setState(s => ({ toasts: s.toasts.concat([{ id, text, icon: icon || 'circle-check', fg: tone === 'err' ? RED : tone === 'gold' ? 'hsl(32 82% 40%)' : GREEN }]).slice(-3) }));
    setTimeout(() => this.setState(s => ({ toasts: s.toasts.filter(t => t.id !== id) })), 2800);
  }
  beep(kind) {
    if (!this._p || !this._p.sound) return;
    try {
      const ctx = this.ac || (this.ac = new (window.AudioContext || window.webkitAudioContext)());
      const seq = kind === 'ok' ? [[660, 0], [880, .09]] : kind === 'err' ? [[240, 0], [190, .13]] : kind === 'tap' ? [[520, 0]] : [[523, 0], [659, .1], [784, .2], [1046, .32]];
      seq.forEach(([f, t]) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f; const t0 = ctx.currentTime + t; g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(.14, t0 + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + .2); o.connect(g); g.connect(ctx.destination); o.start(t0); o.stop(t0 + .22); });
    } catch (e) {}
  }

  // ---------- voo de moedas / XP ----------
  center(el) { const f = this.frameRef.current; if (!f || !el) return null; const a = f.getBoundingClientRect(), b = el.getBoundingClientRect(); return { x: b.left - a.left + b.width / 2, y: b.top - a.top + b.height / 2 }; }
  fly(kind, from, n) {
    const to = this.center(kind === 'coin' ? (this.coinImgRef.current || this.coinRef.current) : this.xpRef.current); if (!to || !from) return;
    const items = []; for (let i = 0; i < n; i++) items.push({ id: Math.random().toString(36).slice(2), kind, x: from.x + (i - n / 2) * 8, y: from.y, dx: to.x - from.x - (i - n / 2) * 8, dy: to.y - from.y, delay: i * 60 });
    this.setState(s => ({ flyers: s.flyers.concat(items) }));
    setTimeout(() => this.setState(kind === 'coin' ? { bumpCoin: Date.now() } : { bumpXp: Date.now() }), 700 + (n - 1) * 60);
    setTimeout(() => this.setState(s => ({ flyers: s.flyers.filter(f => !items.includes(f)) })), 1100 + n * 60);
  }
  frameCenter() { const f = this.frameRef.current; return f ? { x: f.clientWidth / 2, y: f.clientHeight / 2 } : { x: 195, y: 420 }; }

  // ---------- navegação ----------
  enterApp() { this.checkWeek(); this.setState({ homeLoading: true }); setTimeout(() => { this.setState({ homeLoading: false }); this.scrollToCurrent(true); }, 450); }
  goApp(extra) {
    this.setState(Object.assign({ screen: 'app', tab: 'learn', sub: null, lesson: null, ex: null, fb: null, why: false, end: null, postItem: null }, extra || {}), () => this.scrollToCurrent(true));
    if (this.pendingToasts) { this.pendingToasts.forEach((m, i) => setTimeout(() => { this.toast('Missão concluída: ' + m.t + ' · +' + this.C.MISSION_REWARD + ' Takitos', 'target', 'gold'); this.fly('coin', this.frameCenter(), 3); }, 500 + i * 900)); this.pendingToasts = null; }
    if (extra && extra.justDone) setTimeout(() => this.setState({ justDone: null }), 1600);
  }
  setTab(t) { this.setState({ tab: t, sub: null, popNode: null }, () => { if (t === 'learn') this.scrollToCurrent(false); }); if (t === 'league') { this.setState({ lbLoading: true }); setTimeout(() => this.setState({ lbLoading: false }), 550); } }
  scrollToCurrent(smooth) {
    setTimeout(() => {
      const c = this.pathRef.current; if (!c) return;
      const el = c.querySelector('[data-current="1"]');
      if (smooth) c.scrollTop = c.scrollHeight;
      if (!el) { this.updateBanner(); return; }
      const top = el.getBoundingClientRect().top - c.getBoundingClientRect().top + c.scrollTop - c.clientHeight * 0.45;
      c.scrollTo({ top, behavior: smooth ? 'smooth' : 'auto' });
      setTimeout(() => this.updateBanner(), smooth ? 500 : 30);
    }, 60);
  }
  updateBanner() {
    const c = this.pathRef.current; if (!c) return;
    const line = c.getBoundingClientRect().top + c.clientHeight * 0.55; let ui = null;
    c.querySelectorAll('[data-ui]').forEach(sec => { const r = sec.getBoundingClientRect(); if (r.top <= line && r.bottom > line) ui = +sec.getAttribute('data-ui'); });
    const secs = c.querySelectorAll('[data-ui]');
    if (secs.length && c.scrollTop + c.clientHeight >= c.scrollHeight - 140) ui = +secs[secs.length - 1].getAttribute('data-ui');
    if (ui === null && secs.length) ui = +secs[secs.length - 1].getAttribute('data-ui');
    if (ui !== null && ui !== this.state.bannerUnit) this.setState(s => ({ bannerUnit: ui, bannerFlip: !s.bannerFlip }));
  }

  // ---------- login ----------
  doLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const { email, pwd, remember } = this.state.lg; const em = email.trim().toLowerCase();
    if (this.state.lg.loading) return;
    if (!em || em.indexOf('@') < 0 || !pwd) { this.setState({ lg: Object.assign({}, this.state.lg, { err: 'Digite seu e-mail e senha.' }) }); return; }
    this.setState({ lg: Object.assign({}, this.state.lg, { loading: true, err: '' }) });
    // Validado no TakeatHub (Supabase do HubProduto) — mesmo fluxo do Login.tsx.
    Hub.entrar(em, pwd).then(r => {
      if (r.erro) { this.setState({ lg: Object.assign({}, this.state.lg, { loading: false, err: r.erro }) }); this.toast(r.erro, 'circle-x', 'err'); return; }
      const pf = r.perfil, uid = r.user.id;
      // O progresso local é por pessoa: outro usuário no mesmo aparelho começa do zero.
      if (this._p.uid && this._p.uid !== uid) this._p = Object.assign(this.defaults(), { remembered: this._p.remembered });
      this.upd(p => {
        p.uid = uid; p.remembered = remember ? em : ''; p.role = r.role;
        p.name = pf.full_name || this.E.nameFromEmail(em); if (pf.team) p.team = pf.team; if (pf.cargo) p.cargo = pf.cargo; if (pf.telefone) p.phone = pf.telefone;
      });
      this.setState({ lg: Object.assign({}, this.state.lg, { loading: false, pwd: '' }) });
      if (pf.force_password_change) this.setState({ first: { uid, email: em, pwd: '', pwd2: '', team: pf.team || this._p.team || 'Suporte', teamDefinida: !!(pf.team && pf.team.trim()), birth: '', err: '' } });
      else this.loginDone(em);
    }).catch(() => this.setState({ lg: Object.assign({}, this.state.lg, { loading: false, err: 'Erro inesperado. Tente novamente.' }) }));
  }
  loginDone(em) {
    this.upd(p => { p.session = { email: em }; p.name = p.name || this.E.nameFromEmail(em); });
    const scr = this._p.onboarded ? 'app' : 'onb';
    this.setState({ screen: scr, first: null, temp: null }, () => { if (scr === 'app') this.enterApp(); });
  }
  saveFirst() {
    const f = this.state.first; if (f.saving) return;
    const ep = Hub.erroSenha(f.pwd);
    if (ep) return this.setState({ first: Object.assign({}, f, { err: ep }) });
    if (f.pwd !== f.pwd2) return this.setState({ first: Object.assign({}, f, { err: 'As senhas não coincidem.' }) });
    const m = f.birth.match(/^(\d{2})\/(\d{2})\/(\d{4})$/), iso = m ? m[3] + '-' + m[2] + '-' + m[1] : '';
    if (!m || isNaN(new Date(iso).getTime())) return this.setState({ first: Object.assign({}, f, { err: 'Informe a data de nascimento no formato dd/mm/aaaa.' }) });
    this.setState({ first: Object.assign({}, f, { saving: true, err: '' }) });
    Hub.salvarPrimeiroAcesso(f.uid, { pwd: f.pwd, team: f.team, birthIso: iso, teamDefinida: f.teamDefinida }).then(r => {
      if (r.erro) return this.setState({ first: Object.assign({}, this.state.first, { saving: false, err: r.erro }) });
      this.upd(p => { if (!f.teamDefinida) p.team = f.team; });
      this.toast('Senha definida. Bem-vindo ao Academy!');
      this.loginDone(f.email);
    });
  }
  genTemp(e) {
    if (e && e.preventDefault) e.preventDefault();
    const em = this.state.lg.email.trim().toLowerCase();
    if (!em || em.indexOf('@') < 0) return this.setState({ temp: { step: 'form', err: 'Digite um e-mail válido.' } });
    this.setState({ temp: { step: 'form', loading: true, err: '' } });
    // Senha temporária entregue no WhatsApp pela Hubia (edge reset-password, autoatendimento).
    Hub.gerarSenhaTemporaria(em).then(r => {
      if (r.erro) return this.setState({ temp: { step: 'form', err: r.erro } });
      this.setState({ temp: { step: 'sent', nome: r.nome, masc: r.masc } });
    });
  }

  // ---------- onboarding ----------
  onbSet(k, v) { this.setState(s => ({ onb: Object.assign({}, s.onb, { [k]: v }) })); this.beep('tap'); }
  onbNext() {
    const o = this.state.onb;
    if (o.step < 4) return this.setState({ onb: Object.assign({}, o, { step: o.step + 1 }) });
    const per = this.C.PERSONAS.find(x => x.id === o.persona) || this.C.PERSONAS[0];
    this.upd(p => { p.persona = per.id; p.objetivo = o.objetivo; p.goalMin = o.goalMin; p.reminder = o.reminder || p.reminder; p.onboarded = true; p.activeTrack = per.order[0]; });
    if (o.nivel === 'teste') {
      const pool = this.E.shuffle(this.units(per.order[0])[0].qs.concat(this.units(per.order[1] || 'OPE')[0].qs)).slice(0, 8);
      this.beginLesson({ mode: 'placement', tid: per.order[0], key: null, ui: 0, qs: pool, title: 'Teste de nivelamento' });
    } else { this.setState({ screen: 'app', tab: 'learn' }, () => this.enterApp()); }
  }

  // ---------- lição ----------
  startNode(key) {
    const tid = key.split(':')[0], units = this.units(tid), nd = this.E.flat(units).find(n => n.key === key), u = units[nd.ui];
    this.setState({ popNode: null });
    if (nd.type === 'bau') return this.openChest('path', key);
    let qs, mode = nd.type, timed = false; const sh = this.E.shuffle;
    if (mode === 'licao') { qs = sh(nd.qs); if (qs.length < 6) qs = qs.concat(sh(this.E.flat([]).concat([].concat.apply([], units.slice(0, nd.ui + 1).map(x => x.qs))).filter(q => nd.qs.indexOf(q) < 0)).slice(0, 6 - qs.length)); qs = qs.slice(0, 10); }
    else if (mode === 'checkpoint') { qs = sh(u.qs).slice(0, 8); if (qs.length < 6) qs = qs.concat(sh([].concat.apply([], units.map(x => x.qs)).filter(q => qs.indexOf(q) < 0)).slice(0, 6 - qs.length)); }
    else if (mode === 'caso') qs = nd.qs.slice();
    else if (mode === 'mestre') { qs = sh(nd.qs).slice(0, 10); timed = true; }
    this.beginLesson({ mode, tid, key, ui: nd.ui, qs, title: nd.title, timed });
  }
  skipTest(tid, ui) { const u = this.units(tid)[ui]; this.setState({ popNode: null }); this.beginLesson({ mode: 'skip', tid, key: null, ui, qs: this.E.shuffle(u.qs).slice(0, 8), title: 'Teste para pular · ' + u.title }); }
  beginLesson(c) {
    const tip = c.mode === 'licao' ? c.qs.find(q => !this._p.hl[q.id]) : null;
    const L = Object.assign({ queue: c.qs.slice(), idx: 0, total: c.qs.length, solved: 0, wrong: {}, combo: 0, maxCombo: 0, comboBonus: 0, correctFirst: 0, t0: Date.now(), qStart: Date.now(), tip: tip || null, tipOpen: !!tip }, c);
    this.setState({ screen: 'lesson', lesson: L, ex: this.makeEx(L.queue[0]), fb: null, why: false, exitAsk: false, sheet: null });
  }
  makeEx(q) {
    const E = this.E, ex = { sel: null, num: '' }, t = q.tipo;
    if (E.numericAnswer(q)) ex.numeric = true;
    if (E.OPT_TYPES.indexOf(t) >= 0) ex.opts = t === 'verdadeiro_falso' ? ['Verdadeiro', 'Falso'] : E.shuffle(q.opcoes);
    if (t === 'ordenar_passos') { let o = E.shuffle(q.opcoes); if (JSON.stringify(o) === JSON.stringify(q.resposta)) o = o.slice().reverse(); ex.order = o; ex.drag = null; }
    if (t === 'combinar_pares') { ex.left = E.shuffle(q.opcoes.esquerda); ex.right = E.shuffle(Array.from(new Set(q.opcoes.direita))); ex.mL = {}; ex.mR = {}; ex.selL = null; ex.selR = null; ex.mistakes = 0; ex.bad = null; }
    if (t === 'onde_fica') { ex.tree = E.buildTree(q.opcoes); ex.path = []; }
    return ex;
  }
  setEx(patch) { this.setState(s => ({ ex: Object.assign({}, s.ex, patch) })); }
  correctText(q) {
    if (q.tipo === 'ordenar_passos') return q.resposta.map((x, i) => (i + 1) + '. ' + x).join('\n');
    if (q.tipo === 'combinar_pares') return Object.keys(q.resposta).map(a => a + ' → ' + q.resposta[a]).join('\n');
    return q.resposta;
  }
  check() {
    const { lesson: L, ex, fb } = this.state; if (fb || !L) return;
    const q = L.queue[L.idx], t = q.tipo; let ok;
    if (t === 'ordenar_passos') ok = JSON.stringify(ex.order) === JSON.stringify(q.resposta);
    else if (t === 'combinar_pares') ok = ex.mistakes === 0;
    else if (ex.numeric) ok = this.E.digits(ex.num).length > 0 && this.E.digits(ex.num) === this.E.digits(q.resposta);
    else ok = ex.sel === q.resposta;
    this.resolve(ok, false);
  }
  resolve(ok, timeout) {
    const L = Object.assign({}, this.state.lesson), q = L.queue[L.idx], E = this.E;
    this.upd(p => {
      p.stats.ans++; if (ok) p.stats.ok++;
      const h0 = (p.hl[q.id] && p.hl[q.id].h) || 1; p.hl[q.id] = { h: ok ? Math.min(64, h0 * 2) : Math.max(.25, h0 / 2), t: this.today().getTime() };
      if (ok) { if ((L.mode === 'errors' || L.mode === 'review') && p.errors[q.id]) { delete p.errors[q.id]; E.dayRec(p, this.tk()).reviews++; } }
      else p.errors[q.id] = true;
    });
    L.wrong = Object.assign({}, L.wrong);
    if (ok) { L.combo++; L.maxCombo = Math.max(L.maxCombo, L.combo); if (L.combo >= 5) L.comboBonus++; L.solved++; if (!L.wrong[q.id]) L.correctFirst++; }
    else { L.combo = 0; L.wrong[q.id] = true; if (E.NOREQ.indexOf(L.mode) < 0) L.queue = L.queue.concat([q]); }
    this.beep(ok ? 'ok' : 'err');
    this.setState({ lesson: L, fb: { ok, correct: this.correctText(q), timeout } });
  }
  nextQ() {
    const L = Object.assign({}, this.state.lesson); L.idx++;
    if (L.idx >= L.queue.length) return this.finish(L);
    L.qStart = Date.now();
    this.setState({ lesson: L, ex: this.makeEx(L.queue[L.idx]), fb: null, why: false });
  }
  ordDown(i, e) { if (this.state.fb) return; try { e.currentTarget.setPointerCapture(e.pointerId); } catch (x) {} this.drag = { i, y0: e.clientY, dy: 0 }; this.setEx({ drag: { i, dy: 0 } }); }
  ordMove(e) { if (!this.drag) return; this.drag.dy = e.clientY - this.drag.y0; this.setEx({ drag: { i: this.drag.i, dy: this.drag.dy } }); }
  ordUp() {
    if (!this.drag) return; const { i, dy } = this.drag; this.drag = null;
    const o = this.state.ex.order.slice(), to = Math.max(0, Math.min(o.length - 1, i + Math.round(dy / STEP)));
    const m = o.splice(i, 1)[0]; o.splice(to, 0, m); this.setEx({ order: o, drag: null });
  }
  tapPair(side, v) {
    const ex = this.state.ex, q = this.state.lesson.queue[this.state.lesson.idx]; if (this.state.fb) return;
    if (side === 'l' && ex.mL[v]) return; if (side === 'r' && ex.mR[v]) return;
    const selL = side === 'l' ? v : ex.selL, selR = side === 'r' ? v : ex.selR;
    if (!selL || !selR) { this.beep('tap'); return this.setEx({ selL, selR }); }
    if (q.resposta[selL] === selR) {
      const mL = Object.assign({}, ex.mL, { [selL]: true }), mR = Object.assign({}, ex.mR);
      if (Object.keys(q.resposta).filter(k => q.resposta[k] === selR).every(k => mL[k])) mR[selR] = true;
      this.beep('ok'); this.setEx({ mL, mR, selL: null, selR: null });
      if (ex.left.every(l => mL[l])) setTimeout(() => this.check(), 420);
    } else {
      this.beep('err'); this.setEx({ mistakes: ex.mistakes + 1, bad: { l: selL, r: selR }, selL: null, selR: null });
      setTimeout(() => this.setEx({ bad: null }), 420);
    }
  }
  openWhy() { this.setState({ why: true }); this.upd(p => { this.E.dayRec(p, this.tk()).whys++; }); }

  finish(L) {
    const E = this.E, C = this.C, wrongN = Object.keys(L.wrong).length, acc = Math.round(L.correctFirst / L.total * 100), perfect = wrongN === 0;
    const dur = Math.round((Date.now() - L.t0) / 1000);
    let xp = 0, pass = true;
    if (L.mode === 'licao' || L.mode === 'caso') xp = 10 + (perfect ? 5 : 0);
    else if (L.mode === 'checkpoint') xp = 20;
    else if (L.mode === 'mestre') { pass = acc >= 80; xp = pass ? 40 : 10; }
    else if (L.mode === 'skip') { pass = acc >= 75; xp = pass ? 20 : 0; }
    else if (L.mode === 'placement') { pass = acc >= 75; xp = 0; }
    else xp = 5 + (perfect ? 3 : 0);
    xp += L.comboBonus;
    const before = E.conquests(this._p, { tracksDone: this.tracksDone() }).fams.map(f => f.level);
    const post = []; let gained = 0, missions = [];
    const units = L.tid ? this.units(L.tid) : [];
    this.upd(p => {
      const k = this.tk(), dr = E.dayRec(p, k), goal = E.goalXp(C, p), b4 = dr.xp;
      gained = this.addXp(p, xp);
      if (L.mode !== 'placement') { dr.lessons++; if (perfect) dr.perfect++; dr.maxCombo = Math.max(dr.maxCombo, L.maxCombo); const mk = k.slice(0, 7); p.month[mk] = (p.month[mk] || 0) + 1; }
      if (L.key && ['licao', 'caso', 'checkpoint'].indexOf(L.mode) >= 0) p.done[L.key] = true;
      if (L.mode === 'mestre' && pass) p.done[L.key] = true;
      if (L.mode === 'skip' && pass) units[L.ui].nodes.forEach(n => { p.done[n.key] = true; });
      if (L.mode === 'placement') { p.levelTest = acc; if (pass) { const per = C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]; per.order.slice(0, 2).forEach(t => this.E.getUnits(C, this.bank, this.atd, p, t)[0].nodes.forEach(n => { p.done[n.key] = true; })); } }
      if (L.mode === 'checkpoint') { const id = 'cp:' + L.tid + ':' + L.ui; if (!p.badges.find(b => b.id === id)) { const b = { id, nome: units[L.ui].title, sub: 'Checkpoint · ' + this.trackInfo(L.tid).nome, icon: 'award', g: 'linear-gradient(145deg,#FFD66B,#FF8A3D)' }; p.badges.push(b); post.push({ k: 'badge', b }); } }
      if (L.mode === 'mestre' && pass) { const c = { id: 'cert:' + L.tid, trilha: this.trackInfo(L.tid).nome, nome: p.name, data: this.today().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }), acc }; p.certs = p.certs.filter(x => x.id !== c.id).concat([c]); post.push({ k: 'cert', c }); }
      if (L.mode !== 'placement') { const st = E.extendStreak(p, this.today()); if (st) post.unshift(Object.assign({ k: 'streak' }, st)); }
      if (b4 < goal && dr.xp >= goal) post.push({ k: 'goal', goal });
      const mk = k.slice(0, 7);
      if ((p.month[mk] || 0) >= C.MONTH_GOAL && !p.badges.find(b => b.id === 'mes:' + mk)) { const b = { id: 'mes:' + mk, nome: 'Desafio do mês', sub: C.MONTH_GOAL + ' lições em ' + this.today().toLocaleDateString('pt-BR', { month: 'long' }), icon: 'target', g: 'linear-gradient(135deg,#FF2F6E,#A82743 55%,#5B1A8A)' }; p.badges.push(b); post.push({ k: 'badge', b }); }
      missions = this.checkMissions(p);
    });
    const after = E.conquests(this._p, { tracksDone: this.tracksDone() }).fams;
    after.forEach((f, i) => { if (f.level > before[i]) post.push({ k: 'badge', b: { nome: f.fam + ' · Nível ' + E.ROMAN[f.level], sub: f.levels[f.level - 1] + ' ' + f.un, icon: f.icon, g: 'linear-gradient(145deg,#7CC9FF,#5B6CFF)' } }); });
    this.pendingToasts = missions;
    this.setState({ screen: 'end', end: { xp: gained, acc, dur, perfect, combo: L.comboBonus, mode: L.mode, pass, title: L.title, key: L.key }, endAnim: { xp: 0, acc: 0 }, post, particles: Date.now(), lesson: null, ex: null, fb: null });
    this.beep('done');
    const t0 = performance.now(), run = now => { const k = Math.min(1, (now - t0) / 600), e = 1 - Math.pow(1 - k, 3); this.setState({ endAnim: { xp: Math.round(gained * e), acc: Math.round(acc * e) } }); if (k < 1) requestAnimationFrame(run); };
    requestAnimationFrame(run);
    if (gained > 0) setTimeout(() => this.fly('xp', this.center(this.endXpRef.current), 1), 720);
  }
  nextPost() {
    const post = this.state.post.slice();
    if (post.length) { const it = post.shift(); this.setState({ screen: 'post', postItem: it, post }); if (it.k === 'streak' && it.milestone) setTimeout(() => this.fly('coin', this.frameCenter(), 5), 900); return; }
    const key = this.state.end && this.state.end.key;
    this.goApp({ justDone: key || null });
  }
  tracksDone() { return this.trackList().filter(t => { const f = this.E.flat(this.units(t.id)); return f.length && f.every(n => this._p.done[n.key]); }).length; }

  // ---------- baú ----------
  openChest(source, key) {
    const r = Math.random(); let reward;
    if (r < .6) reward = { k: 'takitos', n: 10 + Math.floor(Math.random() * 3) * 10 };
    else if (r < .8) reward = this._p.streak.freezes < 2 ? { k: 'freeze' } : { k: 'takitos', n: 25 };
    else reward = { k: 'boost' };
    this.setState({ chest: { source, key, reward, at: Date.now() }, popNode: null });
  }
  collectChest() {
    const c = this.state.chest, rw = c.reward;
    this.upd(p => {
      if (rw.k === 'takitos') p.takitos += rw.n; else if (rw.k === 'freeze') p.streak.freezes = Math.min(2, p.streak.freezes + 1); else p.boostUntil = Date.now() + 15 * 60000;
      if (c.source === 'path') p.done[c.key] = true; else this.E.dayRec(p, this.tk()).chest = true;
    });
    this.setState({ chest: null, justDone: c.source === 'path' ? c.key : null });
    if (rw.k === 'takitos') setTimeout(() => this.fly('coin', this.frameCenter(), 5), 80);
    else this.toast(rw.k === 'freeze' ? 'Congelamento de ofensiva guardado' : 'XP em dobro ativo por 15 minutos', rw.k === 'freeze' ? 'snowflake' : 'zap', 'gold');
    if (c.source === 'path') setTimeout(() => this.setState({ justDone: null }), 1600);
  }

  // ---------- ligas ----------
  checkWeek() {
    const wk = this.E.dkey(this.E.monday(this.today()));
    if (!this._p.league.week) return this.upd(p => { p.league.week = wk; });
    if (this._p.league.week !== wk) this.endWeek();
  }
  endWeek() {
    const C = this.C, d = this.E.leagueData(C, this._p, this.today()), me = d.rows.find(r => r.me), n = d.rows.length, idx = this._p.league.idx;
    let to = idx, res = 'stay';
    if (me.rank <= C.LEAGUE_RULES.sobem && idx < C.LEAGUES.length - 1) { to = idx + 1; res = 'up'; }
    else if (me.rank > n - C.LEAGUE_RULES.descem && idx > 0) { to = idx - 1; res = 'down'; }
    const wk = this.E.dkey(this.E.monday(this.today()));
    this.upd(p => { p.league.idx = to; p.league.xp = 0; p.league.seed++; p.league.week = wk; if (res === 'up') p.takitos += C.LEAGUE_RULES.premioPromocao; });
    this.setState({ weekResult: { from: idx, to, res, rank: me.rank } });
  }

  // ---------- praticar ----------
  dueQs() {
    const now = this.today().getTime(), hl = this._p.hl;
    return Object.keys(hl).map(id => ({ id, pr: Math.pow(2, -((now - hl[id].t) / this.E.DAY) / hl[id].h) })).filter(x => x.pr < .5).sort((a, b) => a.pr - b.pr).map(x => this.qById(x.id)).filter(Boolean);
  }
  startPractice(mode, qs, title) {
    if (!qs.length) return this.toast(mode === 'errors' ? 'Nenhum erro para revisar. Mandou bem!' : 'Nada para revisar agora.', 'circle-check');
    this.beginLesson({ mode, tid: null, key: null, ui: 0, qs: this.E.shuffle(qs).slice(0, 8), title });
  }
  practiceTerm(term) {
    const t = term.toLowerCase();
    const qs = this.bank.filter(q => (q.enunciado + ' ' + JSON.stringify(q.opcoes)).toLowerCase().indexOf(t) >= 0);
    if (qs.length < 3) return this.toast('Ainda não há questões suficientes para "' + term + '".', 'search', 'err');
    this.startPractice('term', qs, 'Praticar · ' + term);
  }
  newBatch(f) { const g = this.C.GLOSSARY, items = []; for (let i = 0; i < 4; i++) items.push(g[(f.ptr + i) % g.length]); return Object.assign(f, { items, left: this.E.shuffle(items.map(x => x.t)), right: this.E.shuffle(items.map(x => x.s)), mL: {}, selL: null, selR: null, bad: null, ptr: f.ptr + 4 }); }
  startFlash() { const f = this.newBatch({ end: Date.now() + 60000, score: 0, ptr: Math.floor(Math.random() * 19), done: false }); this.setState({ screen: 'flash', flash: f }); }
  tapFlash(side, v) {
    const f = Object.assign({}, this.state.flash); if (f.done) return;
    if (side === 'l') { if (f.mL[v]) return; f.selL = v; } else { if (Object.values(f.mL).indexOf(v) >= 0) return; f.selR = v; }
    if (f.selL && f.selR) {
      const it = f.items.find(x => x.t === f.selL);
      if (it.s === f.selR) { f.mL = Object.assign({}, f.mL, { [f.selL]: f.selR }); f.score++; this.beep('ok'); if (Object.keys(f.mL).length === 4) setTimeout(() => this.setState(s => ({ flash: this.newBatch(Object.assign({}, s.flash)) })), 380); }
      else { f.bad = { l: f.selL, r: f.selR }; this.beep('err'); setTimeout(() => this.setState(s => ({ flash: Object.assign({}, s.flash, { bad: null }) })), 400); }
      f.selL = null; f.selR = null;
    } else this.beep('tap');
    this.setState({ flash: f });
  }
  finishFlash() {
    const f = this.state.flash, rec = f.score > this._p.flashRecord; let xp = 0, st = null;
    this.upd(p => { xp = this.addXp(p, Math.min(20, f.score)); if (rec) p.flashRecord = f.score; if (f.score > 0) st = this.E.extendStreak(p, this.today()); this.pendingToasts = this.checkMissions(p); });
    this.setState({ flash: Object.assign({}, f, { done: true, rec, xp }) });
    this.beep('done');
  }

  // ---------- líder ----------
  leaderUpd(fn) { this.upd(p => { const t = p.team; p.leader.rules[t] = p.leader.rules[t] || []; fn(p, t); }); }
  hubiaDraft(rule, tipo) {
    if (tipo === 'verdadeiro_falso') return { tipo, enunciado: 'Pela regra "' + rule.titulo + '": ' + rule.ruim.replace(/\.$/, '') + ' é uma resposta adequada.', opts: ['Verdadeiro', 'Falso', '', ''], correct: 1, explicacao: rule.descricao, hubia: true };
    return { tipo, enunciado: (tipo === 'diagnostico' ? 'Mensagem do atendente: "' + rule.ruim + '" O que essa mensagem viola?' : 'Um cliente traz um caso ligado a "' + rule.titulo + '". Qual resposta segue a regra do time?'),
      opts: tipo === 'diagnostico' ? ['A regra "' + rule.titulo + '"', 'Encerramento', 'CSAT', 'Nenhuma regra'] : [rule.bom, rule.ruim, 'Responder depois, sem avisar o cliente.', 'Encaminhar para outro time sem contexto.'], correct: 0, explicacao: rule.descricao, hubia: true };
  }
  addQuestion() {
    const f = this.state.qForm, vf = f.tipo === 'verdadeiro_falso';
    const opts = vf ? ['Verdadeiro', 'Falso'] : f.opts.map(x => x.trim()).filter(Boolean);
    if (!f.enunciado.trim() || opts.length < 2 || !opts[f.correct]) return this.toast('Preencha o enunciado, as alternativas e a correta.', 'triangle-alert', 'err');
    this.leaderUpd((p, t) => { const r = p.leader.rules[t].find(x => x.id === f.ruleId); r.questions.push({ id: r.id + '-q' + (r.questions.length + 1), trilha: 'Regras de Atendimento', unidade: r.titulo, licao: r.titulo, tipo: f.tipo, dificuldade: 4, enunciado: f.enunciado.trim(), opcoes: opts, resposta: opts[f.correct], explicacao: f.explicacao.trim() || r.descricao, fonte: r.wiki || 'Regra do time ' + t }); });
    this.setState({ qForm: null }); this.toast('Questão adicionada ao rascunho');
  }

  renderVals() {
    const s = this.state;
    const F = { frameRef: this.frameRef, isSplash: true, isLogin: false, isOnb: false, isApp: false, isLesson: false, isEnd: false, isPost: false, isFlash: false, showHeader: false, offlineBanner: false, tempOpen: false, firstOpen: false, sheetOpen: false, chestOpen: false, wrOpen: false, exitAsk: false, resetAsk: false, toasts: [], flyersEl: null, particlesEl: null, stopProp: e => e.stopPropagation(), closePop: () => { if (this.state.popNode) this.setState({ popNode: null }); } };
    if (!s.ready || !s.p) return F;
    const v = Object.assign(F, { isSplash: s.screen === 'splash', isLogin: s.screen === 'login', isOnb: s.screen === 'onb', isApp: s.screen === 'app', isLesson: s.screen === 'lesson', isEnd: s.screen === 'end', isPost: s.screen === 'post', isFlash: s.screen === 'flash' });
    v.showHeader = (s.screen === 'app' && !s.sub) || s.screen === 'end' || s.screen === 'post';
    v.offlineBanner = (!s.online || s.p.offlineSim) && s.screen === 'app';
    v.toasts = s.toasts; v.printCert = !!s.certView; if (s.certView) Object.assign(v, this.vCert());
    v.flyersEl = this.flyersEl(); v.particlesEl = this.particlesEl();
    Object.assign(v, this.vHeader(), this.vOverlays());
    if (v.isLogin) Object.assign(v, this.vLogin());
    if (v.isOnb) Object.assign(v, this.vOnb());
    if (v.isApp) Object.assign(v, this.vApp());
    if (v.isLesson) Object.assign(v, this.vLesson());
    if (v.isEnd) Object.assign(v, this.vEnd());
    if (v.isPost) Object.assign(v, this.vPost());
    if (v.isFlash) Object.assign(v, this.vFlash());
    return v;
  }

  flyersEl() {
    const h = React.createElement;
    return h('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 120 } }, this.state.flyers.map(f => h('div', { key: f.id, style: { position: 'absolute', left: f.x - 14, top: f.y - 14, '--dx': f.dx + 'px', animation: 'flyX .7s cubic-bezier(.45,0,.55,1) ' + f.delay + 'ms both' } },
      h('div', { style: { '--dy': f.dy + 'px', animation: 'flyY .7s cubic-bezier(.5,-0.9,.7,1) ' + f.delay + 'ms both' } },
        f.kind === 'coin' ? h('img', { src: './src/assets/takitos.png', width: 28, height: 28, style: { display: 'block', filter: 'drop-shadow(0 4px 8px rgba(0,0,0,.25))' } })
          : h('span', { style: { width: 30, height: 30, borderRadius: 10, background: AMBER, color: '#fff', display: 'grid', placeItems: 'center', boxShadow: '0 6px 14px hsl(40 92% 46% / .45)' } }, h('lu-icon', { name: 'zap', size: '18', fill: 'currentColor' }))))));
  }
  particlesEl() {
    if (!this.state.particles || (this.state.screen !== 'end')) return null;
    const h = React.createElement, cols = ['#ff2419', '#df1c0d', '#8f1109', 'hsl(40 92% 46%)', 'hsl(150 55% 40%)', 'hsl(212 72% 48%)', 'hsl(262 52% 55%)'], r = this.E.seeded(this.state.particles);
    const items = []; for (let i = 0; i < 34; i++) { const a = r() * Math.PI * 2, d = 90 + r() * 170; items.push(h('span', { key: i, style: { position: 'absolute', left: '50%', top: '30%', width: 6 + r() * 6, height: 10 + r() * 8, borderRadius: r() > .5 ? 999 : 2, background: cols[i % cols.length], '--px': Math.cos(a) * d + 'px', '--py': Math.sin(a) * d + 120 * r() + 'px', '--pr': (r() * 720 - 360) + 'deg', animation: 'particle 1.3s cubic-bezier(.16,1,.3,1) ' + (r() * 150) + 'ms both' } })); }
    return h('div', { key: this.state.particles, style: { position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden', zIndex: 5 } }, items);
  }
  num(v, ts) { return React.createElement('span', { key: 'n' + ts, style: { display: 'inline-block', animation: ts ? 'bump .45s cubic-bezier(.34,1.56,.64,1)' : 'none' } }, v); }

  vHeader() {
    const p = this._p, s = this.state, E = this.E, k = this.tk(), xpT = p.xpDay[k] || 0, goal = E.goalXp(this.C, p), sn = E.streakNow(p, this.today()), done = p.streak.last === k;
    const ti = this.trackInfo(p.activeTrack);
    return {
      trackIcon: ti.icon, trackShort: ({ ATD: 'Atendimento', FUN: 'Fundamentos', OPE: 'Operação', KDS: 'Cozinha', DEL: 'Delivery', GES: 'Gestor', CAN: 'Canais', DIS: 'Dispositivos', INT: 'Integrações', FIS: 'Fiscal', MUL: 'Multilojas', CLU: 'Clube', BAS: 'Bastidores' })[ti.id] || ti.nome,
      openTracks: () => this.setState({ sheet: 'tracks' }), openStreak: () => this.setState({ sheet: 'streak' }), openCoins: () => this.setState({ sheet: 'coins' }),
      streakN: sn, flameColor: done ? 'hsl(28 90% 52%)' : 'hsl(0 0% 62%)', flameFill: done ? 'hsl(40 92% 56%)' : 'none',
      xpRef: this.xpRef, coinRef: this.coinRef, coinImgRef: this.coinImgRef, xpNumEl: this.num(xpT, s.bumpXp), coinNumEl: this.num(p.takitos, s.bumpCoin),
      goalXp: goal, ringDash: Math.min(100, Math.round(xpT / goal * 100)) + ' 100', ringColor: xpT >= goal ? GREEN : AMBER, boostOn: Date.now() < p.boostUntil
    };
  }

  vLogin() {
    const lg = this.state.lg, set = (k) => (e) => this.setState({ lg: Object.assign({}, this.state.lg, { [k]: e.target.value, err: '' }) });
    return {
      lgEmail: lg.email, lgPwd: lg.pwd, onLgEmail: set('email'), onLgPwd: set('pwd'), lgPwdType: lg.show ? 'text' : 'password', lgEyeIcon: lg.show ? 'eye-off' : 'eye',
      toggleShow: () => this.setState({ lg: Object.assign({}, lg, { show: !lg.show }) }), lgRemember: lg.remember, toggleRemember: () => this.setState({ lg: Object.assign({}, lg, { remember: !lg.remember }) }),
      onLogin: e => this.doLogin(e), lgLoading: lg.loading, lgIdle: !lg.loading, hasLgErr: !!lg.err, lgErr: lg.err, onForgot: () => this.setState({ temp: { step: 'form', err: '' } }),
      onLgKey: e => { if (e.key === 'Enter') this.doLogin(e); }
    };
  }

  vOnb() {
    const o = this.state.onb, C = this.C;
    const card = (sel) => ({ bd: sel ? RED : BD, bg: sel ? REDT2 : '#fff', fg: sel ? RED : INK, tr: sel ? 'translateY(-2px) scale(1.02)' : 'none' });
    const can = [!!o.persona, !!o.objetivo, !!o.goalMin, !!o.nivel, true][o.step];
    return {
      onbPct: ((o.step + 1) / 5 * 100) + '%', onbCanBack: o.step > 0, onbDisabledBack: o.step === 0, onbBack: () => this.setState({ onb: Object.assign({}, o, { step: o.step - 1 }) }),
      onb0: o.step === 0, onb1: o.step === 1, onb2: o.step === 2, onb3: o.step === 3, onb4: o.step === 4,
      personasInt: C.PERSONAS.filter(x => x.grupo === 'Time Takeat').map(x => Object.assign({ nome: x.nome, icon: x.icon, onClick: () => this.onbSet('persona', x.id) }, card(o.persona === x.id))),
      personasCli: C.PERSONAS.filter(x => x.grupo === 'Restaurante').map(x => Object.assign({ nome: x.nome, icon: x.icon, onClick: () => this.onbSet('persona', x.id) }, card(o.persona === x.id))),
      objetivos: C.OBJETIVOS.map(x => Object.assign({ t: x.t, d: x.d, onClick: () => this.onbSet('objetivo', x.id) }, card(o.objetivo === x.id))),
      goals: C.GOALS.map(x => Object.assign({ t: x.min + ' min por dia', d: x.t, xp: x.xp + ' XP', onClick: () => this.onbSet('goalMin', x.min) }, card(o.goalMin === x.min))),
      niveis: [{ id: 'basico', t: 'Começar do básico', d: 'Sigo a trilha desde a primeira lição.', icon: 'sprout' }, { id: 'teste', t: 'Fazer o teste rápido', d: '8 questões. Com 75% ou mais, as unidades básicas ficam concluídas.', icon: 'gauge' }].map(x => Object.assign({ t: x.t, d: x.d, icon: x.icon, onClick: () => this.onbSet('nivel', x.id) }, card(o.nivel === x.id))),
      reminders: C.REMINDERS.slice(0, 4).map(r => { const sel = !o.custom && (o.reminder || '09:30') === r; return { t: r, onClick: () => this.setState(s => ({ onb: Object.assign({}, s.onb, { reminder: r, custom: false }) })), bg: sel ? RED : '#fff', fg: sel ? '#fff' : MUT, bd: sel ? RED : BD }; }),
      onbCustom: !!o.custom, onbCustomBg: o.custom ? RED : '#fff', onbCustomFg: o.custom ? '#fff' : MUT, onbCustomBd: o.custom ? RED : BD, onOnbCustom: () => this.setState(s => ({ onb: Object.assign({}, s.onb, { custom: true, reminder: s.onb.reminder || '09:30' }) })),
      onbTime: this.timeVals(o.reminder || '09:30', v => this.setState(s => ({ onb: Object.assign({}, s.onb, { reminder: v }) }))),
      onbNext: () => this.onbNext(), onbDisabled: !can, onbBtnBg: can ? RED : 'hsl(0 0% 88%)', onbBtnFg: can ? '#fff' : 'hsl(0 0% 62%)', onbBtnSh: can ? '0 4px 0 hsl(6 100% 34%)' : '0 4px 0 hsl(0 0% 80%)',
      onbNextLabel: o.step === 4 ? (o.nivel === 'teste' ? 'Começar o teste' : 'Começar a trilha') : 'Continuar',
      onAllowNotif: () => { try { window.Notification && Notification.requestPermission(); } catch (e) {} this.toast('Lembrete combinado para ' + (o.reminder || '09:30'), 'bell'); }
    };
  }

  vApp() {
    const s = this.state, p = this._p, t = s.tab;
    const tabs = [['learn', 'Aprender', 'book-open'], ['practice', 'Praticar', 'dumbbell'], ['league', 'Ligas', 'trophy'], ['missions', 'Missões', 'target'], ['profile', 'Perfil', 'user']].map(([id, label, icon]) => ({ label, icon, onClick: () => this.setTab(id), fg: t === id ? RED : MUT, bg: t === id ? REDT : 'transparent', fw: t === id ? 700 : 500 }));
    const v = { tabs, isTabs: !s.sub, isSub: !!s.sub, tabLearn: t === 'learn' && !s.sub, tabPractice: t === 'practice' && !s.sub, tabLeague: t === 'league' && !s.sub, tabMissions: t === 'missions' && !s.sub, tabProfile: t === 'profile' && !s.sub,
      subLoja: s.sub === 'loja', subGloss: s.sub === 'gloss', subLeader: s.sub === 'leader', subResgate: s.sub === 'resgate', subCert: s.sub === 'cert', subReports: s.sub === 'reports', subReportView: s.sub === 'reportView', subTitle: { reportView: 'Feedback', reports: 'Meus feedbacks', loja: 'Loja', gloss: 'Glossário', leader: 'Modo líder', resgate: 'Resgatar código', cert: 'Certificado' }[s.sub] || '', subCrumb: { reportView: 'Perfil / Meus feedbacks', reports: 'Perfil / Feedback', loja: 'Hub / Loja', gloss: 'Praticar / Glossário', leader: 'Atendimento / ' + p.team, resgate: 'Hub / Loja', cert: 'Perfil / Certificados' }[s.sub] || '', subIcon: { reportView: 'message-square-text', reports: 'message-square-text', loja: 'store', gloss: 'book-text', leader: 'shield', resgate: 'gift', cert: 'file-badge' }[s.sub] || 'store', onSubBack: () => { if (s.sub === 'reportView') return this.setState({ sub: 'reports', repLight: null }); if (s.sub === 'cert' && s.certFrom === 'post') return this.setState({ screen: 'post', sub: null, certFull: false }); this.setState({ sub: s.sub === 'resgate' ? 'loja' : null, certFull: false }); } };
    if (v.tabLearn) Object.assign(v, this.vLearn());
    if (v.tabPractice) Object.assign(v, this.vPractice());
    if (v.tabLeague) Object.assign(v, this.vLeague());
    if (v.tabMissions) Object.assign(v, this.vMissions());
    if (v.tabProfile) Object.assign(v, this.vProfile());
    if (v.subLoja) Object.assign(v, this.vLoja());
    if (v.subGloss) Object.assign(v, this.vGloss());
    if (v.subLeader) Object.assign(v, this.vLeader());
    if (v.subResgate) Object.assign(v, this.vResgate());
    if (v.subCert) Object.assign(v, this.vCert());
    if (v.subReports) Object.assign(v, this.vReports());
    if (v.subReportView) Object.assign(v, this.vReportView());
    return v;
  }

  vLearn() {
    const s = this.state, p = this._p, E = this.E, tid = p.activeTrack, units = this.units(tid), flat = E.flat(units), curI = flat.findIndex(n => !p.done[n.key]);
    const COLOR = { licao: [RED, 'hsl(6 100% 34%)'], caso: [RED, 'hsl(6 100% 34%)'], bau: [AMBER, 'hsl(36 90% 34%)'], checkpoint: [AMBER, 'hsl(36 90% 34%)'], mestre: ['#8f1109', '#560803'] };
    const ICON = { licao: 'book-open', bau: 'gift', caso: 'message-square', checkpoint: 'award', mestre: 'trophy' };
    const uv = units.map(u => {
      const unitDone = u.nodes.every(n => p.done[n.key]), first = flat.indexOf(u.nodes[0]), locked = curI >= 0 && first > curI;
      const rows = u.nodes.map((n, ni) => {
        const gi = flat.indexOf(n), done = !!p.done[n.key], cur = gi === curI, lockedN = !done && !cur, x = OFF[ni % 8], cx = Math.max(-58, Math.min(58, x));
        const [col, dark] = COLOR[n.type], open = s.popNode === n.key;
        const nEx = n.type === 'licao' ? Math.min(10, Math.max(6, n.qs.length)) : n.type === 'checkpoint' ? Math.min(8, Math.max(6, n.qs.length)) : n.type === 'mestre' ? 10 : n.type === 'caso' ? n.qs.length : 0;
        const popSub = n.type === 'bau' ? 'Abra para ganhar uma recompensa' : n.type === 'mestre' ? nEx + ' exercícios · 30 s cada · sem dicas · +40 XP' : nEx + ' exercícios · +' + E.NODE_XP[n.type] + ' XP';
        return {
          key: n.key, dc: cur ? '1' : '0', left: 'calc(50% + ' + x + 'px - 34px)', isCur: cur, notCur: !cur,
          bg: lockedN ? 'hsl(0 0% 90%)' : done && n.type === 'bau' ? 'hsl(40 70% 90%)' : col, sh: '0 6px 0 ' + (lockedN ? 'hsl(0 0% 80%)' : done && n.type === 'bau' ? 'hsl(40 50% 76%)' : dark), fg: lockedN ? 'hsl(0 0% 62%)' : done && n.type === 'bau' ? 'hsl(36 75% 42%)' : '#fff',
          icon: done ? (n.type === 'bau' ? 'package-open' : 'check') : ICON[n.type], anim: n.key === s.justDone ? 'nodePop .55s cubic-bezier(.34,1.56,.64,1)' : (cur && s.justDone ? 'flipIn .6s .4s cubic-bezier(.16,1,.3,1) both' : 'none'),
          onClick: e => { e.stopPropagation(); if (open) return this.setState({ popNode: null }); this.openPop(n.key, e.currentTarget, ni === 0 && !unitDone && !done); }, z: open ? 40 : 'auto', hasLine: ni > 0,
          popPos: open && s.popUp ? 'bottom:94px' : 'top:92px', caretPos: open && s.popUp ? 'bottom:-7px' : 'top:-7px', popOrigin: open && s.popUp ? 'bottom center' : 'top center',
          skipBg: lockedN ? 'hsl(0 0% 95%)' : 'rgba(255,255,255,.16)', skipBd: lockedN ? BD : 'rgba(255,255,255,.45)',
          lx1: 150 + (ni > 0 ? OFF[(ni - 1) % 8] : 0), lx2: 150 + x, lc: done || cur ? 'hsl(6 91% 47% / .55)' : 'hsl(0 0% 88%)', lanim: cur && s.justDone ? 'drawLine .4s .05s cubic-bezier(.16,1,.3,1) both' : 'none',
          popOpen: open, popLeft: 'calc(50% + ' + cx + 'px - 130px)', caretLeft: (130 + x - cx - 8) + 'px', popTitle: n.title, popSub, popBg: lockedN ? '#fff' : col, popFg: lockedN ? INK : '#fff', popSubFg: lockedN ? MUT : 'rgba(255,255,255,.85)',
          popCan: !lockedN, popLocked: lockedN, popBtn: done ? (n.type === 'bau' ? 'Já aberto' : 'Praticar de novo') : n.type === 'bau' ? 'Abrir baú' : 'Começar', popBtnFg: col,
          onStart: () => { if (done && n.type === 'bau') return; this.startNode(n.key); },
          onReport: e => { e.stopPropagation(); this.openReport({ tipo: 'fase', ref: n.key, label: 'Fase · ' + u.title, titulo: n.title, trilha: this.trackInfo(tid).nome, unidade: u.title }); }, reportFg: lockedN ? MUT : 'rgba(255,255,255,.85)', showSkip: ni === 0 && !unitDone && !done, onSkip: () => this.skipTest(tid, u.ui),
          showStartTag: cur && !open
        };
      });
      return { ui: u.ui, uiS: String(u.ui), label: 'Unidade ' + (u.ui + 1), title: u.title, color: u.color, op: locked ? .5 : 1, rows: rows.reverse(), done: unitDone };
    });
    const bu = units[s.bannerUnit] || units[0], curN = flat[curI], ti = this.trackInfo(tid), k = this.tk();
    const sn = E.streakNow(p, this.today()), risk = sn > 0 && p.workDays.indexOf(this.today().getDay()) >= 0 && p.streak.last !== k;
    const m = p.leader.mandatory[p.team];
    return {
      pathRef: this.pathRef, onPathScroll: () => { if (!this._raf) this._raf = requestAnimationFrame(() => { this._raf = 0; this.updateBanner(); }); },
      units: uv.reverse(), hasUnits: units.length > 0, bannerA: s.bannerFlip, bannerB: !s.bannerFlip, bLabel: bu ? 'Unidade ' + (bu.ui + 1) + ' · ' + ti.nome : '', bTitle: bu ? bu.title : '', bColor: bu ? bu.color : RED,
      onUnitInfo: () => this.setState({ sheet: 'unit' }), showRisk: risk, riskText: 'Faça uma lição hoje para manter ' + sn + (sn === 1 ? ' dia' : ' dias') + ' de ofensiva.',
      hasContinue: !!curN && !s.popNode, continueLabel: curN ? curN.title : '', onContinue: () => curN && this.startNode(curN.key), trackDone: curI < 0 && units.length > 0,
      isAtd: tid === 'ATD', atdEmpty: tid === 'ATD' && !units.length, canLead: this.isLeader(), onOpenLeader: () => this.setState({ sub: 'leader', leaderTab: 'units' }),
      atdMand: !!(m && m.on), atdMandText: m && m.on ? 'Obrigatória para ' + (m.publico === 'novatos' ? 'novatos' : 'o time inteiro') + (m.prazo ? ' até ' + this.E.pk(m.prazo).toLocaleDateString('pt-BR') : '') : '',
      homeLoading: s.homeLoading, homeReady: !s.homeLoading
    };
  }

  vPractice() {
    const p = this._p, due = this.dueQs(), errs = Object.keys(p.errors).map(id => this.qById(id)).filter(Boolean);
    const atdTeam = this.C.BASE_TEAMS.indexOf(p.team) >= 0;
    const recs = atdTeam ? Object.keys(this.C.MONITORIA).filter(c => this.C.MONITORIA[c] < 60).map(c => ({ crit: c, score: this.C.MONITORIA[c], onClick: () => this.startPractice('reforco', this.atd.filter(q => q.unidade === c), 'Reforce · ' + c) })) : [];
    return { dueCount: due.length, onReview: () => this.startPractice('review', due, 'Revisão inteligente'), errCount: errs.length, onErrors: () => this.startPractice('errors', errs, 'Meus erros'),
      onGlossOpen: () => this.setState({ sub: 'gloss', gloss: '' }), onFlash: () => this.startFlash(), flashRecord: p.flashRecord, recs, hasRecs: recs.length > 0, glossCount: this.C.GLOSSARY.length,
      dueLabel: due.length ? due.length + ' conceitos com chance de lembrar abaixo de 50%' : 'Tudo em dia. Volte amanhã.', errLabel: errs.length ? errs.length + ' questões para acertar de novo' : 'Nenhum erro pendente' };
  }

  vLeague() {
    const s = this.state, p = this._p, C = this.C, E = this.E, lgs = C.LEAGUES, L = lgs[p.league.idx], d = E.leagueData(C, p, this.today());
    const offline = !s.online || p.offlineSim;
    let rows = d.rows; if (s.lbFilter === 'team') rows = rows.filter(r => r.team === p.team || r.me).map((r, i) => Object.assign({}, r, { rank: i + 1 }));
    const n = d.rows.length, up = p.league.idx < lgs.length - 1 ? C.LEAGUE_RULES.sobem : 0, down = p.league.idx > 0 ? n - C.LEAGUE_RULES.descem : n + 1;
    const items = []; rows.forEach((r, i) => {
      items.push({ isRow: true, isDiv: false, rank: r.rank, nome: r.me ? r.nome + ' (você)' : r.nome, team: r.team, xp: r.xp + ' XP', av: E.av(r.nome, r.mold), bg: r.me ? 'hsl(6 91% 47% / .08)' : '#fff', bd: r.me ? 'hsl(6 91% 47% / .45)' : BD, pos: r.me ? 'sticky' : 'relative', rankFg: s.lbFilter !== 'all' ? MUT : r.rank <= up ? GREEN : r.rank > down ? RED : MUT, delay: (i * 40) + 'ms' });
      const nx = rows[i + 1];
      if (s.lbFilter === 'all' && nx && r.rank === up) items.push({ isRow: false, isDiv: true, divText: 'Zona de promoção', divIcon: 'chevrons-up', divFg: GREEN });
      if (s.lbFilter === 'all' && nx && r.rank === down) items.push({ isRow: false, isDiv: true, divText: 'Zona de rebaixamento', divIcon: 'chevrons-down', divFg: RED });
    });
    const top = rows.slice(0, 3), ord = [1, 0, 2], H = [96, 72, 56], COLS = ['linear-gradient(180deg,#FFD66B,#FF8A3D)', 'linear-gradient(180deg,#f1f5f9,#a7b1be)', 'linear-gradient(180deg,#e7a46a,#a2582a)'];
    const podium = ord.filter(i => top[i]).map(i => ({ place: i + 1, nome: top[i].me ? 'Você' : top[i].nome.split(' ')[0], xp: top[i].xp + ' XP', av: E.av(top[i].nome, top[i].mold), h: H[i] + 'px', g: COLS[i], stepDelay: [.24, .12, 0][i] + 's', avDelay: ([.24, .12, 0][i] + .35) + 's' }));
    return {
      lbLoading: s.lbLoading && !offline, lbError: offline, lbReady: !s.lbLoading && !offline, onRetry: () => { if (this.state.retrying) return; this.setState({ retrying: true }); setTimeout(() => { const still = !navigator.onLine || this._p.offlineSim; this.setState({ retrying: false, online: navigator.onLine, errShake: still ? Date.now() : 0, lbLoading: !still }); if (still) this.toast('Ainda sem conexão. Tente de novo em instantes.', 'wifi-off', 'err'); else setTimeout(() => this.setState({ lbLoading: false }), 600); }, 900); }, retrying: !!s.retrying, retryIdle: !s.retrying, retryIcon: s.retrying ? 'loader-circle' : 'refresh-cw', retryAnim: s.retrying ? 'spin .8s linear infinite' : 'none', errAnim: s.errShake ? ((Math.floor(s.errShake / 7) % 2) ? 'shake .35s ease' : 'shakeB .35s ease') : 'none', errKey: s.errShake,
      lgName: 'Liga ' + L.nome, lgGrad: L.g, lgIcon: L.icon || 'trophy', lgCountdown: 'Termina em ' + d.countdown, lgRules: (up ? 'Top ' + up + ' sobem' : 'Topo das ligas') + ' · ' + (p.league.idx > 0 ? C.LEAGUE_RULES.descem + ' últimos descem' : 'Bronze não rebaixa'),
      lgSteps: lgs.map((x, i) => ({ g: x.g, icon: x.icon || 'trophy', nome: x.nome, op: i === p.league.idx ? 1 : i < p.league.idx ? .8 : .4, sz: i === p.league.idx ? '44px' : '34px', isz: i === p.league.idx ? '20' : '15', cur: i === p.league.idx, fw: i === p.league.idx ? 700 : 500, fg: i === p.league.idx ? INK : MUT })),
      fAllBg: s.lbFilter === 'all' ? '#fff' : 'transparent', fAllFg: s.lbFilter === 'all' ? INK : MUT, fAllSh: s.lbFilter === 'all' ? '0 1px 2px rgba(0,0,0,.08)' : 'none',
      fTeamBg: s.lbFilter === 'team' ? '#fff' : 'transparent', fTeamFg: s.lbFilter === 'team' ? INK : MUT, fTeamSh: s.lbFilter === 'team' ? '0 1px 2px rgba(0,0,0,.08)' : 'none',
      onFAll: () => this.setState({ lbFilter: 'all' }), onFTeam: () => this.setState({ lbFilter: 'team' }), lbIsAll: s.lbFilter === 'all', lbIsTeam: s.lbFilter === 'team', podium, lbItems: items, onEndWeek: () => this.endWeek(), myTeam: p.team
    };
  }

  vMissions() {
    const p = this._p, C = this.C, E = this.E, k = this.tk(), dr = p.day[k] || { claimed: {} }, ms = E.missionsFor(C, k);
    const daily = ms.map(m => { const pr = Math.min(m.meta, (dr[m.m] || 0)), done = !!(dr.claimed && dr.claimed[m.k]); return { t: m.t, prog: pr + '/' + m.meta, pct: Math.round(pr / m.meta * 100) + '%', done, notDone: !done, reward: '+' + C.MISSION_REWARD, op: done ? .55 : 1, deco: done ? 'line-through' : 'none' }; });
    const nd = daily.filter(x => x.done).length, all = nd === 3;
    const mk = k.slice(0, 7), mp = Math.min(C.MONTH_GOAL, p.month[mk] || 0);
    const mon = E.monday(this.today()), f = Math.min(1, (this.today() - mon) / (7 * E.DAY) + .1), r = E.seeded('team' + E.dkey(mon) + p.team);
    let mine = 0; Object.keys(p.day).forEach(d => { if (d >= E.dkey(mon) && d <= k) mine += p.day[d].lessons; });
    const mates = C.PEOPLE.filter(x => x[1] === p.team).slice(0, 5).map(x => ({ nome: x[0], n: Math.round(r() * 9 * f), av: E.av(x[0], x[2]) }));
    mates.unshift({ nome: (p.name || 'Você') + ' (você)', n: mine, av: E.av(p.name, p.equipped) });
    const tot = mates.reduce((a, b) => a + b.n, 0);
    const mid = new Date(this.today()); mid.setHours(24, 0, 0, 0); const left = mid - this.today();
    return {
      daily, dailyDone: nd, chestReady: all && !dr.chest, chestOpened: !!dr.chest, chestLocked: !all, onDailyChest: () => this.openChest('daily'),
      resetIn: 'renova em ' + Math.floor(left / 36e5) + 'h', monthT: 'Desafio de ' + this.today().toLocaleDateString('pt-BR', { month: 'long' }), monthSub: 'Conclua ' + C.MONTH_GOAL + ' lições e ganhe um emblema exclusivo',
      monthPct: Math.round(mp / C.MONTH_GOAL * 100) + '%', monthProg: mp + '/' + C.MONTH_GOAL, monthDone: mp >= C.MONTH_GOAL,
      teamT: 'Equipe ' + p.team + ': ' + C.TEAM_GOAL + ' lições na semana', teamPct: Math.min(100, Math.round(tot / C.TEAM_GOAL * 100)) + '%', teamProg: Math.min(tot, C.TEAM_GOAL) + '/' + C.TEAM_GOAL, teamMembers: mates.map(m => Object.assign(m, { nl: m.n + (m.n === 1 ? ' lição' : ' lições') })),
      onLoja: () => this.setState({ sub: 'loja' }), hubLevel: ['Explorador do Hub', 'Conhecedor do Hub', 'Especialista do Hub'][nd >= 3 ? 2 : nd >= 1 ? 1 : 0]
    };
  }

  vProfile() {
    const s = this.state, p = this._p, C = this.C, E = this.E, pt = s.profTab;
    const cq = E.conquests(p, { tracksDone: this.tracksDone() }), acc = p.stats.ans ? Math.round(p.stats.ok / p.stats.ans * 100) : 0, L = C.LEAGUES[p.league.idx];
    const roleLabel = { master: 'Master', admin: 'Admin', lider: 'Líder', analista: 'Viewer' }[p.role] || 'Viewer';
    const stats = [['flame', 'Ofensiva', E.streakNow(p, this.today()) + ' dias', 'hsl(28 90% 52%)', 'hsl(28 90% 52% / .14)'], ['zap', 'XP total', p.xpTotal, AMBER, 'hsl(40 92% 46% / .15)'], ['trophy', 'Liga', L.nome, 'hsl(212 72% 48%)', 'hsl(212 72% 48% / .12)'], ['book-open', 'Lições', cq.lessons, RED, REDT], ['target', 'Precisão', acc + '%', GREEN, 'hsl(150 55% 40% / .14)'], ['snowflake', 'Congelamentos', p.streak.freezes + '/2', 'hsl(190 65% 42%)', 'hsl(190 65% 42% / .12)']].map(x => ({ icon: x[0], label: x[1], val: x[2], fg: x[3], bg: x[4] }));
    const emb = cq.fams.map(f => ({ nome: f.fam, sub: f.level ? 'Nível ' + E.ROMAN[f.level] : 'Bloqueado', prog: f.next ? f.val + '/' + f.next + ' ' + f.un : 'Nível máximo', icon: f.icon, g: f.level ? 'linear-gradient(145deg,#7CC9FF,#5B6CFF)' : 'linear-gradient(145deg,hsl(0 0% 88%),hsl(0 0% 76%))', op: 1 }))
      .concat(p.badges.map(b => ({ nome: b.nome, sub: b.sub, prog: 'Conquistado', icon: b.icon, g: b.g, op: 1 })));
    const order = (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).order;
    const trk = this.trackList().filter(t => t.id === 'ATD' || order.indexOf(t.id) >= 0 || E.trackPct(C, this.bank, this.atd, p, t.id) > 0).map(t => { const pc = E.trackPct(C, this.bank, this.atd, p, t.id); return { nome: t.nome, icon: t.icon, pct: pc + '%', onClick: () => { this.upd(q => { q.activeTrack = t.id; }); this.setTab('learn'); } }; });
    const mates = C.PEOPLE.filter(x => x[1] === p.team).slice(0, 6).map(x => { const nudged = p.nudged[x[0]] === this.tk(); const r = E.seeded('st' + x[0] + this.tk()); return { nome: x[0], sub: Math.floor(r() * 40) + ' dias de ofensiva', av: E.av(x[0], x[2]), nudged, canNudge: !nudged, onNudge: () => { this.upd(q => { q.nudged[x[0]] = this.tk(); }); this.toast('Você cutucou ' + x[0].split(' ')[0] + '. Ela recebe um lembrete.', 'hand'); } }; });
    const pf = s.prof || { name: p.name, phone: p.phone, pwd: '', pwd2: '', show: false };
    const setPf = k => e => this.setState({ prof: Object.assign({}, pf, { [k]: e.target.value }) });
    const pill = id => ({ bg: pt === id ? RED : '#fff', fg: pt === id ? '#fff' : MUT, bd: pt === id ? RED : BD });
    const lead = this.isLeader();
    const r = E.seeded('lead' + p.team + this.tk());
    const teamPeople = C.PEOPLE.filter(x => x[1] === p.team);
    return {
      onProfReport: () => this.openReport({ tipo: 'geral', label: 'Feedback geral', titulo: '' }), onProfReports: () => this.setState({ sub: 'reports' }), profRepCount: (window.AcademyFeedback ? window.AcademyFeedback.list().length : 0), profPadTop: p.equippedBg ? '50px' : '16px', profBg: (C.SHOP.find(x => x.id === p.equippedBg) || {}).g || '', hasProfBg: !!p.equippedBg, profIconOn: !!p.equippedIcon, profIcon: (C.SHOP.find(x => x.id === p.equippedIcon) || {}).icon || 'star', profName: p.name || 'Usuário', profEmail: p.session ? p.session.email : '', roleLabel, profAv: E.av(p.name, p.equipped), profCargo: p.cargo + ' · ' + p.team,
      ptA: pill('academy'), ptD: pill('dados'), ptC: pill('config'), onPtA: () => this.setState({ profTab: 'academy' }), onPtD: () => this.setState({ profTab: 'dados' }), onPtC: () => this.setState({ profTab: 'config' }),
      isPtA: pt === 'academy', isPtD: pt === 'dados', isPtC: pt === 'config',
      stats, emblems: emb, certs: p.certs.map(c => ({ trilha: c.trilha, data: c.data, onOpen: () => this.viewCert(c), onPrint: e => { e.stopPropagation(); this.openCert(c); } })),
      onCertSample: () => this.viewCert({ nome: p.name, trilha: this.trackInfo(p.activeTrack).nome, data: this.today().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }) }), hasCerts: p.certs.length > 0, noCerts: !p.certs.length,
      trkRows: trk, mates, hasMates: mates.length > 0,
      isLeaderUser: lead, leadPct: Math.round(35 + r() * 40) + '%', leadDone: Math.round(r() * 5) + ' trilhas concluídas', leadCerts: Math.round(r() * 4) + ' certificados', leadWorst: ['Gestão de expectativa', 'Registro / Motivo', 'Encaminhamento interno'], leadMembers: teamPeople.length + 1,
      onOpenLeader: () => this.setState({ sub: 'leader', leaderTab: 'panel' }),
      pfName: pf.name, pfPhone: pf.phone, onPfName: setPf('name'), onPfPhone: setPf('phone'), pfTeam: p.team, pfCargo: p.cargo, canManage: p.role === 'admin' || p.role === 'master', cantManage: !(p.role === 'admin' || p.role === 'master'),
      pTeamDD: this.dd('pteam', p.team, C.TEAMS.map(t => ({ t, sel: p.team === t, onPick: () => { this.upd(q => { q.team = t; }); this.toast('Equipe alterada para ' + t); } }))),
      onPfSave: () => { this.upd(q => { q.name = pf.name; q.phone = pf.phone; }); this.toast('Perfil atualizado com sucesso!'); },
      pfPwd: pf.pwd, pfPwd2: pf.pwd2, onPfPwd: setPf('pwd'), onPfPwd2: setPf('pwd2'), pfPwdType: pf.show ? 'text' : 'password', pfEye: pf.show ? 'eye-off' : 'eye', onPfEye: () => this.setState({ prof: Object.assign({}, pf, { show: !pf.show }) }),
      onPfPwdSave: () => { if (pf.pwd.length < 6) return this.toast('A senha deve ter pelo menos 6 caracteres.', 'circle-x', 'err'); if (pf.pwd !== pf.pwd2) return this.toast('As senhas não coincidem.', 'circle-x', 'err'); this.upd(q => { const e = q.session.email; q.users[e] = Object.assign({}, q.users[e], { pwd: pf.pwd }); }); this.setState({ prof: Object.assign({}, pf, { pwd: '', pwd2: '' }) }); this.toast('Senha alterada com sucesso!'); },
      cfgGoals: C.GOALS.map(g => ({ t: g.min + ' min', bg: p.goalMin === g.min ? '#fff' : 'transparent', fg: p.goalMin === g.min ? INK : MUT, sh: p.goalMin === g.min ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.upd(q => { q.goalMin = g.min; }) })),
      cfgDays: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((l, i) => { const on = p.workDays.indexOf(i) >= 0; return { l, bg: on ? RED : '#fff', fg: on ? '#fff' : MUT, bd: on ? RED : BD, onClick: () => this.upd(q => { q.workDays = on ? q.workDays.filter(x => x !== i) : q.workDays.concat([i]).sort(); }) }; }),
      cfgRem: C.REMINDERS.slice(0, 4).map(t => { const on = !s.remCustom && p.reminder === t; return { t, bg: on ? RED : '#fff', fg: on ? '#fff' : MUT, bd: on ? RED : BD, onClick: () => { this.setState({ remCustom: false }); this.upd(q => { q.reminder = t; }); } }; }),
      remCustom: !!s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0, remCustomBg: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? RED : '#fff', remCustomFg: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? '#fff' : MUT, remCustomBd: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? RED : BD, onRemCustom: () => this.setState({ remCustom: true }),
      cfgTime: this.timeVals(p.reminder, v => this.upd(q => { q.reminder = v; })),
      soundOn: p.sound, soundBg: p.sound ? RED : BD, soundKnob: p.sound ? '18px' : '2px', onSound: () => this.upd(q => { q.sound = !q.sound; }),
      offBg: p.offlineSim ? RED : BD, offKnob: p.offlineSim ? '18px' : '2px', onOffSim: () => this.upd(q => { q.offlineSim = !q.offlineSim; }),
      personaDD: this.dd('persona', (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).nome, C.PERSONAS.map(x => ({ t: x.nome + ' · ' + x.grupo, sel: p.persona === x.id, onPick: () => this.upd(q => { q.persona = x.id; }) }))),
      cfgRoles: [['analista', 'Analista'], ['lider', 'Líder'], ['admin', 'Admin'], ['master', 'Master']].map(([id, t]) => ({ t, bg: p.role === id ? '#fff' : 'transparent', fg: p.role === id ? INK : MUT, sh: p.role === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.upd(q => { q.role = id; }) })),
      onAdvanceDay: () => { this.upd(q => { q.dayOffset++; }); this.checkWeek(); this.toast('Avançamos para ' + this.today().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' }), 'calendar'); },
      onResetAsk: () => this.setState({ resetAsk: true }), onLogout: () => { Hub.sair(); this.upd(q => { q.session = null; }); this.setState({ screen: 'login', lg: Object.assign({}, s.lg, { pwd: '', email: p.remembered || '' }) }); }
    };
  }

  vLoja() {
    const s = this.state, p = this._p, C = this.C, lj = s.loja, tab = lj.tab || 'moldura', norm = x => x.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    let items = C.SHOP.filter(i => i.tipo === tab);
    if (lj.busca.trim()) items = items.filter(i => norm(i.nome).indexOf(norm(lj.busca.trim())) >= 0);
    const tiers = ['todas', 'comum', 'raro', 'epico', 'lendario', 'sazonal'];
    const tl = t => (t === 'todas' ? 'Todas as raridades' : C.RARIDADE[t].label) + ' (' + items.filter(i => t === 'todas' || i.raridade === t).length + ')';
    const tierDD = this.dd('tier', tl(lj.tier), tiers.map(t => ({ t: tl(t), sel: lj.tier === t, dot: t === 'todas' ? 'transparent' : C.RARIDADE[t].cor, onPick: () => this.setState({ loja: Object.assign({}, this.state.loja, { tier: t }) }) })));
    if (lj.tier !== 'todas') items = items.filter(i => i.raridade === lj.tier);
    const eqOf = i => i.tipo === 'moldura' ? p.equipped === i.asset : i.tipo === 'fundo' ? p.equippedBg === i.id : i.tipo === 'icone' ? p.equippedIcon === i.id : false;
    const list = items.map(i => {
      const rar = C.RARIDADE[i.raridade], own = p.owned.indexOf(i.id) >= 0 && i.tipo !== 'item', eq = eqOf(i), gratis = i.preco === 0, sem = !gratis && p.takitos < i.preco;
      let btn = 'Comprar', btnBg = RED, btnFg = '#fff', btnBd = RED, dis = sem;
      if (own) { btn = eq ? 'Em uso' : 'Equipar'; btnBg = eq ? 'hsl(0 0% 95%)' : '#fff'; btnFg = INK; btnBd = BD; dis = false; }
      else if (i.somente_codigo) { btn = 'Bloqueado'; btnBg = '#fff'; btnFg = MUT; btnBd = BD; dis = true; }
      else if (gratis) { btn = 'Pegar grátis'; btnBg = 'hsl(0 0% 95%)'; btnFg = INK; btnBd = BD; }
      else if (sem) { btn = 'Takitos insuficientes'; btnBg = 'hsl(0 0% 90%)'; btnFg = MUT; btnBd = 'hsl(0 0% 90%)'; }
      return { nome: i.nome, col: 'Coleção ' + i.colecao, rar: rar.label, rbg: rar.bg, rfg: rar.fg, top: '3px solid ' + rar.cor, isMold: i.tipo === 'moldura', isFundo: i.tipo === 'fundo', isIcone: i.tipo === 'icone', isItem: i.tipo === 'item', g: i.g || '', av: this.E.av(p.name, i.asset), icon: i.icon || 'gift', eq, preco: i.preco, isGratis: gratis && !i.somente_codigo, isPago: !gratis, isCod: !!i.somente_codigo, btn, btnBg, btnFg, btnBd, dis,
        onClick: () => {
          if (own) { this.upd(q => { if (i.tipo === 'moldura') q.equipped = eq ? null : i.asset; else if (i.tipo === 'fundo') q.equippedBg = eq ? null : i.id; else q.equippedIcon = eq ? null : i.id; }); return this.toast(eq ? i.nome + ' removido do perfil' : i.nome + ' equipado!'); }
          if (dis) return;
          this.setState({ buy: i.id, dd: null });
        } };
    });
    const tabs = C.SHOP_TABS.map(([id, t]) => ({ t, bg: tab === id ? '#fff' : 'transparent', fg: tab === id ? INK : MUT, sh: tab === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ loja: Object.assign({}, this.state.loja, { tab: id, tier: 'todas' }) }) }));
    return { lojaSaldo: p.takitos, lojaBusca: lj.busca, onLojaBusca: e => this.setState({ loja: Object.assign({}, lj, { busca: e.target.value }) }), lojaPh: 'Buscar ' + ({ moldura: 'moldura', fundo: 'plano de fundo', icone: 'ícone', item: 'item' })[tab] + ' pelo nome...',
      lojaTabs: tabs, tierDD, lojaItems: list, lojaEmpty: !list.length, onOpenResgate: () => this.setState({ sub: 'resgate', resg: { code: '', item: null, err: '' } }) };
  }
  vBuy() {
    const s = this.state, p = this._p, C = this.C, i = C.SHOP.find(x => x.id === s.buy); if (!i) return { buyOpen: false };
    const rar = C.RARIDADE[i.raridade], after = p.takitos - i.preco, bg = C.SHOP.find(x => x.id === p.equippedBg), ic = C.SHOP.find(x => x.id === p.equippedIcon);
    return { buyOpen: true, bNomeI: i.nome, bCol: 'Coleção ' + i.colecao, bRar: rar.label, bRbg: rar.bg, bRfg: rar.fg, bTop: '3px solid ' + rar.cor, bPreco: i.preco, bGratis: i.preco === 0, bPago: i.preco > 0, bAfter: after + ' Takitos depois da compra',
      bAv: this.E.av(p.name, i.tipo === 'moldura' ? i.asset : p.equipped), bBanner: i.tipo === 'fundo' ? i.g : (bg ? bg.g : 'linear-gradient(135deg,hsl(0 0% 96%),hsl(0 0% 90%))'), bIconOn: i.tipo === 'icone' || !!ic, bIcon: i.tipo === 'icone' ? i.icon : ic ? ic.icon : 'star', bIsItem: i.tipo === 'item', bIsVisual: i.tipo !== 'item', bItemIcon: i.icon || 'gift', bNome: p.name || 'Você', bTeam: p.team,
      bHint: i.tipo === 'item' ? (i.id === 'i-freeze' ? 'Protege sua ofensiva num dia útil sem lição.' : 'Todo XP dos próximos 15 minutos vale o dobro.') : 'Assim fica no seu perfil do Hub.',
      onBuyCancel: () => this.setState({ buy: null }),
      onBuyConfirm: () => {
        this.upd(q => { q.takitos -= i.preco; if (i.tipo === 'item') { if (i.id === 'i-freeze') q.streak.freezes = Math.min(2, q.streak.freezes + 1); else q.boostUntil = Date.now() + 15 * 60000; } else { q.owned.push(i.id); if (i.tipo === 'moldura') q.equipped = i.asset; else if (i.tipo === 'fundo') q.equippedBg = i.id; else q.equippedIcon = i.id; } });
        this.setState({ buy: null }); this.toast(i.nome + (i.tipo === 'item' ? ' ativado!' : ' comprado e equipado!'), 'store', 'gold');
      } };
  }
  vResgate() {
    const p = this._p, C = this.C, r = this.state.resg || { code: '', item: null, err: '' }, it = r.item, set = patch => this.setState({ resg: Object.assign({}, this.state.resg || {}, patch) });
    const rar = it ? C.RARIDADE[it.raridade] : null;
    return { rsCode: r.code, onRsCode: e => set({ code: e.target.value.toUpperCase(), err: '' }), rsHasErr: !!r.err, rsErr: r.err, rsForm: !it, rsPreview: !!it, rsDisabled: !r.code.trim(),
      onRsCheck: () => { const id = C.CODES[r.code.trim()]; if (!id) return set({ err: 'Código inválido ou já usado.' }); if (p.owned.indexOf(id) >= 0) return set({ err: 'Você já tem esse item na coleção.' }); set({ item: C.SHOP.find(x => x.id === id) }); },
      rsNome: it ? it.nome : '', rsCol: it ? 'Coleção ' + it.colecao : '', rsRar: rar ? rar.label : '', rsRbg: rar ? rar.bg : '', rsRfg: rar ? rar.fg : '', rsTop: rar ? '3px solid ' + rar.cor : '', rsAv: this.E.av(p.name, it ? it.asset : null),
      onRsConfirm: () => { this.upd(q => { q.owned.push(it.id); }); this.setState({ sub: 'loja', resg: null, loja: Object.assign({}, this.state.loja, { codigo: '' }) }); this.toast(it.nome + ' resgatada! Já está na sua coleção.', 'gift', 'gold'); },
      onRsOther: () => set({ item: null, code: '', err: '' }) };
  }

  vGloss() {
    const q = this.state.gloss.trim().toLowerCase();
    return { gloss: this.state.gloss, onGloss: e => this.setState({ gloss: e.target.value }), glossItems: this.C.GLOSSARY.filter(g => !q || (g.t + ' ' + g.d).toLowerCase().indexOf(q) >= 0).map(g => ({ t: g.t, d: g.d, onPractice: () => this.practiceTerm(g.t) })) };
  }

  vLeader() {
    const s = this.state, p = this._p, C = this.C, E = this.E, team = p.team, lt = s.leaderTab, dis = E.disabledFor(C, p, team), rules = p.leader.rules[team] || [];
    const tabs = [['units', 'Unidades'], ['rules', 'Regras'], ['mand', 'Obrigatória'], ['panel', 'Painel']].map(([id, t]) => ({ t, onClick: () => this.setState({ leaderTab: id }), bg: lt === id ? RED : '#fff', fg: lt === id ? '#fff' : MUT, bd: lt === id ? RED : BD, sh: lt === id ? '0 2px 8px hsl(6 91% 47% / .28)' : 'none' }));
    const base = C.ATD_UNITS.map((u, i) => { const on = dis.indexOf(i) < 0; return { t: (i + 1) + '. ' + u.titulo, regra: u.regra, crit: !!u.critico, trk: on ? RED : BD, knob: on ? '18px' : '2px', n: this.atd.filter(q => q.unidade === u.titulo).length + ' questões', onToggle: () => this.upd(q => { const d = E.disabledFor(C, q, team).slice(); q.leader.disabled[team] = on ? d.concat([i]) : d.filter(x => x !== i); }) }; });
    const rf = s.ruleForm, qf = s.qForm;
    const rv = rules.map(r => ({ id: r.id, t: r.titulo, d: r.descricao, bom: r.bom, ruim: r.ruim, wiki: r.wiki || 'Sem artigo vinculado', nq: r.questions.length + (r.questions.length === 1 ? ' questão' : ' questões'), pub: r.published, draft: !r.published,
      open: s.openRule === r.id, onToggle: () => this.setState({ openRule: s.openRule === r.id ? null : r.id, qForm: null }),
      qs: r.questions.map(q => ({ t: q.enunciado, tipo: E.TYPE_LABEL[q.tipo][0], ans: q.resposta })),
      onNewQ: () => this.setState({ qForm: { ruleId: r.id, tipo: 'cenario', enunciado: '', opts: ['', '', '', ''], correct: 0, explicacao: '' } }),
      onPublish: () => { if (!r.questions.length) return this.toast('Crie pelo menos 1 questão antes de publicar.', 'triangle-alert', 'err'); this.leaderUpd((q, t) => { q.leader.rules[t].find(x => x.id === r.id).published = true; }); this.toast('Regra publicada na trilha do time'); },
      onUnpub: () => this.leaderUpd((q, t) => { q.leader.rules[t].find(x => x.id === r.id).published = false; }),
      showQForm: !!(qf && qf.ruleId === r.id) }));
    const setR = k => e => this.setState({ ruleForm: Object.assign({}, rf, { [k]: e.target.value }) });
    const setQ = k => e => this.setState({ qForm: Object.assign({}, qf, { [k]: e.target.value }) });
    const qRule = qf ? rules.find(x => x.id === qf.ruleId) : null, vf = qf && qf.tipo === 'verdadeiro_falso';
    const m = p.leader.mandatory[team] || { on: false, prazo: '', publico: 'time' };
    const setM = patch => this.upd(q => { q.leader.mandatory[team] = Object.assign({}, m, patch); });
    const r = E.seeded('panel' + team + E.dkey(E.monday(this.today())));
    const atdPct = E.trackPct(C, this.bank, this.atd, p, 'ATD');
    const members = C.PEOPLE.filter(x => x[1] === team).map(x => ({ nome: x[0], av: E.av(x[0], x[2]), pct: Math.round(10 + r() * 85) })).concat([{ nome: (p.name || 'Você') + ' (você)', av: E.av(p.name, p.equipped), pct: atdPct }]).sort((a, b) => b.pct - a.pct).map(x => Object.assign(x, { pctS: x.pct + '%', fg: x.pct >= 80 ? GREEN : x.pct >= 60 ? AMBER : RED }));
    const prec = C.ATD_UNITS.filter((u, i) => dis.indexOf(i) < 0).map(u => ({ t: u.titulo, v: Math.round(48 + r() * 48) })).concat(rules.filter(x => x.published).map(x => ({ t: x.titulo, v: Math.round(45 + r() * 50) })));
    prec.forEach(x => { x.vS = x.v + '%'; x.fg = x.v >= 80 ? GREEN : x.v >= 60 ? AMBER : RED; x.band = x.v >= 80 ? 'Alto' : x.v >= 60 ? 'Médio' : 'Baixo'; });
    const worst = prec.slice().sort((a, b) => a.v - b.v).slice(0, 3);
    return {
      leaderTabs: tabs, ltUnits: lt === 'units', ltRules: lt === 'rules', ltMand: lt === 'mand', ltPanel: lt === 'panel', leadTeam: team, baseUnits: base, noBase: C.BASE_TEAMS.indexOf(team) < 0,
      rules: rv, hasRules: rules.length > 0, noRules: !rules.length,
      ruleFormOpen: !!rf, onNewRule: () => this.setState({ ruleForm: { titulo: '', descricao: '', bom: '', ruim: '', wiki: '' } }), onCancelRule: () => this.setState({ ruleForm: null }),
      rfT: rf ? rf.titulo : '', rfD: rf ? rf.descricao : '', rfB: rf ? rf.bom : '', rfR: rf ? rf.ruim : '', rfW: rf ? rf.wiki : '', onRfT: setR('titulo'), onRfD: setR('descricao'), onRfB: setR('bom'), onRfR: setR('ruim'), onRfW: setR('wiki'),
      onSaveRule: () => { if (!rf.titulo.trim() || !rf.descricao.trim()) return this.toast('Dê um título e uma descrição para a regra.', 'triangle-alert', 'err'); const id = 'r' + Date.now().toString(36); this.leaderUpd((q, t) => { q.leader.rules[t].push(Object.assign({ id, questions: [], published: false }, rf)); }); this.setState({ ruleForm: null, openRule: id }); this.toast('Regra criada como rascunho'); },
      qfTipos: [['cenario', 'Cenário'], ['multipla_escolha', 'Múltipla escolha'], ['verdadeiro_falso', 'V ou F'], ['diagnostico', 'Diagnóstico']].map(([id, t]) => ({ t, bg: qf && qf.tipo === id ? '#fff' : 'transparent', fg: qf && qf.tipo === id ? INK : MUT, sh: qf && qf.tipo === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ qForm: Object.assign({}, qf, { tipo: id, correct: id === 'verdadeiro_falso' ? 1 : 0 }) }) })),
      qfEnun: qf ? qf.enunciado : '', onQfEnun: setQ('enunciado'), qfExp: qf ? qf.explicacao : '', onQfExp: setQ('explicacao'), qfVF: !!vf, qfNotVF: !vf,
      qfOpts: qf ? (vf ? ['Verdadeiro', 'Falso'] : qf.opts).map((o, i) => ({ v: o, ph: 'Alternativa ' + (i + 1), letter: String.fromCharCode(65 + i), onChange: e => { const op = qf.opts.slice(); op[i] = e.target.value; this.setState({ qForm: Object.assign({}, this.state.qForm, { opts: op }) }); }, ok: qf.correct === i, rbg: qf.correct === i ? GREEN : '#fff', rbd: qf.correct === i ? GREEN : BD, onCorrect: () => this.setState({ qForm: Object.assign({}, this.state.qForm, { correct: i }) }) })) : [],
      onHubia: () => { if (!qRule) return; this.setState({ qForm: Object.assign({}, qf, this.hubiaDraft(qRule, qf.tipo)) }); this.toast('Hubia preencheu um rascunho. Revise antes de salvar.', 'sparkles'); },
      qfHubia: !!(qf && qf.hubia), onCancelQ: () => this.setState({ qForm: null }), onAddQ: () => this.addQuestion(),
      prevEnun: qf && qf.enunciado ? qf.enunciado : 'O enunciado aparece aqui.', prevOpts: qf ? (vf ? ['Verdadeiro', 'Falso'] : qf.opts.filter(Boolean)).map((o, i) => ({ t: o, bd: (vf ? i : qf.opts.indexOf(o)) === qf.correct ? GREEN : BD })) : [], prevTipo: qf ? E.TYPE_LABEL[qf.tipo][0] : '',
      mOn: m.on, mTrk: m.on ? RED : BD, mKnob: m.on ? '18px' : '2px', onMToggle: () => setM({ on: !m.on }), mPrazo: m.prazo, onMPrazo: e => setM({ prazo: e.target.value }),
      mPubTime: { bg: m.publico !== 'novatos' ? '#fff' : 'transparent', fg: m.publico !== 'novatos' ? INK : MUT, sh: m.publico !== 'novatos' ? '0 1px 2px rgba(0,0,0,.08)' : 'none' }, mPubNov: { bg: m.publico === 'novatos' ? '#fff' : 'transparent', fg: m.publico === 'novatos' ? INK : MUT, sh: m.publico === 'novatos' ? '0 1px 2px rgba(0,0,0,.08)' : 'none' },
      onPubTime: () => setM({ publico: 'time' }), onPubNov: () => setM({ publico: 'novatos' }),
      members, prec, worst, teamAvg: Math.round(members.reduce((a, b) => a + b.pct, 0) / members.length) + '%'
    };
  }

  vLesson() {
    const s = this.state, L = s.lesson, ex = s.ex, E = this.E, h = React.createElement; if (!L || !ex) return {};
    const noReq = E.NOREQ.indexOf(L.mode) >= 0, answered = L.solved + (noReq ? Object.keys(L.wrong).length : 0), pct = Math.round(Math.min(1, answered / L.total) * 100);
    const v = {
      lessonPct: pct + '%', onExit: () => this.setState({ exitAsk: true }),
      shineEl: h('span', { key: 'sh' + answered, style: { position: 'absolute', top: 0, bottom: 0, width: '35%', left: 0, background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.75),transparent)', animation: answered ? 'shine .8s .15s ease-out both' : 'none' } }),
      showCombo: L.combo >= 3, comboEl: h('span', { key: 'c' + L.combo, style: { display: 'inline-flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 999, background: 'hsl(40 92% 46% / .15)', color: 'hsl(32 82% 40%)', fontWeight: 700, fontSize: 12 + Math.min(4, L.combo - 3), animation: 'comboPop .4s cubic-bezier(.34,1.56,.64,1)' } }, h('lu-icon', { name: 'flame', size: '14' }), 'x' + L.combo),
      onLessonReport: () => { const q = L.tipOpen ? L.tip : L.queue[L.idx]; this.openReport({ tipo: 'questao', ref: q.id, label: 'Questão ' + q.id + ' · ' + E.TYPE_LABEL[q.tipo][0], titulo: q.enunciado, trilha: q.trilha, unidade: q.unidade, licao: L.title }); },
      isTimed: L.timed && !L.tipOpen, isTip: L.tipOpen, notTip: !L.tipOpen, lessonTitle: L.title
    };
    if (L.timed) { const left = Math.max(0, 30 - Math.floor((s.now - L.qStart) / 1000)); v.secsLeft = left + 's'; v.timerFg = left <= 10 ? RED : MUT; }
    if (L.tipOpen) { Object.assign(v, { tipTitle: L.tip.licao, tipText: L.tip.explicacao, tipFonte: E.fmtFonte(L.tip.fonte), onTipGo: () => this.setState({ lesson: Object.assign({}, L, { tipOpen: false, qStart: Date.now() }) }) }); return v; }
    const q = L.queue[L.idx], t = q.tipo, checked = !!s.fb, TL = E.TYPE_LABEL[t];
    const optStyle = o => {
      const sel = ex.sel === o, isAns = o === q.resposta; let bd = BD, bg = '#fff', sh = '0 3px 0 hsl(0 0% 88%)', tr = 'none', anim = 'none', fg = INK;
      if (!checked && sel) { bd = RED; bg = REDT2; sh = '0 3px 0 hsl(6 91% 47% / .45)'; tr = 'translateY(-2px) scale(1.02)'; fg = RED; }
      if (checked && isAns) { bd = GREEN; bg = GREENT; sh = '0 3px 0 hsl(150 55% 40% / .45)'; fg = 'hsl(150 55% 28%)'; }
      if (checked && sel && !isAns) { bd = RED; bg = REDT; anim = 'shake .3s ease'; fg = RED; }
      return { text: o, bd, bg, sh, tr, anim, fg, sel, onClick: () => { if (this.state.fb) return; this.beep('tap'); this.setEx({ sel: o }); } };
    };
    Object.assign(v, { typeLabel: TL[0], typeIcon: TL[1], enun: q.enunciado, isVF: t === 'verdadeiro_falso', isCenario: t === 'cenario', isDiag: t === 'diagnostico', isLacuna: t === 'completar_lacuna', isTouch: t === 'toque_na_tela', isNumeric: !!ex.numeric, isOrder: t === 'ordenar_passos', isPairs: t === 'combinar_pares', isOnde: t === 'onde_fica' });
    v.isPlainQ = !v.isCenario && !v.isDiag && !v.isLacuna && !v.isTouch;
    v.isOptList = !!ex.opts && !v.isLacuna && !v.isTouch && !v.isNumeric;
    v.optCols = v.isVF ? '1fr 1fr' : '1fr';
    v.opts = ex.opts ? ex.opts.map(optStyle) : [];
    if (v.isLacuna) { const parts = q.enunciado.split(/_{2,}/); v.lacA = parts[0]; v.lacB = parts.slice(1).join(' '); v.lacBlank = ex.sel || '\u00a0'; v.lacBd = ex.sel ? RED : 'hsl(0 0% 80%)'; v.lacFg = checked ? (ex.sel === q.resposta ? GREEN : RED) : RED; }
    if (v.isTouch) { const m = q.enunciado.match(/^Tela:\s*([\s\S]+?)\.\s+([\s\S]*)$/); v.touchCap = m ? m[1] : 'Tela da plataforma'; v.touchQ = m ? m[2] : q.enunciado; }
    if (v.isNumeric) { v.numVal = ex.num; v.onNum = e => { if (this.state.fb) return; this.setEx({ num: e.target.value }); }; v.numBd = checked ? (s.fb.ok ? GREEN : RED) : (ex.num ? RED : BD); v.onNumKey = e => { if (e.key === 'Enter' && this.E.digits(this.state.ex.num)) this.check(); }; }
    if (v.isOrder) {
      const d = ex.drag, n = ex.order.length;
      v.ordItems = ex.order.map((text, j) => {
        let ty = 0, z = 1, sc = 1, shadow = '0 3px 0 hsl(0 0% 88%)', trans = 'transform .22s cubic-bezier(.16,1,.3,1)';
        if (d) { const target = Math.max(0, Math.min(n - 1, d.i + Math.round(d.dy / STEP))); if (j === d.i) { ty = d.dy; z = 5; sc = 1.04; shadow = '0 14px 30px rgba(0,0,0,.18)'; trans = 'none'; } else if (j > d.i && j <= target) ty = -STEP; else if (j < d.i && j >= target) ty = STEP; }
        const ok = checked && q.resposta[j] === text, bad = checked && !ok;
        return { text, num: j + 1, tf: 'translateY(' + ty + 'px) scale(' + sc + ')', z, shadow, trans, bd: ok ? GREEN : bad ? RED : BD, bg: ok ? GREENT : bad ? REDT2 : '#fff', nbg: ok ? GREEN : bad ? RED : 'hsl(0 0% 95%)', nfg: ok || bad ? '#fff' : MUT, onDown: e => this.ordDown(j, e), onMove: e => this.ordMove(e), onUp: () => this.ordUp() };
      });
    }
    if (v.isPairs) {
      const mk = (side, val) => { const m = side === 'l' ? ex.mL[val] : ex.mR[val], sel = side === 'l' ? ex.selL === val : ex.selR === val, bad = ex.bad && (side === 'l' ? ex.bad.l : ex.bad.r) === val; return { text: val, onClick: () => this.tapPair(side, val), bd: sel || bad ? RED : BD, bg: sel ? REDT2 : bad ? REDT : '#fff', fg: sel || bad ? RED : INK, anim: m ? 'pairOut .45s cubic-bezier(.16,1,.3,1) forwards' : bad ? 'shake .3s ease' : 'none', pe: m ? 'none' : 'auto', tr: sel ? 'translateY(-2px) scale(1.02)' : 'none' }; };
      v.pairL = ex.left.map(x => mk('l', x)); v.pairR = ex.right.map(x => mk('r', x)); v.pairMist = ex.mistakes ? ex.mistakes + (ex.mistakes === 1 ? ' erro' : ' erros') : 'Sem erros';
    }
    if (v.isOnde) {
      let node = ex.tree; ex.path.forEach(lb => { node = node.kids.find(k => k.label === lb) || node; });
      const rows = node.kids.map(k => { const sel = ex.sel && k.value === ex.sel && !k.kids.length; return { label: k.label, kids: k.kids.length > 0, leaf: !k.kids.length, sel, bg: sel ? REDT2 : '#fff', bd: sel ? RED : 'hsl(0 0% 93%)', fg: sel ? RED : INK, onClick: () => { if (this.state.fb) return; this.beep('tap'); if (k.kids.length) this.setEx({ path: ex.path.concat([k.label]) }); else this.setEx({ sel: k.value }); } }; });
      if (node.value && node.kids.length) rows.unshift({ label: 'Abrir ' + node.label, kids: false, leaf: true, sel: ex.sel === node.value, bg: ex.sel === node.value ? REDT2 : '#fff', bd: ex.sel === node.value ? RED : 'hsl(0 0% 93%)', fg: ex.sel === node.value ? RED : INK, onClick: () => this.setEx({ sel: node.value }) });
      v.ondeRows = rows; v.ondeCrumb = ['Início'].concat(ex.path).join('  ›  '); v.ondeCanBack = ex.path.length > 0; v.onOndeBack = () => this.setEx({ path: ex.path.slice(0, -1) }); v.ondeSel = ex.sel || ''; v.hasOndeSel = !!ex.sel;
    }
    const can = v.isOrder ? true : v.isNumeric ? E.digits(ex.num).length > 0 : ex.sel != null;
    Object.assign(v, { showCheck: !v.isPairs && !checked, checkDisabled: !can, checkBg: can ? RED : 'hsl(0 0% 90%)', checkFg: can ? '#fff' : 'hsl(0 0% 62%)', checkSh: can ? '0 4px 0 hsl(6 100% 34%)' : '0 4px 0 hsl(0 0% 82%)', onCheck: () => this.check(), pairsHint: v.isPairs && !checked });
    if (checked) { const ok = s.fb.ok; Object.assign(v, { fbOpen: !s.why, fbOk: ok, fbBad: !ok, fbTitle: ok ? ['Mandou bem!', 'Isso mesmo!', 'Perfeito!'][answered % 3] : s.fb.timeout ? 'O tempo acabou' : 'Resposta correta:', fbCorrect: s.fb.correct, fbBg: ok ? 'hsl(150 55% 96%)' : 'hsl(6 91% 97%)', fbFg: ok ? 'hsl(150 55% 30%)' : RED, fbBtn: ok ? GREEN : RED, fbBtnSh: ok ? '0 4px 0 hsl(150 55% 28%)' : '0 4px 0 hsl(6 100% 34%)', onNext: () => this.nextQ(), onWhy: () => this.openWhy(), whyOpen: s.why, whyText: q.explicacao, whyFonte: E.fmtFonte(q.fonte), onWhyClose: () => this.setState({ why: false }), fbRequeue: !ok && !noReq }); }
    else Object.assign(v, { fbOpen: false, whyOpen: false });
    return v;
  }

  vEnd() {
    const e = this.state.end, a = this.state.endAnim; if (!e) return {};
    const T = { licao: 'Lição concluída!', caso: 'Caso resolvido!', checkpoint: 'Checkpoint concluído!', mestre: e.pass ? 'Desafio Mestre vencido!' : 'Quase lá no Desafio Mestre', skip: e.pass ? 'Unidade liberada!' : 'Ainda não foi desta vez', placement: 'Teste de nivelamento', review: 'Revisão concluída!', errors: 'Erros revisados!', term: 'Treino concluído!', reforco: 'Reforço concluído!' };
    const sub = e.mode === 'placement' ? (e.pass ? 'Você acertou ' + e.acc + '%. As unidades básicas já estão concluídas.' : 'Você acertou ' + e.acc + '%. Vamos começar do básico, no seu ritmo.') : e.mode === 'skip' && !e.pass ? 'Você precisava de 75%. Siga pela trilha e tente de novo depois.' : e.mode === 'mestre' && !e.pass ? 'O certificado sai com 80% de acerto. Você fez ' + e.acc + '%.' : e.perfect ? 'Lição perfeita, sem nenhum erro.' : e.title;
    const stats = [{ label: 'XP ganho', val: '+' + a.xp, icon: 'zap', fg: 'hsl(32 82% 40%)', bg: 'hsl(40 92% 46% / .15)', d: '.15s', ref: this.endXpRef }, { label: 'Precisão', val: a.acc + '%', icon: 'target', fg: GREEN, bg: 'hsl(150 55% 40% / .14)', d: '.23s', ref: null }, { label: 'Tempo', val: this.E.mmss(e.dur), icon: 'clock', fg: 'hsl(212 72% 48%)', bg: 'hsl(212 72% 48% / .12)', d: '.31s', ref: null }];
    return { onEndReport: () => this.openReport({ tipo: 'fase', ref: e.key || e.mode, label: 'Fase concluída', titulo: e.title }), endTitle: T[e.mode] || 'Concluído!', endSub: sub, endStats: stats, endXpRef: this.endXpRef, endPerfect: e.perfect && e.mode !== 'placement', endCombo: e.combo > 0, endComboT: '+' + e.combo + ' XP de combo', onEndNext: () => this.nextPost(), endIcon: e.pass ? 'trophy' : 'sprout', endIconBg: e.pass ? 'linear-gradient(145deg,#FFD66B,#FF8A3D)' : 'linear-gradient(145deg,#3DFFBE,#14B8A6)' };
  }

  vPost() {
    const it = this.state.postItem, p = this._p, E = this.E; if (!it) return {};
    const v = { postStreak: it.k === 'streak', postGoal: it.k === 'goal', postBadge: it.k === 'badge', postCert: it.k === 'cert', onPostNext: () => it.view ? this.setState({ screen: 'app', postItem: null }) : this.nextPost(), postBtn: it.view ? 'Voltar ao perfil' : 'Continuar' };
    if (v.postStreak) {
      const h = React.createElement, mon = E.monday(this.today()), tk = this.tk(), days = p.streak.days || [];
      v.rollEl = h('span', { style: { position: 'relative', display: 'inline-block', height: 72, overflow: 'hidden', verticalAlign: 'top' } },
        h('span', { key: 'o', style: { position: 'absolute', left: 0, right: 0, textAlign: 'center', animation: 'rollOut .45s .55s cubic-bezier(.16,1,.3,1) forwards' } }, it.from),
        h('span', { key: 'n', style: { display: 'inline-block', animation: 'rollIn .45s .55s cubic-bezier(.16,1,.3,1) both' } }, it.to));
      v.week = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map((l, i) => { const d = new Date(mon); d.setDate(d.getDate() + i); const k = E.dkey(d), on = days.indexOf(k) >= 0, today = k === tk, work = p.workDays.indexOf(d.getDay()) >= 0; return { l, on, off: !on, today, bg: on ? 'hsl(28 90% 52%)' : 'transparent', fg: on ? '#fff' : work ? MUT : 'hsl(0 0% 75%)', bd: today ? 'hsl(28 90% 52%)' : 'hsl(0 0% 90%)', anim: today ? 'fillIn .5s .9s cubic-bezier(.34,1.56,.64,1) both' : 'none' }; });
      v.streakTitle = it.to === 1 ? 'Ofensiva iniciada!' : it.to + ' dias de ofensiva!';
      v.streakSub = it.used ? 'Usamos ' + it.used + ' congelamento para proteger sua ofensiva.' : 'Volte no próximo dia útil para continuar.';
      v.hasMilestone = !!it.milestone; v.milestoneT = it.milestone ? 'Marco de ' + it.milestone.d + ' dias: +' + it.milestone.t + ' Takitos' : '';
    }
    if (v.postGoal) { v.goalT = 'Meta diária batida!'; v.goalS = it.goal + ' XP hoje. É assim que o hábito se forma.'; }
    if (v.postBadge) { v.bNome = it.b.nome; v.bSub = it.b.sub; v.bIcon = it.b.icon; v.bG = it.b.g; }
    if (v.postCert) { const c = it.c; v.cNome = c.nome || p.name; v.cTrilha = c.trilha; v.cData = c.data; v.onShare = () => this.shareCert(c); v.onPrintCert = () => this.viewCert(c, it.view ? null : 'post'); }
    return v;
  }
  openPop(key, btn, hasSkip) {
    const c = this.pathRef.current; if (!c || !btn) return this.setState({ popNode: key, popUp: false });
    const NEED = (hasSkip ? 262 : 206) + 12, BAR = 84, TOP = 92;
    const cr = c.getBoundingClientRect(), br = btn.getBoundingClientRect();
    const below = cr.bottom - BAR - br.bottom, above = br.top - cr.top - TOP;
    const canDown = c.scrollHeight - c.clientHeight - c.scrollTop, canUp = c.scrollTop;
    let up = false, dy = 0;
    if (below >= NEED) up = false;
    else if (below + canDown >= NEED) dy = NEED - below;
    else if (above >= NEED) up = true;
    else if (above + canUp >= NEED) { up = true; dy = -(NEED - above); }
    else { up = above > below; }
    this.setState({ popNode: key, popUp: up });
    if (dy) c.scrollBy({ top: dy, behavior: 'smooth' });
  }

  // ---------- feedback ----------
  openReport(ctx) {
    const cat = ctx.tipo === 'questao' ? 'incorreta' : ctx.tipo === 'fase' ? 'dificuldade' : 'bug';
    this.setState({ rep: { ctx, cat, text: '', files: [], sending: false, done: null, err: '' }, popNode: null });
  }
  repSet(patch) { this.setState(s => ({ rep: Object.assign({}, s.rep, patch) })); }
  addRepFiles(list) {
    [].slice.call(list || []).forEach(f => {
      const id = Math.random().toString(36).slice(2), base = { id, nome: f.name, tamanho: f.size, tipo: f.type || '', thumb: null };
      this.setState(s => ({ rep: Object.assign({}, s.rep, { files: s.rep.files.concat([base]) }) }));
      if (!/^image\//.test(f.type)) return;
      const rd = new FileReader();
      rd.onload = () => { const img = new Image(); img.onload = () => { const k = Math.min(1, 240 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); const t = cv.toDataURL('image/jpeg', .72); const k2 = Math.min(1, 1100 / Math.max(img.width, img.height)), cv2 = document.createElement('canvas'); cv2.width = Math.round(img.width * k2); cv2.height = Math.round(img.height * k2); cv2.getContext('2d').drawImage(img, 0, 0, cv2.width, cv2.height); const full = cv2.toDataURL('image/jpeg', .8); this.setState(s => s.rep ? ({ rep: Object.assign({}, s.rep, { files: s.rep.files.map(x => x.id === id ? Object.assign({}, x, { thumb: t, full }) : x) }) }) : null); }; img.src = rd.result; };
      rd.readAsDataURL(f);
    });
  }
  sendReport() {
    const r = this.state.rep, p = this._p; if (!r || r.sending) return;
    if (!r.text.trim() && !r.files.length) return this.repSet({ err: 'Escreva o feedback ou adicione um anexo.' });
    const entry = { id: window.AcademyFeedback.newId(), createdAt: new Date().toISOString(), categoria: r.cat, texto: r.text, ctx: r.ctx,
      anexos: r.files.map(f => ({ nome: f.nome, tamanho: f.tamanho, tipo: f.tipo, thumb: f.thumb, full: f.full || null })),
      user: { email: p.session ? p.session.email : null, nome: p.name, equipe: p.team, persona: p.persona }, app: { tela: this.state.screen + (this.state.sub ? '/' + this.state.sub : '/' + this.state.tab), versao: 'app-1.1' } };
    this.repSet({ sending: true, err: '' });
    window.AcademyFeedback.send(entry, p.offlineSim).then(saved => { this.repSet({ sending: false, done: saved }); this.setState({ repTick: Date.now() }); });
  }
  flushReports() { if (!window.AcademyFeedback) return; window.AcademyFeedback.flush(this._p && this._p.offlineSim).then(n => { if (n) { this.toast(n + (n === 1 ? ' feedback pendente enviado' : ' feedbacks pendentes enviados'), 'cloud-upload'); this.setState({ repTick: Date.now() }); } }); }
  vReport() {
    const r = this.state.rep; if (!r) return { repOpen: false };
    const CATS = [['bug', 'Bug', 'bug'], ['dificuldade', 'Dificuldade', 'circle-help'], ['incorreta', 'Informação incorreta', 'triangle-alert'], ['outro', 'Outros', 'message-square']];
    const kb = n => n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
    const ICON = { questao: 'circle-help', fase: 'map-pin', geral: 'message-square-text', tela: 'smartphone' };
    const d = r.done, n = r.text.length;
    return { repOpen: true, repForm: !d, repDone: !!d, repCtxIcon: ICON[r.ctx.tipo] || 'message-square-text', repCtxLabel: r.ctx.label, repCtxTitle: r.ctx.titulo, repHasCtxTitle: !!r.ctx.titulo,
      repCats: CATS.map(([id, t, icon]) => ({ t, icon, bd: r.cat === id ? RED : BD, bg2: r.cat === id ? REDT2 : '#fff', fg2: r.cat === id ? RED : INK, bg: r.cat === id ? '#fff' : 'transparent', fg: r.cat === id ? INK : MUT, sh: r.cat === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.repSet({ cat: id }) })),
      repText: r.text, onRepText: e => this.repSet({ text: e.target.value, err: '' }), repCount: n ? n.toLocaleString('pt-BR') + (n === 1 ? ' caractere' : ' caracteres') : '',
      repFileRef: this.repFileRef, onRepPick: () => this.repFileRef.current && this.repFileRef.current.click(), onRepFiles: e => { this.addRepFiles(e.target.files); e.target.value = ''; },
      repFiles: r.files.map(f => ({ nome: f.nome, size: kb(f.tamanho), hasThumb: !!f.thumb, noThumb: !f.thumb, thumb: f.thumb || '', icon: /pdf/.test(f.tipo) ? 'file-text' : /video/.test(f.tipo) ? 'file-video' : /image/.test(f.tipo) ? 'image' : 'paperclip', onRemove: () => this.repSet({ files: this.state.rep.files.filter(x => x.id !== f.id) }) })),
      repHasFiles: r.files.length > 0, repFileCount: r.files.length + (r.files.length === 1 ? ' anexo' : ' anexos'),
      repHasErr: !!r.err, repErr: r.err, repSending: r.sending, repIdle: !r.sending, onRepSend: () => this.sendReport(), onRepClose: () => { if (!r.sending) this.setState({ rep: null }); },
      repDoneId: d ? d.id : '', repSynced: !!(d && d.status === 'enviado'), repPending: !!(d && d.status !== 'enviado'), onRepAnother: () => this.openReport(r.ctx) };
  }
  vReportView() {
    const s = this.state, f = (window.AcademyFeedback ? window.AcademyFeedback.list() : []).find(x => x.id === s.repViewId);
    if (!f) return { rvNone: true, rvSome: false };
    const CAT = { bug: ['Bug', 'bug'], dificuldade: ['Dificuldade', 'circle-help'], incorreta: ['Informação incorreta', 'triangle-alert'], conteudo: ['Informação incorreta', 'triangle-alert'], sugestao: ['Outros', 'message-square'], outro: ['Outros', 'message-square'] }[f.categoria] || ['Outros', 'message-square'];
    const kb = n => n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
    const ICON = { questao: 'circle-help', fase: 'map-pin', geral: 'message-square-text' };
    const imgs = f.anexos.filter(a => a.thumb || a.full), files = f.anexos.filter(a => !(a.thumb || a.full));
    const lightIdx = s.repLight, light = lightIdx != null ? imgs[lightIdx] : null;
    const dt = new Date(f.createdAt), meta = [['Protocolo', f.id], ['Enviado em', dt.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })], ['Tela', f.app && f.app.tela ? f.app.tela : '—']];
    if (f.ctx.trilha) meta.push(['Trilha', f.ctx.trilha]);
    if (f.ctx.unidade) meta.push(['Unidade', f.ctx.unidade]);
    return { rvNone: false, rvSome: true, rvCat: CAT[0], rvCatIcon: CAT[1], rvOk: f.status === 'enviado', rvPend: f.status !== 'enviado', rvCtxIcon: ICON[f.ctx.tipo] || 'message-square-text', rvCtxLabel: f.ctx.label, rvCtxTitle: f.ctx.titulo || '', rvHasCtxTitle: !!f.ctx.titulo,
      rvText: f.texto || '', rvHasText: !!(f.texto || '').trim(), rvNoText: !(f.texto || '').trim(), rvLen: (f.texto || '').length.toLocaleString('pt-BR') + ' caracteres',
      rvImgs: imgs.map((a, i) => ({ src: a.full || a.thumb, nome: a.nome, onOpen: () => this.setState({ repLight: i }) })), rvHasImgs: imgs.length > 0,
      rvFiles: files.map(a => ({ nome: a.nome, size: kb(a.tamanho), icon: /pdf/.test(a.tipo) ? 'file-text' : /video/.test(a.tipo) ? 'file-video' : 'paperclip' })), rvHasFiles: files.length > 0,
      rvAnexosT: f.anexos.length ? f.anexos.length + (f.anexos.length === 1 ? ' anexo' : ' anexos') : '', rvHasAnexos: f.anexos.length > 0,
      rvMeta: meta.map(([k, v]) => ({ k, v })),
      rvLight: !!light, rvLightSrc: light ? (light.full || light.thumb) : '', rvLightNome: light ? light.nome : '', rvLightPos: light ? (lightIdx + 1) + ' de ' + imgs.length : '', rvLightMulti: imgs.length > 1,
      onRvLightClose: () => this.setState({ repLight: null }), onRvPrev: e => { e.stopPropagation(); this.setState({ repLight: (lightIdx - 1 + imgs.length) % imgs.length }); }, onRvNext: e => { e.stopPropagation(); this.setState({ repLight: (lightIdx + 1) % imgs.length }); },
      onRvAgain: () => this.openReport(f.ctx) };
  }
  vReports() {
    const list = (window.AcademyFeedback ? window.AcademyFeedback.list() : []), CAT = { bug: 'Bug', dificuldade: 'Dificuldade', incorreta: 'Informação incorreta', conteudo: 'Informação incorreta', sugestao: 'Outros', outro: 'Outros' };
    return { repList: list.map(f => ({ id: f.id, cat: CAT[f.categoria] || 'Outros', onOpen: () => this.setState({ sub: 'reportView', repViewId: f.id }), ctx: f.ctx.label + (f.ctx.titulo ? ' · ' + f.ctx.titulo : ''), texto: f.texto || '(só anexo)', data: new Date(f.createdAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }), anexos: f.anexos.length ? f.anexos.length + (f.anexos.length === 1 ? ' anexo' : ' anexos') : '', hasAnexos: f.anexos.length > 0, ok: f.status === 'enviado', pend: f.status !== 'enviado' })),
      repListEmpty: !list.length, repPendCount: list.filter(x => x.status !== 'enviado').length, onRepNew: () => this.openReport({ tipo: 'geral', label: 'Feedback geral', titulo: '' }) };
  }

  viewCert(c, from) { this.setState({ screen: 'app', sub: 'cert', certView: c, certFrom: from || null, certFull: false }); }
  vCert() {
    const s = this.state, c = s.certView || {}, nome = c.nome || this._p.name || 'Colaborador', trilha = c.trilha || '', data = c.data || '';
    let hh = 0; (nome + trilha + data).split('').forEach(ch => { hh = (hh * 31 + ch.charCodeAt(0)) >>> 0; });
    return { cvNome: nome, cvTrilha: trilha, cvData: data, cvCodigo: 'TKA-' + String(hh % 1000000).padStart(6, '0'),
      cvDesc: 'Venceu o Desafio Mestre da trilha, uma simulação cronometrada e sem dicas com as questões mais difíceis' + (c.acc ? ', com ' + c.acc + '% de acerto' : '') + '. Domínio comprovado da trilha no TakeatHub Academy.',
      cvFull: !!s.certFull, onCvFull: () => this.setState({ certFull: true }), onCvFullClose: () => this.setState({ certFull: false }),
      onCvPrint: () => this.openCert(c), onCvShare: () => this.shareCert(c) };
  }
  openCert(c) {
    this.setState({ certView: c }, () => setTimeout(() => { try { window.print(); } catch (x) {} }, 350));
  }
  shareCert(c) {
    const cv = document.createElement('canvas'); cv.width = 1200; cv.height = 800; const x = cv.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, 1200, 800); x.fillStyle = '#df1c0d'; x.fillRect(0, 0, 1200, 14); x.fillRect(0, 786, 1200, 14);
    x.strokeStyle = 'hsl(0,0%,90%)'; x.lineWidth = 2; x.strokeRect(40, 40, 1120, 720);
    x.fillStyle = '#df1c0d'; x.font = '700 22px Poppins, sans-serif'; x.fillText('TAKEATHUB ACADEMY · CERTIFICADO', 90, 130);
    x.fillStyle = '#212121'; x.font = '800 64px Poppins, sans-serif'; x.fillText(c.nome || this._p.name, 90, 300);
    x.fillStyle = '#757575'; x.font = '400 28px Poppins, sans-serif'; x.fillText('concluiu o Desafio Mestre da trilha', 90, 370);
    x.fillStyle = '#212121'; x.font = '700 40px Poppins, sans-serif'; x.fillText(c.trilha, 90, 430);
    x.fillStyle = '#757575'; x.font = '400 24px Poppins, sans-serif'; x.fillText('Emitido em ' + c.data, 90, 680);
    const img = new Image(); img.onload = () => { x.drawImage(img, 980, 560, 130, 130); dl(); }; img.onerror = dl; img.src = (window.ACADEMY_IMG && window.ACADEMY_IMG['assets/academy-book.png']) || './assets/academy-book.png';
    function dl() { cv.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'certificado-takeathub-academy.png'; a.click(); }); }
    this.toast('Imagem do certificado gerada', 'share-2');
  }

  vFlash() {
    const f = this.state.flash; if (!f) return {};
    const left = Math.max(0, (f.end - this.state.now) / 1000);
    const mk = (side, val) => { const used = side === 'l' ? !!f.mL[val] : Object.values(f.mL).indexOf(val) >= 0, sel = side === 'l' ? f.selL === val : f.selR === val, bad = f.bad && (side === 'l' ? f.bad.l : f.bad.r) === val; return { text: val, onClick: () => this.tapFlash(side, val), bd: sel || bad ? RED : BD, bg: sel ? REDT2 : bad ? REDT : '#fff', fg: sel || bad ? RED : INK, anim: used ? 'pairOut .45s cubic-bezier(.16,1,.3,1) forwards' : bad ? 'shake .3s ease' : 'none', pe: used ? 'none' : 'auto' }; };
    return { flashPlaying: !f.done, flashDone: f.done, flashLeft: Math.ceil(left) + 's', flashW: (left / 60 * 100) + '%', flashScore: f.score, flL: f.left.map(x => mk('l', x)), flR: f.right.map(x => mk('r', x)),
      flashRec: f.rec, flashRecT: 'Recorde pessoal: ' + this._p.flashRecord, flashXp: '+' + (f.xp || 0) + ' XP', onFlashAgain: () => this.startFlash(), onFlashExit: () => this.goApp({ tab: 'practice' }), onFlashQuit: () => this.setState({ screen: 'app', flash: null }) };
  }

  vOverlays() {
    const s = this.state, p = this._p, E = this.E, C = this.C, v = {};
    v.tempOpen = !!s.temp; if (s.temp) Object.assign(v, { tempForm: s.temp.step === 'form', tempSent: s.temp.step === 'sent', tempLoading: !!s.temp.loading, tempIdle: !s.temp.loading, hasTempErr: !!s.temp.err, tempErr: s.temp.err || '', tempNome: s.temp.nome || '', tempMasc: s.temp.masc || '', tempPwd: s.temp.pwd || '', onTempGen: e => this.genTemp(e), onTempClose: () => !s.temp.loading && this.setState({ temp: null }), onTempLogin: () => this.setState({ temp: null, lg: Object.assign({}, s.lg, { pwd: '' }) }), stop: e => e.stopPropagation(), tempEmail: s.lg.email, onTempEmail: e => this.setState({ lg: Object.assign({}, s.lg, { email: e.target.value }) }) });
    v.firstOpen = !!s.first; if (s.first) { const f = s.first, set = k => e => this.setState({ first: Object.assign({}, this.state.first, { [k]: e.target.value, err: '' }) }); Object.assign(v, { fPwd: f.pwd, fPwd2: f.pwd2, fTeam: f.team, fBirth: f.birth, onFPwd: set('pwd'), onFPwd2: set('pwd2'), onFTeam: set('team'), onFBirth: set('birth'), fTeamDD: this.dd('fteam', f.team, C.TEAMS.map(t => ({ t, sel: f.team === t, onPick: () => this.setState({ first: Object.assign({}, this.state.first, { team: t }) }) }))),
        onFBirthMask: e => { const d = e.target.value.replace(/\D/g, '').slice(0, 8); const v = d.length > 4 ? d.slice(0, 2) + '/' + d.slice(2, 4) + '/' + d.slice(4) : d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d; this.setState({ first: Object.assign({}, this.state.first, { birth: v, err: '' }) }); }, hasFErr: !!f.err, fErr: f.err, onFirstSave: () => this.saveFirst(), fEmail: f.email }); }
    v.sheetOpen = !!s.sheet; v.onSheetClose = () => this.setState({ sheet: null });
    v.sheetTracks = s.sheet === 'tracks'; v.sheetStreak = s.sheet === 'streak'; v.sheetCoins = s.sheet === 'coins'; v.sheetUnit = s.sheet === 'unit';
    if (v.sheetTracks) {
      const order = (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).order, list = this.trackList();
      const sorted = [list[0]].concat(order.map(id => list.find(t => t.id === id)).filter(Boolean)).concat(list.filter(t => t.id !== 'ATD' && order.indexOf(t.id) < 0));
      const recId = (order.find(id => E.trackPct(C, this.bank, this.atd, p, id) < 100)) || null;
      v.trackRows = sorted.map(t => { const pc = E.trackPct(C, this.bank, this.atd, p, t.id), sel = p.activeTrack === t.id, nU = this.units(t.id).length; return { nome: t.nome, icon: t.icon, pct: pc + '%', sub: t.id === 'ATD' ? (nU ? nU + ' unidades · personalizável pelo líder' : 'Aguardando o líder montar') : nU + ' unidades', rec: t.id === recId, sel, bd: sel ? RED : BD, bg: sel ? REDT2 : '#fff', onClick: () => { this.upd(q => { q.activeTrack = t.id; }); this.setState({ sheet: null, bannerUnit: 0, popNode: null }, () => this.scrollToCurrent(true)); } }; });
    }
    if (v.sheetStreak) {
      const mon = E.monday(this.today()), tk = this.tk(), days = p.streak.days || [];
      v.sWeek = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map((l, i) => { const d = new Date(mon); d.setDate(d.getDate() + i); const k = E.dkey(d), on = days.indexOf(k) >= 0; return { l, n: d.getDate(), bg: on ? 'hsl(28 90% 52%)' : 'hsl(0 0% 95%)', fg: on ? '#fff' : (p.workDays.indexOf(d.getDay()) >= 0 ? MUT : 'hsl(0 0% 75%)'), bd: k === tk ? 'hsl(28 90% 52%)' : 'transparent' }; });
      v.sCount = E.streakNow(p, this.today()); v.sBest = 'Recorde: ' + (p.streak.best || 0) + ' dias'; v.sFreezes = p.streak.freezes + '/2 congelamentos';
      v.sMiles = [7, 30, 100, 365].map(d => ({ t: d + ' dias', done: (p.streak.best || 0) >= d, bg: (p.streak.best || 0) >= d ? 'hsl(28 90% 52% / .14)' : 'hsl(0 0% 95%)', fg: (p.streak.best || 0) >= d ? 'hsl(28 80% 40%)' : MUT }));
      v.sToday = this.today().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
      v.onAdvanceDay2 = () => { this.upd(q => { q.dayOffset++; }); this.checkWeek(); this.toast('Agora é ' + this.today().toLocaleDateString('pt-BR', { weekday: 'long' }), 'calendar'); };
    }
    if (v.sheetCoins) {
      const k = this.tk(), dr = p.day[k] || { claimed: {} }, ms = E.missionsFor(C, k);
      v.cSaldo = p.takitos; v.cMissions = ms.map(m => ({ t: m.t, pct: Math.round(Math.min(m.meta, dr[m.m] || 0) / m.meta * 100) + '%', prog: Math.min(m.meta, dr[m.m] || 0) + '/' + m.meta, done: !!(dr.claimed && dr.claimed[m.k]), r: '+' + C.MISSION_REWARD }));
      v.cDone = ms.filter(m => dr.claimed && dr.claimed[m.k]).length + '/3 concluídas'; v.onCLoja = () => this.setState({ sheet: null, screen: 'app', sub: 'loja' }); v.onCAll = () => this.setState({ sheet: null, screen: 'app', tab: 'missions', sub: null });
    }
    if (v.sheetUnit) {
      const u = this.units()[s.bannerUnit] || this.units()[0];
      v.uTitle = u ? u.title : ''; v.uRegra = u && u.regra ? u.regra : ''; v.uHasRegra = !!(u && u.regra); v.uIsAtd = p.activeTrack === 'ATD';
      v.uLicoes = u ? u.nodes.filter(n => n.type === 'licao').map(n => ({ t: n.title, done: !!p.done[n.key] })) : [];
      v.uQs = u ? u.qs.length + ' questões nesta unidade' : '';
      v.uScore = u && C.MONITORIA[u.title] != null ? 'Sua nota na Monitoria: ' + C.MONITORIA[u.title] : ''; v.uHasScore = !!(u && C.MONITORIA[u.title] != null);
    }
    v.chestOpen = !!s.chest; if (s.chest) { const rw = s.chest.reward; Object.assign(v, { chestTitle: rw.k === 'takitos' ? '+' + rw.n + ' Takitos' : rw.k === 'freeze' ? 'Congelamento de ofensiva' : 'XP em dobro por 15 min', chestSub: rw.k === 'takitos' ? 'Use na Loja do Hub.' : rw.k === 'freeze' ? 'Protege sua ofensiva num dia útil sem lição.' : 'Todo XP ganho nos próximos 15 minutos vale o dobro.', chestCoin: rw.k === 'takitos', chestIcon: rw.k === 'freeze' ? 'snowflake' : 'zap', chestNotCoin: rw.k !== 'takitos', onCollect: () => this.collectChest() }); }
    Object.assign(v, this.vBuy(), this.vReport());
    v.wrOpen = !!s.weekResult; if (s.weekResult) { const w = s.weekResult, L = C.LEAGUES; Object.assign(v, { wrFromG: L[w.from].g, wrToG: L[w.to].g, wrFromIcon: L[w.from].icon || 'trophy', wrToIcon: L[w.to].icon || 'trophy', wrChanged: w.from !== w.to, wrSame: w.from === w.to, wrTitle: w.res === 'up' ? 'Você subiu para a Liga ' + L[w.to].nome + '!' : w.res === 'down' ? 'Você caiu para a Liga ' + L[w.to].nome : 'Você se manteve na Liga ' + L[w.to].nome, wrText: 'Terminou a semana em ' + w.rank + 'º lugar.' + (w.res === 'up' ? ' +' + C.LEAGUE_RULES.premioPromocao + ' Takitos pela promoção.' : ''), onWrClose: () => { const up = w.res === 'up'; this.setState({ weekResult: null }); if (up) setTimeout(() => this.fly('coin', this.frameCenter(), 5), 60); } }); }
    v.exitAsk = s.exitAsk && s.screen === 'lesson'; v.onExitCancel = () => this.setState({ exitAsk: false }); v.onExitConfirm = () => this.setState({ exitAsk: false, screen: 'app', lesson: null, ex: null, fb: null });
    v.resetAsk = s.resetAsk; v.onResetCancel = () => this.setState({ resetAsk: false });
    v.onResetConfirm = () => { const d = this.defaults(), keep = { session: p.session, uid: p.uid, phone: p.phone, users: p.users, remembered: p.remembered, name: p.name, team: p.team, cargo: p.cargo, role: p.role }; this.E._uc = {}; this.save(Object.assign(d, keep)); this.setState({ resetAsk: false, screen: 'onb', onb: { step: 0 }, sub: null }); };
    return v;
  }
}
