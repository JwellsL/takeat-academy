// Busca de atualização do app Android: compara o build instalado com o último APK publicado
// no GitHub Releases (o workflow android.yml publica um release "build-N" a cada push).
export const REPO = 'JwellsL/takeat-academy';
/* global __APP_BUILD__, __APP_VERSION__ */
export const BUILD = Number(typeof __APP_BUILD__ !== 'undefined' ? __APP_BUILD__ : 0) || 0;
export const VERSION = typeof __APP_VERSION__ !== 'undefined' ? __APP_VERSION__ : '1.0.0';
export const ehNativo = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

export async function buscarAtualizacao() {
  const r = await fetch('https://api.github.com/repos/' + REPO + '/releases/latest', { headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store' });
  if (r.status === 404) return { disponivel: false, semRelease: true };
  if (!r.ok) throw new Error('GitHub respondeu ' + r.status);
  const j = await r.json();
  const build = Number(String(j.tag_name || '').replace(/\D/g, '')) || 0;
  const apk = (j.assets || []).find(a => /\.apk$/i.test(a.name));
  return { disponivel: !!apk && build > BUILD, build, url: apk ? apk.browser_download_url : null, publicadoEm: j.published_at, notas: j.body || '' };
}

// Abre o download do APK no navegador do sistema (o Capacitor manda links externos para fora do app).
export function baixar(url) {
  if (!url) return;
  try { window.open(url, '_system'); } catch (e) {}
  setTimeout(() => { if (document.visibilityState === 'visible') location.href = url; }, 400);
}
