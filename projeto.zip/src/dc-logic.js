// Base equivalente ao `DCLogic` do runtime do protótipo: o estado é mesclado de forma
// SÍNCRONA (this.state já reflete o patch logo após setState) e o host re-renderiza.
export default class DCLogic {
  constructor(props) {
    this.props = props || {};
    this.state = {};
    this.__host = null;
  }
  setState(update, cb) {
    this.__host && this.__host.__setLogicState(update, cb);
  }
  forceUpdate() {
    this.__host && this.__host.forceUpdate();
  }
  componentDidMount() {}
  componentDidUpdate() {}
  componentWillUnmount() {}
  renderVals() {
    return {};
  }
}
