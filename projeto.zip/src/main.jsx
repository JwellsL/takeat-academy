import React from 'react';
import { createRoot } from 'react-dom/client';
import './prototype.css';
import App from './App.jsx';

window.React = React;
createRoot(document.getElementById('root')).render(<App />);

if ('serviceWorker' in navigator && import.meta.env.PROD && !(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}

// Teclado no celular: o campo focado vai para o centro da área visível, com folga acima do
// teclado (sem isso a senha ficava escondida ou colada no teclado).
const ehCampo = el => el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') && !/^(checkbox|radio|button|submit|file)$/.test(el.type);
function centralizar(el) {
  if (!ehCampo(el) || document.activeElement !== el) return;
  // Rola só o contêiner rolável mais próximo (scrollIntoView também deslocaria a moldura do app).
  let sc = el.parentElement;
  while (sc && !(/(auto|scroll)/.test(getComputedStyle(sc).overflowY) && sc.scrollHeight > sc.clientHeight + 2)) sc = sc.parentElement;
  const frame = document.querySelector('.ac-frame');
  if (frame) frame.scrollTop = 0;
  if (!sc) return;
  const a = sc.getBoundingClientRect(), b = el.getBoundingClientRect();
  const alvo = sc.scrollTop + (b.top - a.top) - (sc.clientHeight - b.height) * 0.4;
  sc.scrollTo({ top: Math.max(0, alvo), behavior: 'smooth' });
}
document.addEventListener('focusin', e => {
  if (!ehCampo(e.target)) return;
  [120, 380, 700].forEach(t => setTimeout(() => centralizar(e.target), t));
});
const vv = window.visualViewport;
if (vv) vv.addEventListener('resize', () => centralizar(document.activeElement));
