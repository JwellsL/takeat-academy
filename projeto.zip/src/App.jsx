import React from 'react';
import AcademyLogic from './AcademyLogic.js';
import View from './View.jsx';

// Host React da lógica (mesmo contrato do StreamableComponent do protótipo).
export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { v: 0 };
    this.logic = new AcademyLogic(props);
    this.logic.__host = this;
  }
  __setLogicState(update, cb) {
    const prev = this.logic.state;
    const patch = typeof update === 'function' ? update(prev) : update;
    this.logic.state = { ...prev, ...patch };
    this.setState(s => ({ v: s.v + 1 }), cb);
  }
  componentDidMount() {
    try { this.logic.componentDidMount(); } catch (e) { console.error(e); }
  }
  componentDidUpdate(prevProps) {
    try { this.logic.componentDidUpdate(prevProps); } catch (e) { console.error(e); }
  }
  componentWillUnmount() {
    try { this.logic.componentWillUnmount(); } catch (e) { console.error(e); }
  }
  render() {
    return <View v={{ ...this.props, ...this.logic.renderVals() }} />;
  }
}
