# TakeatHub Academy — app mobile

App de aprendizado no estilo Duolingo para a plataforma Takeat. Roda como **PWA instalável**
(funciona offline) e como **app Android nativo** (Capacitor). A interface é a do protótipo
`prototype/original.html`, que é a **fonte da verdade**.

## Rodar

```bash
npm install
npm run dev        # http://localhost:5181
npm run build      # gera dist/ (PWA)
```

Login de teste: qualquer e-mail `@takeat.app` com a senha `academy123`.
Estados de demonstração: `?demo=login`, `?demo=onb0`…`onb4`, `?demo=path` etc.

## Como o app é montado

| Parte | Arquivo |
|---|---|
| Interface (gerada do protótipo, não editar à mão) | `src/View.jsx`, `src/pseudo.css` |
| Template do protótipo | `tools/prototype.dc.html` |
| Conversor template → JSX | `tools/dc2jsx.mjs` (`npm run convert`) |
| Lógica: estado, regras, gamificação | `src/AcademyLogic.js` (portada 1:1 do protótipo) |
| Host React (estado síncrono, igual ao runtime do protótipo) | `src/App.jsx`, `src/dc-logic.js` |
| Banco de questões, ligas, regras, ícones | `public/legacy/*.js` |
| PWA | `public/manifest.webmanifest`, `public/sw.js`, `public/icons/` |
| Android (Capacitor) | `android/`, `capacitor.config.json` |

Para mudar a interface: edite `tools/prototype.dc.html`, rode `npm run convert` e depois a comparação.

## Comparação com o protótipo (pixel a pixel)

Com o app (`npm run dev`, porta 5181) e a pasta `prototype/` servida na 5182
(`python -m http.server 5182 --directory prototype`):

```bash
node tools/compare.mjs            # todos os fluxos
node tools/compare.mjs licao      # só fluxos com "licao" no nome
SAVE=1 node tools/compare.mjs     # salva as capturas em tools/out/
```

Os dois lados rodam com o mesmo relógio, a mesma semente de aleatoriedade e as animações
reduzidas. O resultado é a igualdade por tela e a igualdade geral.

## Android

O APK é compilado pelo GitHub Actions (`.github/workflows/android.yml`) a cada push na `main`.
Ele fica disponível como artefato da execução. Para compilar localmente, é preciso o JDK 17 e o Android SDK:

```bash
npm run cap:sync
cd android && ./gradlew assembleDebug
```

iOS: em um Mac, rode `npm i -D @capacitor/ios && npx cap add ios && npx cap open ios`.

O PWA é publicado no GitHub Pages pelo `.github/workflows/pages.yml`. Ative o Pages com a origem "GitHub Actions".
