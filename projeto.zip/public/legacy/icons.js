(function () {
  var KF = '<style>:host{display:inline-flex;flex-shrink:0;line-height:0}@keyframes drawStroke{to{stroke-dashoffset:0}}@keyframes orbpop{0%,100%{transform:scale(1)}50%{transform:scale(1.5)}}@keyframes orbtail{0%,100%{opacity:.3}50%{opacity:1}}@media (prefers-reduced-motion:reduce){*{animation:none!important;stroke-dashoffset:0!important}}</style>';
  function key(n) { return String(n || '').split('-').map(function (s) { return s ? s[0].toUpperCase() + s.slice(1) : ''; }).join(''); }
  function root(el) { return el.shadowRoot || el.attachShadow({ mode: 'open' }); }
  function render(el) {
    var r = root(el);
    if (!window.lucide) { r.innerHTML = KF; return; }
    var node = window.lucide.icons[key(el.getAttribute('name'))];
    r.innerHTML = KF;
    if (!node) return;
    var s = el.getAttribute('size') || 18;
    var svg = window.lucide.createElement(node);
    svg.setAttribute('width', s); svg.setAttribute('height', s);
    svg.setAttribute('stroke-width', el.getAttribute('stroke') || 2);
    if (el.getAttribute('fill')) svg.setAttribute('fill', el.getAttribute('fill'));
    if (el.hasAttribute('draw')) {
      [].forEach.call(svg.querySelectorAll('path,circle,line,polyline'), function (c, i) {
        c.setAttribute('pathLength', '1');
        c.style.strokeDasharray = '1'; c.style.strokeDashoffset = '1';
        c.style.animation = 'drawStroke .5s cubic-bezier(.16,1,.3,1) ' + (0.12 + i * 0.12) + 's forwards';
      });
    }
    r.appendChild(svg);
  }
  var ANEL = [[60,17,6.5,'#df1c0d'],[71.55,18.3,7.28,'#8f1109'],[82.17,22.08,5.72,'#ff2419'],[90.99,28.04,6.52,'#df1c0d'],[97.29,35.71,7.27,'#ff2419'],[100.58,44.45,5.71,'#8f1109'],[100.58,53.55,6.53,'#df1c0d'],[97.29,62.29,7.26,'#8f1109'],[90.99,69.96,5.70,'#ff2419'],[82.17,75.92,6.55,'#8f1109'],[71.55,79.70,7.25,'#df1c0d'],[60,81,5.69,'#ff2419'],[48.45,79.70,6.56,'#df1c0d'],[37.83,75.92,7.24,'#ff2419'],[29.01,69.96,5.69,'#8f1109'],[22.71,62.29,6.58,'#df1c0d'],[19.42,53.55,7.24,'#ff2419'],[19.42,44.45,5.68,'#8f1109'],[22.71,35.71,6.59,'#df1c0d'],[29.01,28.04,7.23,'#8f1109'],[37.83,22.08,5.68,'#ff2419'],[48.45,18.3,6.61,'#df1c0d']];
  var CAUDA = [[34,74,6.2,'#8f1109'],[28,85,4.6,'#ff2419'],[24,94,3.1,'#df1c0d'],[21,101,2.0,'#8f1109']];
  function orb(el) {
    var s = el.getAttribute('size') || 24, anim = el.hasAttribute('animate');
    var h = KF + '<svg width="' + s + '" height="' + s + '" viewBox="0 0 120 120">';
    ANEL.forEach(function (c, i) { h += '<circle cx="' + c[0] + '" cy="' + c[1] + '" r="' + c[2] + '" fill="' + c[3] + '"' + (anim ? ' style="transform-box:fill-box;transform-origin:center;animation:orbpop 2.2s ease-in-out ' + (i * 0.09) + 's infinite"' : '') + '/>'; });
    CAUDA.forEach(function (c, i) { h += '<circle cx="' + c[0] + '" cy="' + c[1] + '" r="' + c[2] + '" fill="' + c[3] + '"' + (anim ? ' style="animation:orbtail 2.2s ease-in-out ' + (i * 0.12) + 's infinite"' : '') + '/>'; });
    root(el).innerHTML = h + '</svg>';
  }
  if (!customElements.get('hubia-orb')) {
    customElements.define('hubia-orb', class extends HTMLElement {
      static get observedAttributes() { return ['size', 'animate']; }
      connectedCallback() { orb(this); }
      attributeChangedCallback() { if (this.isConnected) orb(this); }
    });
  }
  if (!customElements.get('lu-icon')) {
    customElements.define('lu-icon', class extends HTMLElement {
      static get observedAttributes() { return ['name', 'size', 'stroke', 'fill', 'draw']; }
      connectedCallback() { render(this); }
      attributeChangedCallback() { if (this.isConnected) render(this); }
    });
  }
  function refresh() { document.querySelectorAll('lu-icon').forEach(render); }
  if (!window.lucide) {
    var s = document.createElement('script');
    s.src = 'https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js';
    s.onload = refresh;
    document.head.appendChild(s);
  }
})();
