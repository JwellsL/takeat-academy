// Takeat Academy — regras de negócio (puras). Sem UI.
(function () {
  var DAY = 864e5;
  var z = function (n) { return String(n).padStart(2, '0'); };
  var E = {};
  E.DAY = DAY;
  E.dkey = function (d) { return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };
  E.pk = function (k) { var a = k.split('-').map(Number); return new Date(a[0], a[1] - 1, a[2]); };
  E.monday = function (d) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - (x.getDay() + 6) % 7); return x; };
  E.shuffle = function (a, r) { r = r || Math.random; a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
  E.seeded = function (s) { var h = 2166136261; String(s).split('').forEach(function (c) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }); return function () { h += 0x6D2B79F5; var t = h; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
  E.digits = function (s) { return String(s == null ? '' : s).replace(/\D/g, ''); };
  E.mmss = function (sec) { sec = Math.max(0, Math.round(sec)); return Math.floor(sec / 60) + ':' + z(sec % 60); };
  E.ini = function (nome) { if (!nome) return '?'; var p = nome.trim().split(/\s+/); return ((p[0] || '')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); };
  E.moldSrc = function (asset) { if (!asset) return null; var p = 'public/molduras/' + asset.replace(':', '-') + '.png'; return (window.ACADEMY_IMG && window.ACADEMY_IMG[p]) || './' + p; };
  E.av = function (nome, mold) { var src = E.moldSrc(mold); return { ini: E.ini(nome), src: src || '', has: !!src, no: !src }; };
  E.nameFromEmail = function (email) { var l = String(email).split('@')[0]; return l.split(/[._-]+/).filter(Boolean).map(function (w) { return w[0].toUpperCase() + w.slice(1); }).join(' ') || 'Colaborador'; };

  E.OPT_TYPES = ['multipla_escolha', 'verdadeiro_falso', 'cenario', 'diagnostico', 'completar_lacuna', 'toque_na_tela', 'calculo'];
  E.TYPE_LABEL = {
    multipla_escolha: ['Múltipla escolha', 'list-checks'], verdadeiro_falso: ['Verdadeiro ou falso', 'toggle-right'],
    ordenar_passos: ['Ordene os passos', 'list-ordered'], combinar_pares: ['Combine os pares', 'shuffle'],
    completar_lacuna: ['Complete a lacuna', 'text-cursor-input'], cenario: ['Cenário', 'message-square'],
    diagnostico: ['Diagnóstico', 'stethoscope'], onde_fica: ['Onde fica?', 'map'],
    toque_na_tela: ['Toque na tela certa', 'mouse-pointer-click'], calculo: ['Cálculo rápido', 'calculator']
  };
  E.NODE_XP = { licao: 10, caso: 10, checkpoint: 20, mestre: 40, bau: 0 };
  E.NOREQ = ['placement', 'skip', 'mestre'];

  E.buildTree = function (opts) {
    var root = { label: 'Início', kids: [], value: null };
    opts.forEach(function (o) {
      var parts = o.split(/\s*→\s*/), n = root;
      parts.forEach(function (pt, i) {
        var c = n.kids.find(function (k) { return k.label === pt; });
        if (!c) { c = { label: pt, kids: [], value: null }; n.kids.push(c); }
        n = c; if (i === parts.length - 1) n.value = o;
      });
    });
    root.kids = E.shuffle(root.kids);
    return root;
  };
  E.numericAnswer = function (q) { return q.tipo === 'calculo' && /\d/.test(q.resposta) && String(q.resposta).length <= 14; };

  E.dayRec = function (p, k) { if (!p.day[k]) p.day[k] = { lessons: 0, perfect: 0, maxCombo: 0, reviews: 0, xp: 0, whys: 0, claimed: {}, chest: false }; return p.day[k]; };
  E.goalXp = function (cfg, p) { var g = cfg.GOALS.find(function (x) { return x.min === p.goalMin; }); return g ? g.xp : 20; };

  E.missionsFor = function (cfg, k) {
    var pool = E.shuffle(cfg.MISSIONS, E.seeded('m' + k)), out = [];
    pool.forEach(function (m) { if (out.length < 3 && !(m.m === 'xp' && out.some(function (o) { return o.m === 'xp'; }))) out.push(m); });
    return out;
  };

  E.missedWorkdays = function (p, fromK, toDate) {
    var d = E.pk(fromK); d.setDate(d.getDate() + 1); var n = 0, end = E.dkey(toDate), g = 0;
    while (E.dkey(d) < end && g++ < 800) { if (p.workDays.indexOf(d.getDay()) >= 0) n++; d.setDate(d.getDate() + 1); }
    return n;
  };
  E.streakNow = function (p, today) {
    var s = p.streak; if (!s.last) return 0; if (s.last === E.dkey(today)) return s.count;
    return E.missedWorkdays(p, s.last, today) <= s.freezes ? s.count : 0;
  };
  E.extendStreak = function (p, today) {
    var s = p.streak, k = E.dkey(today); if (s.last === k) return null;
    var wk = E.dkey(E.monday(today)), used = 0;
    if (s.grantWeek !== wk) { s.freezes = Math.min(2, (s.freezes || 0) + 1); s.grantWeek = wk; }
    if (!s.last) s.count = 1;
    else { var m = E.missedWorkdays(p, s.last, today); if (m === 0) s.count++; else if (m <= s.freezes) { s.freezes -= m; used = m; s.count++; } else s.count = 1; }
    s.last = k; s.days = (s.days || []).concat([k]).slice(-400); s.best = Math.max(s.best || 0, s.count);
    var M = { 7: 20, 30: 50, 100: 100, 365: 300 }, milestone = null;
    if (M[s.count]) { milestone = { d: s.count, t: M[s.count] }; p.takitos += M[s.count]; }
    return { from: s.count === 1 ? 0 : s.count - 1, to: s.count, used: used, milestone: milestone };
  };

  E.disabledFor = function (cfg, p, team) {
    var d = p.leader.disabled[team]; if (d) return d;
    return cfg.BASE_TEAMS.indexOf(team) >= 0 ? [] : cfg.ATD_UNITS.map(function (_, i) { return i; });
  };

  E._uc = {};
  E.getUnits = function (cfg, bank, atd, p, tid) {
    var key = tid === 'ATD' ? 'ATD' + JSON.stringify([p.team, p.leader.disabled[p.team], p.leader.rules[p.team]]) : tid;
    if (E._uc[key]) return E._uc[key];
    var groups = [];
    if (tid === 'ATD') {
      var dis = E.disabledFor(cfg, p, p.team), U = cfg.ATD_UNITS;
      U.forEach(function (u, i) { if (!u.critico && dis.indexOf(i) < 0) groups.push({ title: u.titulo, regra: u.regra, qs: atd.filter(function (q) { return q.unidade === u.titulo; }) }); });
      (p.leader.rules[p.team] || []).filter(function (r) { return r.published && r.questions.length; }).forEach(function (r) { groups.push({ title: r.titulo, regra: r.descricao, qs: r.questions, custom: true }); });
      var ci = U.findIndex(function (u) { return u.critico; });
      if (groups.length && dis.indexOf(ci) < 0) groups.push({ title: U[ci].titulo, regra: U[ci].regra, qs: atd.filter(function (q) { return q.unidade === U[ci].titulo; }), critico: true });
    } else {
      var map = new Map();
      bank.filter(function (q) { return q.id.slice(0, 3) === tid; }).forEach(function (q) { if (!map.has(q.unidade)) map.set(q.unidade, []); map.get(q.unidade).push(q); });
      map.forEach(function (qs, title) { groups.push({ title: title, qs: qs }); });
    }
    var all = [].concat.apply([], groups.map(function (g) { return g.qs; }));
    var casoPool = all.filter(function (q) { return q.tipo === 'cenario' || q.tipo === 'diagnostico'; });
    var units = groups.map(function (g, ui) {
      var n = g.qs.length, k = Math.max(1, Math.round(n / 7)), size = Math.ceil(n / k), nodes = [];
      for (var i = 0; i < k; i++) {
        var c = g.qs.slice(i * size, (i + 1) * size); if (!c.length) continue;
        var names = []; c.forEach(function (q) { if (names.indexOf(q.licao) < 0) names.push(q.licao); });
        nodes.push({ type: 'licao', title: names.slice(0, 2).join(' · '), qs: c });
        if (i === 0) nodes.push({ type: 'bau', title: 'Baú' });
      }
      if (ui === 1 && casoPool.length >= 3) nodes.push({ type: 'caso', title: 'Caso de turno', qs: E.shuffle(casoPool, E.seeded(tid)).slice(0, 6) });
      nodes.push({ type: 'checkpoint', title: 'Checkpoint · ' + g.title, qs: g.qs });
      if (ui === groups.length - 1) nodes.push({ type: 'mestre', title: 'Desafio Mestre', qs: all.slice().sort(function (a, b) { return b.dificuldade - a.dificuldade; }).slice(0, 14) });
      nodes.forEach(function (nd, ni) { nd.key = tid + ':' + ui + ':' + ni; nd.ui = ui; nd.ni = ni; });
      return Object.assign({}, g, { ui: ui, nodes: nodes, color: cfg.TEAM_DOT_COLORS[ui % 7] });
    });
    E._uc[key] = units;
    return units;
  };
  E.flat = function (units) { return [].concat.apply([], units.map(function (u) { return u.nodes; })); };
  E.trackPct = function (cfg, bank, atd, p, tid) {
    var f = E.flat(E.getUnits(cfg, bank, atd, p, tid)); if (!f.length) return 0;
    return Math.round(f.filter(function (n) { return p.done[n.key]; }).length / f.length * 100);
  };

  E.leagueData = function (cfg, p, today) {
    var r = E.seeded('lg' + p.league.seed + ':' + p.league.idx);
    var others = E.shuffle(cfg.PEOPLE, r).slice(0, cfg.LEAGUE_RULES.cohort - 1);
    var mon = E.monday(today), f = Math.min(1, Math.max(0.12, (today - mon) / (7 * DAY) + 0.08));
    var rows = others.map(function (o) { return { nome: o[0], team: o[1], mold: o[2], xp: Math.round((15 + r() * 230) * f * (1 + p.league.idx * 0.25)) }; });
    rows.push({ nome: p.name || 'Você', team: p.team, mold: p.equipped, xp: p.league.xp, me: true });
    rows.sort(function (a, b) { return b.xp - a.xp || (a.me ? -1 : b.me ? 1 : 0); });
    rows.forEach(function (x, i) { x.rank = i + 1; });
    var next = new Date(mon); next.setDate(next.getDate() + 7);
    var left = next - today, d = Math.floor(left / DAY), h = Math.floor((left % DAY) / 36e5);
    return { rows: rows, countdown: d > 0 ? d + 'd ' + h + 'h' : h + 'h ' + Math.floor((left % 36e5) / 6e4) + 'min' };
  };

  E.conquests = function (p, extra) {
    var lessons = 0, perfect = 0;
    Object.keys(p.day).forEach(function (k) { lessons += p.day[k].lessons; perfect += p.day[k].perfect; });
    var fams = [
      { fam: 'Ofensiva', icon: 'flame', levels: [3, 7, 30, 100], val: p.streak.best || 0, un: 'dias seguidos' },
      { fam: 'XP', icon: 'zap', levels: [100, 500, 2000, 5000], val: p.xpTotal, un: 'XP' },
      { fam: 'Perfeição', icon: 'sparkles', levels: [1, 5, 20, 50], val: perfect, un: 'lições perfeitas' },
      { fam: 'Trilhas', icon: 'graduation-cap', levels: [1, 3, 6, 12], val: extra.tracksDone, un: 'trilhas concluídas' }
    ];
    fams.forEach(function (f) { f.level = f.levels.filter(function (l) { return f.val >= l; }).length; f.next = f.levels[f.level] || null; });
    return { fams: fams, lessons: lessons, perfect: perfect };
  };
  E.ROMAN = ['', 'I', 'II', 'III', 'IV', 'V'];

  E.fmtFonte = function (f) {
    if (!f) return '';
    return String(f).split(/\s*[;,]\s*(?=[\w-]+\/|treinamento|wiki)/).map(function (part) {
      var m = part.match(/^(.*?)(\s+§.*)?$/), path = m[1].trim(), sec = (m[2] || '').trim();
      var segs = path.split('/'), file = segs[segs.length - 1].replace(/\.(html?|md|tsx?|jsx?|mjs)$/i, '').replace(/^\d+[-_]/, '').replace(/[-_]+/g, ' ');
      file = file.charAt(0).toUpperCase() + file.slice(1);
      var origem = /^wiki/i.test(path) ? 'Wiki' : /^treinamento/i.test(path) ? 'Treinamento Takeat' : segs.length > 1 ? segs[0] : '';
      if (origem === 'Treinamento Takeat') return origem + (sec ? ' · ' + sec : '');
      return (origem && origem !== file ? origem + ' · ' : '') + file + (sec ? ' · ' + sec : '');
    }).join(' / ');
  };
  window.AcademyEngine = E;
})();
