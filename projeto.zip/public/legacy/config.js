// Configuração mockada do Takeat Academy — troque por Supabase do TakeatHub.
window.ACADEMY_CFG = {
  // Ligas (lista provisória, aguardando confirmação — Parte 8.1, opção A)
  LEAGUES: [
    { id: 'bronze', icon: 'shield', nome: 'Bronze', g: 'linear-gradient(145deg,#e7a46a,#a2582a 60%,#6e3412)' },
    { id: 'prata', icon: 'medal', nome: 'Prata', g: 'linear-gradient(145deg,#f1f5f9,#a7b1be 55%,#6b7686)' },
    { id: 'ouro', icon: 'trophy', nome: 'Ouro', g: 'linear-gradient(145deg,#FFD66B,#FF8A3D)' },
    { id: 'platina', icon: 'star', nome: 'Platina', g: 'linear-gradient(145deg,#3DFFBE,#14B8A6)' },
    { id: 'diamante', icon: 'gem', nome: 'Diamante', g: 'linear-gradient(145deg,#7CC9FF,#5B6CFF)' },
    { id: 'mestre', icon: 'crown', nome: 'Mestre', g: 'linear-gradient(135deg,#FF2F6E,#A82743 55%,#5B1A8A)' }
  ],
  LEAGUE_RULES: { cohort: 20, sobem: 5, descem: 3, premioPromocao: 30 },

  // src/lib/teams.ts
  TEAMS: ['Automações de Processos', 'Comercial', 'Financeiro', 'Marketing', 'Novos Canais', 'Onboarding', 'RH', 'Sucesso', 'Suporte', 'Tecnologia', 'Produto'],
  BASE_TEAMS: ['Suporte', 'Sucesso', 'Onboarding', 'Comercial'],
  TEAM_DOT_COLORS: ['hsl(6 91% 47%)', 'hsl(212 70% 50%)', 'hsl(142 60% 40%)', 'hsl(262 60% 55%)', 'hsl(28 90% 52%)', 'hsl(190 65% 42%)', 'hsl(330 65% 52%)'],

  TRACKS: [
    { id: 'FUN', nome: 'Fundamentos Takeat', icon: 'graduation-cap' },
    { id: 'OPE', nome: 'Operação/PDV', icon: 'monitor' },
    { id: 'KDS', nome: 'Cozinha/KDS', icon: 'chef-hat' },
    { id: 'DEL', nome: 'Delivery', icon: 'bike' },
    { id: 'GES', nome: 'Área do Gestor', icon: 'chart-column' },
    { id: 'CAN', nome: 'Canais do cliente', icon: 'tablet-smartphone' },
    { id: 'DIS', nome: 'Dispositivos/Impressão/TEF/POS/Balança', icon: 'printer' },
    { id: 'INT', nome: 'Integrações', icon: 'plug' },
    { id: 'FIS', nome: 'Fiscal', icon: 'receipt' },
    { id: 'MUL', nome: 'Multilojas', icon: 'building-2' },
    { id: 'CLU', nome: 'Clube/Banestes', icon: 'heart-handshake' },
    { id: 'BAS', nome: 'Bastidores Takeat', icon: 'briefcase' }
  ],

  // Tabela 3.1 da documentação, mapeada para as trilhas do banco
  PERSONAS: [
    { id: 'cs', nome: 'Suporte', grupo: 'Time Takeat', icon: 'headset', order: ['FUN', 'BAS', 'OPE', 'DIS', 'FIS', 'INT', 'CAN', 'GES'] },
    { id: 'sucesso', nome: 'Sucesso', grupo: 'Time Takeat', icon: 'trending-up', order: ['FUN', 'BAS', 'GES', 'OPE', 'CLU', 'MUL'] },
    { id: 'onboarding', nome: 'Onboarding', grupo: 'Time Takeat', icon: 'rocket', order: ['FUN', 'OPE', 'KDS', 'DEL', 'DIS', 'FIS'] },
    { id: 'comercial', nome: 'Comercial', grupo: 'Time Takeat', icon: 'handshake', order: ['FUN', 'BAS', 'GES', 'OPE', 'CLU'] },
    { id: 'produto', nome: 'Produto', grupo: 'Time Takeat', icon: 'lightbulb', order: ['FUN', 'BAS', 'OPE', 'KDS', 'DEL', 'GES', 'CAN', 'DIS', 'INT', 'FIS', 'MUL'] },
    { id: 'tecnologia', nome: 'Tecnologia', grupo: 'Time Takeat', icon: 'code', order: ['FUN', 'BAS', 'INT', 'DIS', 'FIS', 'OPE'] },
    { id: 'financeiro', nome: 'Financeiro', grupo: 'Time Takeat', icon: 'wallet', order: ['FUN', 'GES', 'FIS'] },
    { id: 'marketing', nome: 'Marketing', grupo: 'Time Takeat', icon: 'megaphone', order: ['FUN', 'GES', 'CLU', 'CAN'] },
    { id: 'novoscanais', nome: 'Novos Canais', grupo: 'Time Takeat', icon: 'radio-tower', order: ['FUN', 'CAN', 'INT', 'DEL'] },
    { id: 'automacoes', nome: 'Automações de Processos', grupo: 'Time Takeat', icon: 'workflow', order: ['FUN', 'BAS', 'INT', 'GES'] },
    { id: 'rh', nome: 'RH', grupo: 'Time Takeat', icon: 'users', order: ['FUN', 'BAS'] },
    { id: 'garcom', nome: 'Garçom', grupo: 'Restaurante', icon: 'utensils', order: ['FUN', 'OPE'] },
    { id: 'caixa', nome: 'Caixa', grupo: 'Restaurante', icon: 'banknote', order: ['FUN', 'OPE', 'DEL', 'FIS'] },
    { id: 'cozinha', nome: 'Cozinha', grupo: 'Restaurante', icon: 'chef-hat', order: ['FUN', 'KDS'] },
    { id: 'gerente', nome: 'Gerente', grupo: 'Restaurante', icon: 'clipboard-list', order: ['FUN', 'OPE', 'GES', 'MUL'] },
    { id: 'dono', nome: 'Dono', grupo: 'Restaurante', icon: 'store', order: ['FUN', 'OPE', 'GES', 'MUL'] }
  ],
  OBJETIVOS: [
    { id: 'chegando', t: 'Estou chegando agora', d: 'Quero o básico bem feito, do começo.' },
    { id: 'especializar', t: 'Quero me especializar', d: 'Já uso no dia a dia e quero ir fundo.' },
    { id: 'resolver', t: 'Preciso resolver algo', d: 'Vou direto ao tema que está travando.' }
  ],
  GOALS: [{ min: 3, xp: 10, t: 'Leve' }, { min: 5, xp: 20, t: 'Constante' }, { min: 10, xp: 40, t: 'Focado' }, { min: 15, xp: 60, t: 'Intenso' }],
  REMINDERS: ['08:00', '09:30', '12:00', '14:00', '17:30'],

  // Trilha Regras de Atendimento — rubrica da Monitoria (Parte 8.2)
  ATD_UNITS: [
    { titulo: 'Entendimento da demanda', regra: 'Compreender o motivo do contato. Investigar e perguntar, sem presumir' },
    { titulo: 'Comunicação', regra: 'Tom Takeat: cortês, humano e objetivo, sem formalidade excessiva e sem respostas robóticas' },
    { titulo: 'Condução', regra: 'Manter o cliente informado, não abandonar a conversa e explicar os próximos passos' },
    { titulo: 'Conhecimento / Procedimento', regra: 'Orientar corretamente. Não inventar solução nem prazo' },
    { titulo: 'Resolução', regra: 'Resolver quando possível, confirmar a resolução e não encerrar antes da hora' },
    { titulo: 'Encaminhamento interno', regra: 'Acionar Produto/N2/N3 quando necessário, com contexto suficiente' },
    { titulo: 'Registro / Motivo', regra: 'Classificar corretamente: motivo, tags e propriedades do ticket' },
    { titulo: 'Gestão de expectativa', regra: 'Comunicar dependências de outros times. Não prometer prazo que não existe' },
    { titulo: 'Encerramento', regra: 'Confirmar se há outra necessidade e encerrar adequadamente' },
    { titulo: 'CSAT', regra: 'Enviar a pesquisa conforme o processo, sem manipular a resposta' },
    { titulo: 'Erros críticos', regra: 'O que zera a nota: informação incorreta grave, rispidez ou perda de paciência, pedir informação que já tinha, agressão verbal', critico: true }
  ],
  // Mock da nota da Monitoria do usuário por critério (0–100)
  MONITORIA: { 'Entendimento da demanda': 86, 'Comunicação': 91, 'Condução': 74, 'Conhecimento / Procedimento': 82, 'Resolução': 79, 'Encaminhamento interno': 66, 'Registro / Motivo': 55, 'Gestão de expectativa': 52, 'Encerramento': 88, 'CSAT': 93 },

  PEOPLE: [
    ['Ana Prado', 'Suporte', 'metal:ouro'], ['Bruno Lima', 'Sucesso', null], ['Carla Souza', 'Produto', 'natureza:aurora'], ['Diego Martins', 'Suporte', null],
    ['Elisa Rocha', 'Onboarding', 'metal:prata'], ['Felipe Costa', 'Comercial', null], ['Gabriela Nunes', 'Suporte', 'rpg:mago'], ['Henrique Alves', 'Tecnologia', null],
    ['Isabela Freitas', 'Financeiro', 'metal:bronze'], ['João Pedro Reis', 'Suporte', null], ['Karina Lopes', 'Sucesso', 'takeat:marca'], ['Lucas Barros', 'Onboarding', null],
    ['Mariana Teixeira', 'Marketing', null], ['Nicolas Duarte', 'Produto', 'metal:prata'], ['Olívia Campos', 'Suporte', null], ['Paulo Henrique', 'Comercial', 'metal:bronze'],
    ['Rafaela Moura', 'Sucesso', null], ['Samuel Pires', 'Novos Canais', null], ['Tainá Ribeiro', 'RH', 'natureza:aurora'], ['Vitor Azevedo', 'Suporte', null],
    ['Yasmin Cardoso', 'Onboarding', null], ['Wesley Gomes', 'Automações de Processos', null], ['Laura Mendes', 'Suporte', 'metal:ouro'], ['Rodrigo Sales', 'Sucesso', null]
  ],

  MISSIONS: [
    { k: 'xp30', t: 'Ganhe 30 XP', meta: 30, m: 'xp' },
    { k: 'xp50', t: 'Ganhe 50 XP', meta: 50, m: 'xp' },
    { k: 'combo5', t: 'Acerte 5 seguidas', meta: 5, m: 'maxCombo' },
    { k: 'review1', t: 'Revise 1 erro', meta: 1, m: 'reviews' },
    { k: 'lessons2', t: 'Conclua 2 lições', meta: 2, m: 'lessons' },
    { k: 'perfect1', t: 'Faça 1 lição perfeita', meta: 1, m: 'perfect' },
    { k: 'why2', t: 'Abra o "Por quê?" 2 vezes', meta: 2, m: 'whys' }
  ],
  MISSION_REWARD: 10,
  MONTH_GOAL: 20,
  TEAM_GOAL: 40,

  // Loja do Hub (src/pages/Loja.tsx) + itens do Academy
  SHOP: [
    { id: 'm-bronze', tipo: 'moldura', asset: 'metal:bronze', nome: 'Bronze', raridade: 'comum', preco: 0, colecao: 'Metais' },
    { id: 'm-prata', tipo: 'moldura', asset: 'metal:prata', nome: 'Prata', raridade: 'comum', preco: 80, colecao: 'Metais' },
    { id: 'm-ouro', tipo: 'moldura', asset: 'metal:ouro', nome: 'Ouro', raridade: 'raro', preco: 200, colecao: 'Metais' },
    { id: 'm-aurora', tipo: 'moldura', asset: 'natureza:aurora', nome: 'Aurora', raridade: 'epico', preco: 350, colecao: 'Natureza' },
    { id: 'm-mago', tipo: 'moldura', asset: 'rpg:mago', nome: 'Mago', raridade: 'epico', preco: 400, colecao: 'RPG' },
    { id: 'm-takeat', tipo: 'moldura', asset: 'takeat:marca', nome: 'Marca Takeat', raridade: 'lendario', preco: 0, colecao: 'Takeat', somente_codigo: true },
    { id: 'm-natal', tipo: 'moldura', asset: 'natureza:aurora', nome: 'Aurora de Fim de Ano', raridade: 'sazonal', preco: 300, colecao: 'Sazonal' },
    { id: 'f-brasa', tipo: 'fundo', nome: 'Brasa', raridade: 'comum', preco: 60, colecao: 'Fundos', g: 'linear-gradient(135deg,#ff2419,#8f1109)' },
    { id: 'f-menta', tipo: 'fundo', nome: 'Menta', raridade: 'comum', preco: 60, colecao: 'Fundos', g: 'linear-gradient(135deg,#3DFFBE,#14B8A6)' },
    { id: 'f-gelo', tipo: 'fundo', nome: 'Gelo', raridade: 'raro', preco: 150, colecao: 'Fundos', g: 'linear-gradient(135deg,#7CC9FF,#5B6CFF)' },
    { id: 'f-ouro', tipo: 'fundo', nome: 'Dourado', raridade: 'epico', preco: 280, colecao: 'Fundos', g: 'linear-gradient(135deg,#FFD66B,#FF8A3D)' },
    { id: 'f-wrap', tipo: 'fundo', nome: 'Relatório do Gestor', raridade: 'lendario', preco: 600, colecao: 'Fundos', g: 'linear-gradient(135deg,#FF2F6E,#A82743 55%,#5B1A8A)' },
    { id: 'f-sunset', tipo: 'fundo', nome: 'Pôr do sol', raridade: 'sazonal', preco: 250, colecao: 'Sazonal', g: 'linear-gradient(135deg,#FFB36B,#FF4D6D 50%,#C026D3)' },
    { id: 'c-chef', tipo: 'icone', nome: 'Chef', raridade: 'comum', preco: 40, colecao: 'Ícones', icon: 'chef-hat' },
    { id: 'c-headset', tipo: 'icone', nome: 'Atendimento', raridade: 'comum', preco: 40, colecao: 'Ícones', icon: 'headset' },
    { id: 'c-rocket', tipo: 'icone', nome: 'Foguete', raridade: 'raro', preco: 120, colecao: 'Ícones', icon: 'rocket' },
    { id: 'c-crown', tipo: 'icone', nome: 'Coroa', raridade: 'epico', preco: 260, colecao: 'Ícones', icon: 'crown' },
    { id: 'c-flame', tipo: 'icone', nome: 'Chama eterna', raridade: 'lendario', preco: 500, colecao: 'Ícones', icon: 'flame' },
    { id: 'c-snow', tipo: 'icone', nome: 'Floco de neve', raridade: 'sazonal', preco: 180, colecao: 'Sazonal', icon: 'snowflake' },
    { id: 'i-freeze', tipo: 'item', nome: 'Congelamento de ofensiva', raridade: 'comum', preco: 40, colecao: 'Academy', icon: 'snowflake' },
    { id: 'i-boost', tipo: 'item', nome: 'XP em dobro · 15 min', raridade: 'raro', preco: 60, colecao: 'Academy', icon: 'zap' }
  ],
  SHOP_TABS: [['moldura', 'Molduras'], ['fundo', 'Fundos'], ['icone', 'Ícones'], ['item', 'Itens']],
  CODES: { ACADEMY2026: 'm-takeat' },
  RARIDADE: {
    comum: { label: 'Comum', bg: 'hsl(215 16% 55% / .15)', fg: 'hsl(215 16% 45%)', cor: '#94a3b8' },
    raro: { label: 'Raro', bg: 'hsl(217 91% 60% / .15)', fg: 'hsl(217 80% 50%)', cor: '#3b82f6' },
    epico: { label: 'Épico', bg: 'hsl(271 81% 64% / .15)', fg: 'hsl(271 60% 52%)', cor: '#a855f7' },
    lendario: { label: 'Lendário', bg: 'hsl(38 92% 50% / .18)', fg: 'hsl(32 82% 40%)', cor: '#f59e0b' },
    sazonal: { label: 'Sazonal', bg: 'hsl(330 81% 60% / .15)', fg: 'hsl(330 70% 50%)', cor: '#ec4899' }
  },

  GLOSSARY: [
    { t: 'PDV', d: 'Ponto de Venda: a tela de Operação onde mesas, comandas e pedidos são lançados e cobrados.', s: 'Ponto de venda' },
    { t: 'Comanda', d: 'Conta individual de consumo, ligada a uma mesa, balcão ou cliente, que acumula os itens até o pagamento.', s: 'Conta de consumo' },
    { t: 'KDS', d: 'Kitchen Display System: tela da cozinha que substitui a impressão de produção e acompanha as etapas do preparo.', s: 'Tela da cozinha' },
    { t: 'TEF', d: 'Transferência Eletrônica de Fundos: liga a maquininha ao PDV para o valor seguir sozinho, sem digitar duas vezes.', s: 'Maquininha integrada' },
    { t: 'POS', d: 'Maquininha independente (Point of Sale), que não recebe o valor do PDV automaticamente.', s: 'Maquininha avulsa' },
    { t: 'PinPad', d: 'Leitor de cartão conectado ao computador, usado com TEF.', s: 'Leitor ligado ao PC' },
    { t: 'NFC-e', d: 'Nota Fiscal de Consumidor eletrônica, emitida na venda ao consumidor final. Cancelamento em até 30 minutos.', s: 'Nota ao consumidor' },
    { t: 'NF-e', d: 'Nota Fiscal eletrônica de mercadorias entre empresas. Cancelamento em até 24 horas.', s: 'Nota entre empresas' },
    { t: 'CMV', d: 'Custo da Mercadoria Vendida: quanto custaram os insumos do que foi vendido no período.', s: 'Custo do que foi vendido' },
    { t: 'Markup', d: 'Índice aplicado sobre o custo para chegar ao preço de venda.', s: 'Índice sobre o custo' },
    { t: 'Ficha técnica', d: 'Receita do produto com insumos e quantidades, base para baixa de estoque e CMV.', s: 'Receita com insumos' },
    { t: 'DRE', d: 'Demonstração do Resultado: receitas menos custos e despesas por competência.', s: 'Resultado por competência' },
    { t: 'DFC', d: 'Demonstração do Fluxo de Caixa: entradas e saídas pelo dia em que o dinheiro se moveu.', s: 'Caixa por movimento' },
    { t: 'Sangria', d: 'Retirada de dinheiro do caixa durante o turno, registrada para a conferência bater.', s: 'Retirada do caixa' },
    { t: 'Curva ABC', d: 'Classificação dos produtos pela participação no faturamento: A (maior), B e C.', s: 'Ranking de faturamento' },
    { t: 'Cashback', d: 'Parte do valor gasto que volta como crédito para o cliente no Takeat Clube.', s: 'Crédito de volta' },
    { t: 'MRR', d: 'Receita recorrente mensal dos clientes da Takeat.', s: 'Receita recorrente mensal' },
    { t: 'Churn', d: 'Cancelamento de clientes num período.', s: 'Cancelamento de clientes' },
    { t: 'CSAT', d: 'Pesquisa de satisfação enviada ao fim do atendimento.', s: 'Satisfação do atendimento' }
  ]
};
