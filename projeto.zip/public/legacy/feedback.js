// Feedback do Academy — fila local + envio para a nuvem.
// Envio real: tabela `academy_feedback` + bucket `academy-feedback` no Supabase do TakeatHub
// (src/hub.js). A fila local garante o envio offline: o que falhar fica pendente e é
// reenviado quando a conexão volta.
(function () {
  var KEY = 'takeat-academy-feedback-v1';
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
  function save(list) { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { list.forEach(function (f) { f.anexos.forEach(function (a) { a.thumb = null; }); }); try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (x) {} } }
  function online(sim) { return navigator.onLine && !sim; }
  function SEND(entry) {
    if (!window.AcademyHub) return Promise.resolve({ ok: false });
    return window.AcademyHub.enviarFeedback(entry).catch(function () { return { ok: false }; });
  }
  var FB = {
    list: function () { return load(); },
    newId: function () { return 'FB-' + Date.now().toString(36).toUpperCase().slice(-6) + Math.floor(Math.random() * 90 + 10); },
    send: function (entry, sim) {
      var list = load(); entry.status = 'pendente'; list.unshift(entry); save(list);
      if (!online(sim)) return Promise.resolve(entry);
      return SEND(entry).then(function (r) {
        var l = load(), it = l.find(function (x) { return x.id === entry.id; });
        if (it && r.ok) { it.status = 'enviado'; it.syncedAt = r.at; save(l); }
        return it || entry;
      });
    },
    flush: function (sim) {
      if (!online(sim)) return Promise.resolve(0);
      var pend = load().filter(function (x) { return x.status === 'pendente'; });
      return Promise.all(pend.map(function (e) { return SEND(e).then(function (r) { return { id: e.id, r: r }; }); })).then(function (res) {
        var l = load(), n = 0;
        res.forEach(function (x) { var it = l.find(function (y) { return y.id === x.id; }); if (it && x.r && x.r.ok) { it.status = 'enviado'; it.syncedAt = x.r.at; n++; } });
        save(l); return n;
      });
    }
  };
  window.AcademyFeedback = FB;
})();
