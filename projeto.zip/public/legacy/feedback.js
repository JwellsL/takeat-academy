// Feedback do Academy — fila local + envio para a nuvem.
// Produção: trocar SEND por insert na tabela `academy_feedback` (Supabase do TakeatHub)
// e upload dos anexos no bucket `academy-feedback`. A fila local garante o envio offline.
(function () {
  var KEY = 'takeat-academy-feedback-v1';
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
  function save(list) { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { list.forEach(function (f) { f.anexos.forEach(function (a) { a.thumb = null; }); }); try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (x) {} } }
  function online(sim) { return navigator.onLine && !sim; }
  function SEND(entry) { return new Promise(function (res) { setTimeout(function () { res({ ok: true, at: Date.now() }); }, 900); }); }
  var FB = {
    list: function () { return load(); },
    newId: function () { return 'FB-' + Date.now().toString(36).toUpperCase().slice(-6) + Math.floor(Math.random() * 90 + 10); },
    send: function (entry, sim) {
      var list = load(); entry.status = 'pendente'; list.unshift(entry); save(list);
      if (!online(sim)) return Promise.resolve(entry);
      return SEND(entry).then(function (r) {
        var l = load(), it = l.find(function (x) { return x.id === entry.id; });
        if (it && r.ok) { it.status = 'enviado'; it.syncedAt = r.at; save(l); }
        return it || entry;
      });
    },
    flush: function (sim) {
      if (!online(sim)) return Promise.resolve(0);
      var pend = load().filter(function (x) { return x.status === 'pendente'; });
      return Promise.all(pend.map(SEND)).then(function () {
        var l = load(); l.forEach(function (x) { if (x.status === 'pendente') { x.status = 'enviado'; x.syncedAt = Date.now(); } }); save(l); return pend.length;
      });
    }
  };
  window.AcademyFeedback = FB;
})();
