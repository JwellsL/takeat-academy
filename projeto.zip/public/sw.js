// Service worker do Academy: app 100% offline (cache-first para arquivos do próprio app).
const CACHE = 'academy-v1';
const CORE = ['./', './index.html', './manifest.webmanifest', './legacy/lucide.min.js', './legacy/academy-img.js', './legacy/icons.js', './legacy/engine.js', './legacy/config.js', './legacy/bank.js', './legacy/atendimento.js', './legacy/feedback.js', './assets/academy-book.png', './assets/takeat-mark.png', './src/assets/takitos.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
  if (r.mode === 'navigate') {
    e.respondWith(fetch(r).then(res => { caches.open(CACHE).then(c => c.put('./index.html', res.clone())); return res; }).catch(() => caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); } return res; })));
});
