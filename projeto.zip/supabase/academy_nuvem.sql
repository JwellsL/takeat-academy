-- Takeat Academy · progresso na nuvem, ranking real e Takitos do TakeatHub.
-- Supabase do TakeatHub (ggorwvqcqgzvcdzcmbov). Idempotente: pode rodar mais de uma vez.
-- Aplicar no SQL Editor do PROD.

-- 1) Progresso e configurações do usuário (1 linha por pessoa) -------------------------
create table if not exists public.academy_progresso (
  user_id      uuid primary key references auth.users(id) on delete cascade,
  dados        jsonb not null default '{}'::jsonb,   -- estado completo do app (trilhas, ofensiva, emblemas, config…)
  xp_total     integer not null default 0,
  liga_semana  text,                                 -- segunda-feira da semana (yyyy-mm-dd)
  liga_xp      integer not null default 0,           -- XP na semana (ranking)
  liga_idx     integer not null default 0,           -- 0 Bronze … 5 Mestre
  posicoes     jsonb not null default '{}'::jsonb,   -- fase atual por trilha { "FUN": "FUN:0:2", … }
  resumo       jsonb not null default '{}'::jsonb,   -- números públicos p/ colegas: lições na semana, ofensiva, % atendimento
  atualizado_em timestamptz not null default now()
);
alter table public.academy_progresso add column if not exists resumo jsonb not null default '{}'::jsonb;
create index if not exists academy_progresso_semana_idx on public.academy_progresso (liga_semana, liga_xp desc);

alter table public.academy_progresso enable row level security;

drop policy if exists "academy_progresso le o proprio" on public.academy_progresso;
create policy "academy_progresso le o proprio" on public.academy_progresso
  for select to authenticated using (user_id = auth.uid());
-- Escrita só pelas RPCs abaixo (security definer).

-- (a versão antiga sem p_resumo, se existir, é removida)
drop function if exists public.academy_salvar(jsonb, integer, text, integer, integer, jsonb);
-- (o retorno do ranking mudou: recria)
drop function if exists public.academy_ranking(text);

-- 2) Salvar progresso ---------------------------------------------------------------------
create or replace function public.academy_salvar(
  p_dados jsonb, p_xp_total integer, p_liga_semana text, p_liga_xp integer, p_liga_idx integer, p_posicoes jsonb, p_resumo jsonb default '{}'::jsonb
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'sem sessão'; end if;
  insert into public.academy_progresso (user_id, dados, xp_total, liga_semana, liga_xp, liga_idx, posicoes, resumo, atualizado_em)
  values (uid, coalesce(p_dados, '{}'::jsonb), greatest(0, coalesce(p_xp_total, 0)), p_liga_semana,
          greatest(0, coalesce(p_liga_xp, 0)), least(5, greatest(0, coalesce(p_liga_idx, 0))), coalesce(p_posicoes, '{}'::jsonb), coalesce(p_resumo, '{}'::jsonb), now())
  on conflict (user_id) do update set
    dados = excluded.dados, xp_total = excluded.xp_total, liga_semana = excluded.liga_semana,
    liga_xp = excluded.liga_xp, liga_idx = excluded.liga_idx, posicoes = excluded.posicoes, resumo = excluded.resumo, atualizado_em = now();
  return jsonb_build_object('ok', true, 'em', now());
end $$;

-- 3) Estado ao abrir o app: progresso salvo + saldo de Takitos do Hub ---------------------
create or replace function public.academy_estado()
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); v record;
begin
  if uid is null then raise exception 'sem sessão'; end if;
  select dados, atualizado_em into v from public.academy_progresso where user_id = uid;
  return jsonb_build_object('dados', v.dados, 'atualizado_em', v.atualizado_em, 'saldo', public.takitos_saldo(uid));
end $$;

-- 4) Takitos: ganhos e gastos do Academy entram no MESMO saldo do Hub (takitos_ledger) ------
-- Idempotente por ref (o app manda um id único por movimento). Ganho limitado por chamada
-- e gasto só com saldo suficiente.
create or replace function public.academy_takitos(p_delta integer, p_ref text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); v_ref text := 'academy:' || left(coalesce(p_ref, ''), 120); v_saldo integer;
begin
  if uid is null then raise exception 'sem sessão'; end if;
  if p_delta is null or p_delta = 0 or p_ref is null or p_ref = '' then
    return jsonb_build_object('ok', false, 'erro', 'movimento inválido', 'saldo', public.takitos_saldo(uid));
  end if;
  if p_delta > 300 then
    return jsonb_build_object('ok', false, 'erro', 'ganho acima do limite', 'saldo', public.takitos_saldo(uid));
  end if;
  if exists (select 1 from public.takitos_ledger where user_id = uid and ref = v_ref) then
    return jsonb_build_object('ok', true, 'repetido', true, 'saldo', public.takitos_saldo(uid));
  end if;
  v_saldo := public.takitos_saldo(uid);
  if p_delta < 0 and v_saldo + p_delta < 0 then
    return jsonb_build_object('ok', false, 'erro', 'saldo insuficiente', 'saldo', v_saldo);
  end if;
  insert into public.takitos_ledger (user_id, delta, motivo, ref) values (uid, p_delta, 'ajuste', v_ref);
  return jsonb_build_object('ok', true, 'saldo', public.takitos_saldo(uid));
end $$;

-- 5) Ranking real da semana: todos que pontuaram no Academy nesta semana -------------------
create or replace function public.academy_ranking(p_semana text)
returns table (user_id uuid, nome text, equipe text, avatar_url text, moldura text, liga_xp integer, liga_idx integer, xp_total integer, posicoes jsonb, resumo jsonb, eu boolean)
language sql security definer set search_path = public stable as $$
  select a.user_id, coalesce(nullif(pr.full_name, ''), split_part(u.email, '@', 1)), pr.team, pr.avatar_url,
         li.asset, case when a.liga_semana = p_semana then a.liga_xp else 0 end, a.liga_idx, a.xp_total, a.posicoes, a.resumo,
         a.user_id = auth.uid()
  from public.academy_progresso a
  join auth.users u on u.id = a.user_id
  left join public.profiles pr on pr.id = a.user_id
  left join public.loja_itens li on li.id = pr.moldura_id
  where auth.uid() is not null
$$;

revoke all on function public.academy_salvar(jsonb, integer, text, integer, integer, jsonb, jsonb) from public, anon;
revoke all on function public.academy_estado() from public, anon;
revoke all on function public.academy_takitos(integer, text) from public, anon;
revoke all on function public.academy_ranking(text) from public, anon;
grant execute on function public.academy_salvar(jsonb, integer, text, integer, integer, jsonb, jsonb) to authenticated;
grant execute on function public.academy_estado() to authenticated;
grant execute on function public.academy_takitos(integer, text) to authenticated;
grant execute on function public.academy_ranking(text) to authenticated;

-- Reset do período de teste (quando quiserem zerar tudo):
--   delete from public.academy_progresso;
--   delete from public.takitos_ledger where ref like 'academy:%';   -- opcional: desfaz os Takitos do Academy
