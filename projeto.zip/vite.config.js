import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { readFileSync } from 'node:fs';

const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'));

export default defineConfig({
  base: './',
  plugins: [react()],
  // Versão/build gravados no app: o build vem do número da execução no GitHub Actions (VITE_BUILD).
  define: { __APP_VERSION__: JSON.stringify(pkg.version), __APP_BUILD__: JSON.stringify(process.env.VITE_BUILD || '0') },
  build: { chunkSizeWarningLimit: 2000 },
  server: { port: 5181 },
});
