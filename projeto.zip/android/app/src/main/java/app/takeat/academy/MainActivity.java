package app.takeat.academy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
